/**
 * FÊNIX OS — Unified Secret Resolver
 * Resolves credentials deterministically from Docker secrets, file paths, and environment variables.
 * Guarantees zero secret leakage in logs, frontend, or error messages.
 */

const fs = require('node:fs');
const path = require('node:path');

function readSecretFile(filePath) {
  try {
    if (filePath && fs.existsSync(filePath)) {
      const content = fs.readFileSync(filePath, 'utf8').trim();
      if (content && content !== 'dummy' && content.length > 0) {
        return content;
      }
    }
  } catch {
    // Secret file unreadable or permission denied
  }
  return null;
}

function resolveSecret(secretName, env = process.env) {
  // 1. Check standard Docker Secret location (/run/secrets/<secretName>)
  const dockerSecretPath = path.join('/run/secrets', secretName);
  const fromDockerSecret = readSecretFile(dockerSecretPath);
  if (fromDockerSecret) return fromDockerSecret;

  // 2. Check custom secret file path via environment variable (<SECRET_NAME>_FILE)
  const envFileVar = `${secretName.toUpperCase()}_FILE`;
  if (env[envFileVar]) {
    const fromEnvFile = readSecretFile(env[envFileVar]);
    if (fromEnvFile) return fromEnvFile;
  }

  // 3. Check direct environment variable mappings
  const envMappings = {
    ai_provider_key: ['GRG_AIPLATFORM_KEY', 'AI_PROVIDER_KEY', 'FENIX_AI_KEY'],
    github_token: ['GITHUB_TOKEN', 'GH_TOKEN', 'FENIX_GITHUB_TOKEN'],
    postgres_password: ['POSTGRES_PASSWORD', 'PGPASSWORD'],
    redis_password: ['REDIS_PASSWORD'],
    metrics_token: ['FENIX_METRICS_TOKEN', 'METRICS_TOKEN'],
    keycloak_admin_password: ['KEYCLOAK_ADMIN_PASSWORD', 'KC_BOOTSTRAP_ADMIN_PASSWORD'],
    minio_access_key: ['MINIO_ACCESS_KEY', 'MINIO_ROOT_USER'],
    minio_secret_key: ['MINIO_SECRET_KEY', 'MINIO_ROOT_PASSWORD']
  };

  const candidates = envMappings[secretName] || [secretName.toUpperCase()];
  for (const varName of candidates) {
    if (env[varName] && String(env[varName]).trim().length > 0) {
      return String(env[varName]).trim();
    }
  }

  // 4. Local fallback for development / testing if configured in project .secrets
  const localSecretPath = path.join(__dirname, '..', '..', '.secrets', secretName);
  const fromLocalSecret = readSecretFile(localSecretPath);
  if (fromLocalSecret) return fromLocalSecret;

  const rootSecretPath = path.join(__dirname, '..', '..', '..', '.secrets', secretName);
  const fromRootSecret = readSecretFile(rootSecretPath);
  if (fromRootSecret) return fromRootSecret;

  return null;
}

function storeSecret(secretName, value) {
  const localSecretPath = path.join(__dirname, '..', '..', '.secrets', secretName);
  const dir = path.dirname(localSecretPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  fs.writeFileSync(localSecretPath, String(value || '').trim(), { encoding: 'utf8', mode: 0o600 });
  return true;
}

function deleteSecret(secretName) {
  const localSecretPath = path.join(__dirname, '..', '..', '.secrets', secretName);
  if (fs.existsSync(localSecretPath)) {
    try { fs.unlinkSync(localSecretPath); } catch {}
  }
  const rootSecretPath = path.join(__dirname, '..', '..', '..', '.secrets', secretName);
  if (fs.existsSync(rootSecretPath)) {
    try { fs.unlinkSync(rootSecretPath); } catch {}
  }
  return true;
}

function resolveAIProviderKey(env = process.env) {
  // Um `env` injetado representa um ambiente completo (testes, preflight e tenants).
  // Nao pode herdar silenciosamente a chave da maquina via `.secrets`, pois isso ativa um
  // provider que o chamador explicitamente nao configurou.
  if (env !== process.env) {
    for (const name of ['GRG_AIPLATFORM_KEY', 'AI_PROVIDER_KEY', 'FENIX_AI_KEY']) {
      if (env[name] && String(env[name]).trim()) return String(env[name]).trim();
    }
    return null;
  }

  // If local .secrets/ai_provider_key has a validated live key, prefer it over stale ap_dev env vars
  const localSecretPath = path.join(__dirname, '..', '..', '..', '.secrets', 'ai_provider_key');
  const fromLocal = readSecretFile(localSecretPath) || readSecretFile(path.join(__dirname, '..', '..', '.secrets', 'ai_provider_key'));
  if (fromLocal && fromLocal.startsWith('ap_live_')) return fromLocal;

  // A configuracao explicita do ambiente deve vencer secrets montados antigos.
  for (const name of ['GRG_AIPLATFORM_KEY', 'AI_PROVIDER_KEY', 'FENIX_AI_KEY']) {
    if (env[name] && String(env[name]).trim() && !String(env[name]).startsWith('ap_dev_')) return String(env[name]).trim();
  }
  return resolveSecret('ai_provider_key', env);
}

function resolveAIPlatformUrl(env = process.env) {
  // Medido em 2026-08-28: :80 serve o dashboard estatico e responde 405 a POST /v1/text.
  // O gateway Fastify real (health, text, chat e jobs) esta exposto em :3000.
  return env.GRG_AIPLATFORM_URL || 'http://209.50.241.22:3001';
}

function resolveAIPlatformModel(env = process.env) {
  return env.GRG_AIPLATFORM_MODEL || 'qwen2.5:3b';
}

module.exports = {
  resolveSecret,
  storeSecret,
  deleteSecret,
  resolveAIProviderKey,
  resolveAIPlatformUrl,
  resolveAIPlatformModel
};
