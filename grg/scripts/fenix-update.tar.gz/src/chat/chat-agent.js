// ChatAgent: a camada de conversa do OMEGA. Interpreta a mensagem, CONSULTA o estado real
// (twins, insights, memória, catálogo) e EXECUTA ações reais (acoplar/analisar/gerar/aconselhar).
//
// Honestidade: sem chave de LLM, a interpretação é um roteador de intenção determinístico. Ele
// usa o AI Gateway para redigir a resposta em linguagem natural (adapter Echo hoje; troque por
// OpenAI/Anthropic reais sem mudar este arquivo). As AÇÕES são reais — não simuladas.

const GITHUB_URL_RE = /https?:\/\/github\.com\/[^\s]+/i;

class ChatAgent {
  constructor({ app, llm = null }) {
    this.app = app; // { controlPlane, repoIntel, factory, orchestrator, digitalTwin, evolution, aiGateway, store }
    this.llm = llm === false
      ? null
      : ((llm && typeof llm.chat === 'function') ? llm : (app?.aiGateway && typeof app.aiGateway.chat === 'function' ? app.aiGateway : null));
    this.history = []; // memória de conversa progressiva (últimas trocas)
  }

  // Capacidades como FATO derivado, para o LLM nunca ter de adivinhar o que a FÊNIX faz.
  // Fonte: `capabilityDefinitions` (registro governado) + `health`/`metrics` que o
  // capability-registry escreve a partir de execução real de job. Não há lista escrita à mão
  // aqui de propósito: uma capacidade só aparece como comprovada se algum job dela concluiu.
  #capabilityFacts(state, tenantId) {
    const definicoes = (state.capabilityDefinitions || []).filter((item) => item.tenantId === tenantId);
    if (!definicoes.length) return { registradas: 0, nota: 'registro de capacidades vazio para este tenant' };
    const comprovadas = definicoes.filter((item) => item.health === 'HEALTHY');
    const degradadas = definicoes.filter((item) => item.health === 'DEGRADED');
    return {
      registradas: definicoes.length,
      // O nome sozinho não diz nada ao modelo; a descrição é o que ele precisa para responder
      // "o que você sabe fazer" sem inventar.
      catalogo: definicoes.map((item) => `${item.capabilityId}: ${item.description}`),
      comprovadas_por_execucao: comprovadas.map((item) => `${item.capabilityId} (${item.metrics?.successes ?? 0} sucesso(s), última ${item.lastExecutionAt})`),
      degradadas: degradadas.map((item) => item.capabilityId),
      // Distinção que o usuário precisa ver: "sem execução registrada" NÃO é "não existe".
      sem_execucao_registrada: definicoes.filter((item) => item.health === 'UNKNOWN').map((item) => item.capabilityId),
    };
  }

  // Classifica a intenção com o LLM (linguagem aberta). Fallback nas regras se LLM indisponível.
  async classifyWithLLM(text) {
    if (!this.llm || typeof this.llm.chat !== 'function') return null;
    const sys = `Você é o classificador de intenções do GRG Services OS, uma plataforma que acopla e analisa repositórios GitHub, gera sistemas, mantém memória evolutiva e digital twins.
Dada a mensagem do usuário, responda SOMENTE um JSON: {"intent": "<uma das opções>", "username": "<se houver>", "url": "<se houver>"}.
Intents válidas:
- connect_repo: acoplar/analisar UM repositório (tem URL github)
- ingest_portfolio: acoplar TODOS os repos de um usuário (menciona "todos", "portfólio", "meus projetos", ou um username)
- generate: criar/gerar um novo sistema/projeto/app
- insights: perguntar o que o sistema aprendeu, padrões, evolução
- memory: histórico, memória, decisões
- capabilities: catálogo de funcionalidades/módulos
- twin: analisar arquitetura/saúde/riscos/conselhos de um repo
- list: listar repos/projetos existentes
- overview: status geral, visão geral, resumo, números
- chitchat: conversa casual, saudação, "tudo bem", agradecimento, pergunta genérica
- help: pedir ajuda, o que sabe fazer`;
    try {
      const res = await this.llm.chat({ messages: [
        { role: 'system', content: sys },
        { role: 'user', content: text },
      ], format: 'json', temperature: 0 });
      const parsed = JSON.parse(res.text);
      if (parsed && parsed.intent) return parsed;
    } catch { /* cai no fallback */ }
    return null;
  }

  // Redige a resposta final em linguagem natural a partir dos FATOS reais (anti-alucinação:
  // o LLM só reformula os dados que passamos, não inventa).
  async speak(userText, intent, facts, fallbackReply) {
    if (!this.llm || typeof this.llm.chat !== 'function') return fallbackReply;
    try {
      const sys = `Você é a FÊNIX — o Enterprise Cognitive Kernel da GRG. Não é um chatbot: é o cérebro da plataforma; o modelo de IA é só seu motor de inferência.
Personalidade FIXA: técnica, estratégica, direta. Explica antes de executar. Nunca inventa. Sempre informa nível de confiança quando relevante e cita riscos. Pensa em longo prazo. Fala em português, curto (2-5 frases).
REGRA CRÍTICA: use APENAS os fatos fornecidos no JSON. NÃO invente números, repos, capabilities ou URLs. Se os fatos estão vazios, diga objetivamente o que o operador pode fazer a seguir.
REGRA CRÍTICA 2: NUNCA negue ter uma capacidade. Contador em zero significa "ainda não usei", não "não sei fazer" — nunca diga que não é capaz de algo listado em "capacidades.catalogo". Se uma capacidade está em "sem_execucao_registrada", diga que existe e ainda não foi exercitada.`;
      const request = this.llm.chat({ messages: [
        { role: 'system', content: sys },
        { role: 'user', content: `Mensagem do usuário: "${userText}"\nIntenção: ${intent}\nFatos reais (JSON):\n${JSON.stringify(facts).slice(0, 2500)}\n\nResponda ao usuário com base SÓ nesses fatos.` },
      ], temperature: 0.4 });
      const res = await Promise.race([
        request,
        new Promise((_, reject) => setTimeout(() => reject(new Error('llm response timeout')), 8000)),
      ]);
      return res.text.trim() || fallbackReply;
    } catch {
      return fallbackReply;
    }
  }

  // Interpreta a intenção. Determinístico, auditável.
  detectIntent(text) {
    const t = text.toLowerCase().trim();
    const url = (text.match(GITHUB_URL_RE) || [])[0] || null;

    // "acoplar/pegar TODOS os projetos do meu user/github <username>" → ingestão de portfólio inteiro
    const mentionsAll = /(todos|todas|todo|all|portf[oó]lio|meus? (projetos|repos|reposit))/.test(t);
    const ingestVerb = /(acopl|conect|mape|ingest|integr|import|traz|pega|puxa|busca|carrega|baixa)/.test(t);
    const hasUser = this.extractUsername(text);
    if (mentionsAll && (ingestVerb || hasUser)) {
      return { kind: 'ingest_portfolio', username: hasUser };
    }

    if (url && /(acopl|conect|analis|ingest|adicion|integr)/.test(t)) return { kind: 'connect_repo', url };
    if (url) return { kind: 'connect_repo', url };
    if (/(gerar|ger[ae]|criar|cri[ae]|novo|construir|constr[ou]i|montar|monta|fazer|fa[çc]a).*(sistema|projeto|app|aplica|site|loja|crm|erp|saas|plataforma|marketplace|landing|bot|api)/.test(t)) return { kind: 'generate', prompt: text };
    if (/(insight|aprend|evolu|o que aprend|padr)/.test(t)) return { kind: 'insights' };
    if (/(mem[oó]ria|hist[oó]rico|decis)/.test(t)) return { kind: 'memory' };
    if (/(capabilit|funcionalidad|cat[aá]logo|m[oó]dulo)/.test(t)) return { kind: 'capabilities' };
    if (/(status|vis[aã]o|overview|painel|resumo|estado|funcion|rodando|online|operacional|sa[uú]de)/.test(t)) return { kind: 'overview' };
    if (/(twin|modelo|arquitetura|sa[uú]de|risco|analis[ae] o|conselho|advise|melhor)/.test(t)) {
      const repoId = this.matchRepoId(t);
      return { kind: 'twin', repoId };
    }
    if (/(repos|projetos|lista|quais)/.test(t)) return { kind: 'list' };
    if (/(ajuda|help|o que voc|comandos|pode fazer)/.test(t)) return { kind: 'help', deterministic: true };
    return { kind: 'help' };
  }

  // Classificação operacional de intenções. Sem fabricação de missões.
  classifyRequest(text) {
    const value = String(text || '').trim();
    const t = value.toLowerCase();

    // 1. PROJECT_CONNECT (URL do GitHub ou comando explícito para conectar/acoplar repositório)
    const url = (value.match(GITHUB_URL_RE) || [])[0] || null;
    if (url || /(conectar|conecte|acoplar|acople|importar|importe|vincular|adicione o repo|adicionar repo)\b/.test(t)) {
      return { category: 'PROJECT_CONNECT', requiresConfirmation: false, intent: 'connect_repo', url };
    }

    // 2. PROJECT_ANALYSIS (análise estrutural e arquitetural de projeto)
    if (/(analise meu projeto|analisar meu projeto|analise o projeto|audite meu projeto|diagn[oó]stico do projeto|estrutura do projeto)\b/.test(t)) {
      return { category: 'PROJECT_ANALYSIS', requiresConfirmation: false, intent: 'twin' };
    }

    // 3. STATUS (consulta de telemetria e integridade do runtime)
    if (/^(qual seu status|qual o status|status do sistema|status do runtime|como est[aá] o sistema|sistema est[aá] rodando|overview)\b/.test(t)) {
      return { category: 'STATUS', requiresConfirmation: false, intent: 'overview' };
    }

    // 4. REPAIR (recuperação de falhas e reparo de jobs)
    if (/(repare|corrija o erro|auto repair|consertar falha|repair job)\b/.test(t)) {
      return { category: 'REPAIR', requiresConfirmation: false, intent: 'repair' };
    }

    // 5. CONTINUE (continuação autônoma do DAG da missão)
    if (/^(continue|prossiga|retomar|avance|pr[oó]ximo job|next job)\b/.test(t)) {
      return { category: 'CONTINUE', requiresConfirmation: false, intent: 'continue' };
    }

    // 6. INSPECT (inspeção de logs, métricas ou detalhes de agentes e missões)
    if (/(inspecione|inspecionar|detalhes do agente|detalhes da miss[aã]o|detalhes do job|ver logs|ver diff)\b/.test(t)) {
      return { category: 'INSPECT', requiresConfirmation: false, intent: 'inspect' };
    }

    // 7. CONVERSATION (saudações, esclarecimentos, dúvidas sem alterar código ou criar job)
    const conversation = /^(oi|ol[aá]|bom dia|boa tarde|boa noite|hey|hello)\b/.test(t)
      || /\b(como funciona|o que voc[eê]|consegue|pode explicar|explique|qual sua capacidade|qual [eé] a data|obrigado|valeu)\b/.test(t)
      || (/\?$/.test(value) && !/\b(corrija|adicione|implemente|refatore|construa|crie|altere|mude)\b/.test(t));
    if (conversation) return { category: 'CONVERSATION', requiresConfirmation: false, intent: this.detectIntent(value).kind };

    // 8. SMALL_TASK (tarefa pontual: gera 1 job sem missão pesada)
    const small = /\b(corrij[ae]|mude|troque|adicione um campo|altere o texto|troque a cor|endpoint simples)\b/.test(t)
      && !/\b(inteir[oa]|completo|completa|v[aá]rios|toda|todo|sistema|arquitetura)\b/.test(t);
    if (small) return { category: 'SMALL_TASK', requiresConfirmation: false, intent: this.detectIntent(value).kind };

    // 9. LONG_MISSION (missões amplas que demandam proposta formal e autorização)
    const large = /\b(sistema completo|projeto completo|integre tudo|refatore o sistema|melhore o command center|reconstrua|evolu[cç][aã]o cont[ií]nua|v[aá]rios jobs|dias|full.?stack)\b/.test(t)
      || value.length > 180;
    if (large) return { category: 'LONG_MISSION', requiresConfirmation: true, intent: this.detectIntent(value).kind };

    // 10. CODE_CHANGE (mudança de código explícita que demanda autorização)
    if (/\b(implemente|crie|construa|refatore|melhore|adicione|corrija|mude|altere|teste)\b/.test(t)) {
      return { category: 'CODE_CHANGE', requiresConfirmation: true, intent: this.detectIntent(value).kind };
    }

    return { category: 'CONVERSATION', requiresConfirmation: false, intent: this.detectIntent(value).kind };
  }

  matchRepoId(text) {
    // tenta casar um id de repo conhecido pela substring
    return this._repoHint || null;
  }

  // Extrai username do GitHub de frases como "meu user github biel0071" ou "github.com/biel0071".
  extractUsername(text) {
    const STOP = new Set(['github', 'user', 'usuario', 'usuário', 'conta', 'perfil', 'meu', 'meus', 'do', 'de', 'da', 'no', 'projetos', 'repos', 'todos']);
    const fromUrl = text.match(/github\.com\/([A-Za-z0-9-]+)/i);
    if (fromUrl) return fromUrl[1];
    // token seguido de barra: "biel0071/"
    const slash = text.match(/\b([A-Za-z0-9][A-Za-z0-9-]{1,38})\s*\//);
    if (slash && !STOP.has(slash[1].toLowerCase())) return slash[1];
    // após palavra-chave, pulando stopwords encadeadas (ex.: "user github biel0071")
    const seq = text.match(/(?:user|usu[aá]rio|github|conta|perfil)\s+((?:[A-Za-z0-9][A-Za-z0-9-]{1,38}\s+){0,3}[A-Za-z0-9][A-Za-z0-9-]{1,38})/i);
    if (seq) {
      const token = seq[1].split(/\s+/).find((w) => !STOP.has(w.toLowerCase()));
      if (token) return token;
    }
    return null;
  }

  async handle(tenantId, actorId, text) {
    // 1) tenta regras determinísticas (rápidas, confiáveis para URL/comandos claros)
    let intent = this.detectIntent(text);
    // 2) se o LLM está ligado e as regras caíram em 'help' (baixa confiança), pergunta ao LLM
    if (this.llm && intent.kind === 'help' && !intent.deterministic) {
      const llmIntent = await this.classifyWithLLM(text);
      if (llmIntent) {
        intent = { kind: llmIntent.intent, url: llmIntent.url || intent.url, username: llmIntent.username || null };
      }
    }
    let action = { type: intent.kind, ok: true };
    let facts = {};

    try {
      switch (intent.kind) {
        // `help` NAO tinha case: saía com facts={} e o prompt manda não inventar, então a
        // pergunta mais direta que existe ("o que você pode fazer?") chegava ao modelo sem um
        // único fato. É o caminho default do roteador determinístico (detectIntent devolve
        // 'help' quando nada casa), portanto o mais provável em produção. Recebe os mesmos
        // fatos do chitchat: é a mesma pergunta.
        case 'help':
        case 'chitchat': {
          const state = await this.app.store.read();
          const f = (a) => (a || []).filter((x) => x.tenantId === tenantId).length;
          // MEDIDO EM PRODUCAO (2026-07-29): antes daqui saía apenas `capabilities: 0`, porque
          // `state.capabilities` é uma lista LEGADA que está vazia — o registro real é
          // `capabilityDefinitions` (9 built-ins semeados no tenant). Com só zeros no JSON e a
          // ordem "use APENAS os fatos", o modelo respondia ao usuário "não possuímos
          // capacidades avançadas como pesquisar o repositório" — negando o que o FÊNIX faz.
          // A correção não é escrever uma lista de habilidades à mão (isso seria sinal
          // fabricado): é passar o registro com a saúde que já vem de execução real de job
          // (capability-registry.js:52 recordRuntimeEvent) e deixar claro o que é medido.
          facts = {
            conversa: true,
            repos: f(state.repositories),
            projetos: f(state.projects),
            capacidades: this.#capabilityFacts(state, tenantId),
          };
          break;
        }
        case 'connect_repo': {
          const repo = await this.connectAndAnalyze(tenantId, actorId, intent.url);
          const twin = await this.app.digitalTwin.get(tenantId, actorId, repo.id);
          action = { type: 'connect_repo', ok: true, repoId: repo.id };
          facts = {
            repo: repo.name, revision: twin.revision,
            fileCount: twin.model.architecture.fileCount,
            apis: twin.model.apis.count, components: twin.model.components.count,
            tables: twin.model.database.tables.length,
            capabilities: twin.model.capabilities,
            health: twin.model.health, risks: twin.model.risks,
          };
          break;
        }
        case 'ingest_portfolio': {
          const username = intent.username;
          if (!username) { action = { type: 'ingest_portfolio', ok: false }; facts = { note: 'Não identifiquei o usuário. Diga: "acoplar todos os projetos do github biel0071".' }; break; }
          const report = await this.app.portfolio.ingestUser(tenantId, actorId, username, { analyze: true, maxSizeKb: 400000 });
          action = { type: 'ingest_portfolio', ok: true, username };
          facts = { username, total: report.total, results: report.results };
          break;
        }
        case 'generate': {
          // MISSION-FENIX-ACTIVATION: o chat deixa de executar direto. Um objetivo de
          // construcao vira um PROGRAMA real via Executive Brain, que decompoe em missoes
          // reais (via mission-planner) e as materializa. O usuario ve o programa nascer no
          // chat. Se o Brain nao estiver ligado, cai no orchestrator antigo (compatibilidade).
          if (this.app.executiveBrain) {
            const program = await this.app.executiveBrain.createProgram(tenantId, actorId, text);
            const approved = await this.app.executiveBrain.approve(tenantId, actorId, program.id);
            const status = await this.app.executiveBrain.status(tenantId, actorId, program.id);
            action = { type: 'program', ok: true, programId: program.id };
            facts = {
              programId: program.id,
              objective: program.objective,
              missions: approved.missions.map((m) => ({ key: m.key, mode: m.mode, missionId: m.missionId, status: m.status })),
              materialized: approved.missions.filter((m) => m.missionId).length,
              proposed: approved.missions.length,
              programState: status.state?.value || approved.state,
              progress: status.progress?.state === 'measured' ? status.progress.value : null,
            };
          } else {
            const res = await this.app.orchestrator.buildFromPrompt(tenantId, actorId, { prompt: text, name: text.slice(0, 40), target: 'node' });
            action = { type: 'generate', ok: true, projectId: res.projectId };
            facts = { projectId: res.projectId, reused: res.reused, built: res.built, previewUrl: res.previewUrl, outputPath: res.outputPath };
          }
          break;
        }
        case 'insights': {
          const insights = await this.app.evolution.getInsights(tenantId);
          facts = { insights: insights.slice(0, 12).map((i) => ({ type: i.type, summary: i.summary, confidence: i.confidence })) };
          break;
        }
        case 'memory': {
          const state = await this.app.store.read();
          facts = { memory: state.memoryEvents.filter((m) => m.tenantId === tenantId).slice(-10).reverse().map((m) => ({ kind: m.kind, summary: m.summary })) };
          break;
        }
        case 'capabilities': {
          const state = await this.app.store.read();
          // `state.capabilities` (legado) está vazio em produção; o registro real é
          // capabilityDefinitions. Mantenho o campo antigo para não quebrar quem o lê, mas a
          // resposta ao usuário passa a vir do registro com saúde medida.
          facts = {
            capabilities: (state.capabilities || []).filter((c) => c.tenantId === tenantId).map((c) => `${c.id}@${c.version}`),
            capacidades: this.#capabilityFacts(state, tenantId),
          };
          break;
        }
        case 'twin': {
          const repos = await this.app.repoIntel.listRepositories(tenantId, actorId);
          const repo = intent.repoId ? repos.find((r) => r.id === intent.repoId) : repos[repos.length - 1];
          if (!repo) {
            try {
              const { scanProject } = require('../project-mirror/scanner');
              const mirror = await scanProject(this.app.workspaceRoot || process.cwd());
              action = { type: 'project_analysis', ok: true, projectId: mirror.projectId };
              facts = {
                project: mirror.name,
                path: mirror.path,
                fileCount: mirror.files.total,
                apis: mirror.apis.length,
                tests: mirror.tests.count,
                git: mirror.git,
                tech: mirror.tech,
                dependencies: mirror.dependencies.count,
                mirror,
              };
              await this.app.store.update((s) => {
                s.projects = s.projects || [];
                const idx = s.projects.findIndex((p) => p.id === mirror.projectId || p.name === mirror.name);
                const projObj = {
                  id: mirror.projectId,
                  name: mirror.name,
                  tenantId,
                  path: mirror.path,
                  tech: mirror.tech,
                  files: mirror.files.total,
                  apis: mirror.apis.length,
                  tests: mirror.tests.count,
                  git: mirror.git,
                  updatedAt: new Date().toISOString(),
                };
                if (idx >= 0) s.projects[idx] = { ...s.projects[idx], ...projObj };
                else s.projects.push(projObj);
                return s;
              });
            } catch (err) {
              facts = { note: `Nenhum repo conectado ainda (${err.message}). Cole uma URL do GitHub para começar.` };
            }
            break;
          }
          const advice = await this.app.digitalTwin.advise(tenantId, actorId, repo.id);
          const twin = await this.app.digitalTwin.get(tenantId, actorId, repo.id);
          facts = { repo: repo.name, health: advice.health, advice: advice.advice, capabilities: twin.model.capabilities };
          break;
        }
        case 'list': {
          const repos = await this.app.repoIntel.listRepositories(tenantId, actorId);
          const projects = await this.app.factory.listProjects(tenantId, actorId);
          facts = { repos: repos.map((r) => r.id), projects: projects.map((p) => p.id) };
          break;
        }
        case 'overview': {
          const state = await this.app.store.read();
          const f = (a) => a.filter((x) => x.tenantId === tenantId).length;
          let health = null;
          try {
            health = this.app.health?.check ? await this.app.health.check() : null;
          } catch (error) {
            health = { ok: false, status: 'degraded', checks: {}, error: error.message };
          }
          const checks = Object.entries(health?.checks || {});
          facts = {
            status: health?.status || 'unknown',
            ok: health?.ok === true,
            degraded: checks
              .filter(([, detail]) => detail?.ok === false)
              .map(([name, detail]) => ({ name, critical: detail.critical === true, reason: detail.degraded || detail.error || detail.reason || 'falha reportada' })),
            repos: f(state.repositories),
            projects: f(state.projects),
            capabilities: f(state.capabilities),
            registeredCapabilities: f(state.capabilityDefinitions || []),
            deployments: f(state.deployments),
            insights: f(state.insights),
            memory: f(state.memoryEvents),
          };
          break;
        }
        default:
          facts = { help: [
            'Cole uma URL do GitHub para acoplar e analisar um repo',
            '"gerar um CRM de WhatsApp com IA" para criar um sistema',
            '"o que você aprendeu?" para ver insights evolutivos',
            '"status" para a visão geral', '"capabilities" para o catálogo',
            '"analise o twin" para saúde/riscos/conselhos de um repo',
          ] };
      }
    } catch (e) {
      action = { type: intent.kind, ok: false, error: e.message };
      facts = { error: e.message };
    }

    // resposta determinística (fallback) — para ações concretas mantemos o texto exato/estruturado.
    const structured = this.render(intent.kind, facts, action);
    // Para intents de AÇÃO concreta, usamos o texto estruturado (dados exatos: caminhos, URLs).
    // Para conversa/consulta, deixamos o LLM redigir natural a partir dos fatos reais.
    const CONVERSATIONAL = new Set(['chitchat', 'help', 'insights', 'overview', 'capabilities', 'memory', 'list', 'twin']);
    let reply = structured;
    if (this.llm && CONVERSATIONAL.has(intent.kind)) {
      reply = await this.speak(text, intent.kind, facts, structured);
    }
    if (intent.kind === 'help' && !/Cole uma URL/i.test(reply)) {
      reply = `${reply}\n\nCole uma URL do GitHub para eu acoplar e analisar o projeto, ou descreva uma mudança para criar uma missão executável.`;
    }
    // memória progressiva de conversa
    this.history.push({ role: 'user', content: text }, { role: 'assistant', content: reply });
    if (this.history.length > 12) this.history = this.history.slice(-12);

    await this.recordTurn(tenantId, actorId, text, intent.kind, action);
    return { intent: intent.kind, action, facts, reply, llm: !!this.llm };
  }

  async connectAndAnalyze(tenantId, actorId, url) {
    let repo;
    try {
      repo = await this.app.repoIntel.connect(tenantId, actorId, { url, visibility: 'public' });
    } catch (e) {
      if (/already connected/i.test(e.message)) {
        const list = await this.app.repoIntel.listRepositories(tenantId, actorId);
        repo = list.find((r) => r.url.toLowerCase() === url.toLowerCase().replace(/\.git$/, ''));
      } else throw e;
    }
    await this.app.repoIntel.analyze(tenantId, actorId, repo.id);
    return repo;
  }

  async recordTurn(tenantId, actorId, text, intent, action) {
    try {
      const state = await this.app.store.read();
      // usa a memória via store direto (evita exigir permissão de escrita p/ chat de leitura)
      await this.app.store.update((s) => {
        s.memoryEvents.push({
          id: require('../kernel/ids').uuid(), tenantId, projectId: action.repoId || action.projectId || null,
          actorId: 'chat-agent', kind: `chat:${intent}`,
          summary: `Usuário: "${text.slice(0, 80)}" → ${action.ok ? 'ok' : 'falha'}`,
          evidence: [`intent:${intent}`], confidence: 0.5, createdAt: new Date().toISOString(),
        });
        return s;
      });
    } catch { /* chat não deve quebrar por falha de log */ }
  }

  // Redige a resposta natural. (Com LLM real, passaria facts+intent ao gateway; aqui formata direto.)
  render(kind, facts, action) {
    if (facts.error) return `Tive um problema: ${facts.error}`;
    switch (kind) {
      case 'ingest_portfolio': {
        if (facts.note) return facts.note;
        const lines = facts.results.map((r) => {
          if (r.status === 'analyzed') return `✓ ${r.name} — ${r.fileCount} arq, caps: ${(r.capabilities || []).join(', ') || 'nenhuma'}`;
          if (r.status === 'skipped-empty') return `· ${r.name} — vazio (ignorado)`;
          if (r.status === 'skipped-too-large') return `· ${r.name} — grande demais (ignorado)`;
          if (r.status === 'error') return `✗ ${r.name} — erro: ${r.error}`;
          return `· ${r.name} — ${r.status}`;
        });
        const analyzed = facts.results.filter((r) => r.status === 'analyzed').length;
        return `Acoplei o portfólio de **${facts.username}** — ${facts.total} repos, ${analyzed} analisados:\n${lines.join('\n')}`;
      }
      case 'connect_repo':
        return `Acoplei e analisei **${facts.repo}** (${facts.revision?.slice(0, 8)}).\n` +
          `• ${facts.fileCount} arquivos, ${facts.apis} APIs, ${facts.components} componentes, ${facts.tables} tabelas\n` +
          `• Capabilities: ${facts.capabilities.join(', ')}\n` +
          `• Saúde: ${facts.health.score}/100 (mais fraco: ${facts.health.weakest})` +
          (facts.risks.length ? `\n• Riscos: ${facts.risks.join('; ')}` : '');
      case 'generate':
        // Fluxo novo: Programa real via Executive Brain. Os numeros sao CONTADOS das missoes
        // reais materializadas, nunca inventados ("6 missoes", nao "27").
        if (facts.programId) {
          const lines = facts.missions.map((m) => {
            const mark = m.missionId ? '✓' : '·';
            return `${mark} ${m.key} [${m.mode}] — ${m.missionId ? `missão ${m.missionId.slice(0, 8)} (${m.status})` : m.status}`;
          });
          return `**Programa criado** para: ${facts.objective}\n` +
            `Estado: ${facts.programState} · ${facts.materialized}/${facts.proposed} missões materializadas` +
            (facts.progress !== null ? ` · progresso ${facts.progress}%` : ' · progresso ainda não medido') +
            `\n${lines.join('\n')}\n\n` +
            `As missões são reais e executam pelo runtime (Router → Gateway → providers). ` +
            `Acompanhe o progresso pelo painel de missões. Nota honesta: "materializada" significa ` +
            `plano criado e enfileirado — o produto final depende da execução dos jobs, não está pronto ainda.`;
        }
        return `Gerei o projeto **${facts.projectId}** — arquivos reais escritos em disco.\n` +
          (facts.outputPath ? `• Pasta: ${facts.outputPath}\n` : '') +
          `• Rode: cd "${facts.outputPath || facts.projectId}" && node src/index.js\n` +
          `• Reutilizou: ${facts.reused.join(', ') || 'nada (catálogo vazio — acople repos antes)'}\n` +
          `• Criou novo: ${facts.built.join(', ') || 'nada'}\n` +
          `• Preview: ${facts.previewUrl}`;
      case 'insights':
        return facts.insights.length
          ? 'O que aprendi até agora:\n' + facts.insights.map((i) => `• [${i.type}] ${i.summary}`).join('\n')
          : 'Ainda não aprendi nada — acople alguns repos para eu começar a evoluir.';
      case 'memory':
        return facts.memory.length ? 'Memória recente:\n' + facts.memory.map((m) => `• ${m.summary}`).join('\n') : 'Memória vazia.';
      case 'capabilities':
        return facts.capabilities.length ? `Catálogo (${facts.capabilities.length}): ${facts.capabilities.join(', ')}` : 'Catálogo vazio — acople repos para popular.';
      case 'twin':
      case 'project_analysis':
        if (facts.mirror) {
          return `Análise do Projeto **${facts.project}** concluída com sucesso:\n` +
            `• Localização: \`${facts.path}\`\n` +
            `• Tecnologias: Frontend: ${facts.tech?.frontend || 'HTML/JS Vanilla'} · Backend: ${facts.tech?.backend || 'Node.js Core'}\n` +
            `• Arquivos: ${facts.fileCount} arquivos mapeados (${facts.dependencies} dependências)\n` +
            `• APIs detectadas: ${facts.apis} rotas/endpoints\n` +
            `• Testes: ${facts.tests} arquivos de teste\n` +
            `• Git: branch \`${facts.git?.branch || 'main'}\` (${facts.git?.isClean ? 'limpo' : 'alterações pendentes'})\n` +
            `• Contexto operacional registrado na memória do Fênix.`;
        }
        if (facts.note) return facts.note;
        return `Twin de **${facts.repo}** — saúde ${facts.health.score}/100.\n` +
          `Capabilities: ${facts.capabilities.join(', ')}\n` +
          `Conselhos:\n${facts.advice.map((a) => `• ${a}`).join('\n')}`;
      case 'list':
        return `Repos: ${facts.repos.join(', ') || 'nenhum'}\nProjetos: ${facts.projects.join(', ') || 'nenhum'}`;
      case 'overview':
        return `Visão geral: sistema ${facts.ok ? 'funcionando' : 'com atenção'} (${facts.status || 'unknown'}). ` +
          `${facts.repos} repos, ${facts.projects} projetos, ${facts.registeredCapabilities ?? facts.capabilities} capacidades registradas, ` +
          `${facts.deployments} deploys, ${facts.insights} insights, ${facts.memory} eventos de memória.` +
          (facts.degraded?.length ? ` Pontos degradados: ${facts.degraded.map((item) => `${item.name}${item.critical ? ' crítico' : ''}: ${item.reason}`).join('; ')}.` : '');
      case 'chitchat': {
        // Fallback sem LLM. Cita o numero REGISTRADO de capacidades (nao uma lista fixa) para
        // que nem o caminho determinístico possa afirmar menos do que a plataforma tem.
        const n = facts.capacidades?.registradas || 0;
        return `Tô por aqui. Você tem ${facts.repos || 0} repos e ${facts.projetos || 0} projetos no sistema`
          + `${n ? `, e ${n} capacidades registradas` : ''}. Posso acoplar um repositório, gerar um sistema ou te mostrar o que aprendi.`;
      }
      default: {
        const help = Array.isArray(facts.help) ? facts.help : [
          'Cole uma URL do GitHub para acoplar e analisar um repo',
          '"gerar um sistema..." para criar um projeto',
          '"o que você aprendeu?" para insights', '"status" para a visão geral',
        ];
        return 'Posso:\n' + help.map((h) => `• ${h}`).join('\n');
      }
    }
  }
}

module.exports = { ChatAgent };
