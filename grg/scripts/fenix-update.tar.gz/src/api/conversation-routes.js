'use strict';
/**
 * FÊNIX OS V8.2 — Conversation & Intelligent Dual-Lane Routes
 * Dispatches Fast Lane vs Job Lane requests, handles interactive model switching,
 * queue controls, and delivers real runtime model & token telemetry.
 */

var { classify, setConfirmationMode, getConfirmationMode, CONFIRMATION_MODES } = require('../routing/conversation-router');
var { enhance } = require('../execution/prompt-enhancer');
var { selectModelForTask, setSelectorMode, getSelectorMode, getProviderStatus, getTokenReport, parseNaturalLanguageModelCommand } = require('../routing/model-router');
var { globalJobQueueManager, JOB_STATUSES } = require('../execution/job-queue-manager');
var { handle: handleFastLane } = require('../execution/fast-lane-engine');

function getProjectContext(projectId) {
  try {
    var registry = require('../projects/project-registry');
    var p = registry.getProjectById(projectId);
    if (!p) return '';
    return 'Project: ' + p.name + ' (' + p.vpsPath + ') | Services: ' + (p.services || []).join(', ');
  } catch (e) {
    return '';
  }
}

async function handleConversationRoutes(req, res, url, sendJson, readJson, identity, app) {
  if (!url) {
    try { url = new URL(req.url, 'http://127.0.0.1:4400'); } catch (_) { url = { pathname: req.url || '/' }; }
  }
  if (typeof sendJson !== 'function') {
    sendJson = function(res, code, data) {
      if (!res.headersSent) res.writeHead(code, { 'content-type': 'application/json' });
      res.end(JSON.stringify(data));
    };
  }
  if (typeof readJson !== 'function') {
    readJson = async function(req) {
      var body = '';
      for await (var chunk of req) body += chunk;
      return body ? JSON.parse(body) : {};
    };
  }
  var pathname = url.pathname;
  var method = req.method;
  var actorId = (identity && identity.actorId) || 'grg-admin';
  var tenantId = (identity && identity.tenantId) || 'grg';

  // 1. POST /api/v2/conversation — Main Dual-Lane Entrypoint
  if (method === 'POST' && pathname === '/api/v2/conversation') {
    var reqStart = Date.now();
    var body = await readJson(req).catch(function() { return {}; });
    var rawMessage = String(body.message || '').trim();
    if (!rawMessage) {
      sendJson(res, 400, { ok: false, error: 'message is required' });
      return true;
    }

    var lower = rawMessage.toLowerCase();

    // 1.1 Natural Language Model Switching Command
    var nlModel = parseNaturalLanguageModelCommand(rawMessage);
    if (nlModel.handled) {
      sendJson(res, 200, {
        ok: true,
        lane: 'FAST_LANE',
        response: nlModel.response,
        currentMode: getSelectorMode(),
        isCommand: true,
        latencyMs: Date.now() - reqStart,
        actions: [
          { type: 'send_command', command: '/fast', label: '⚡ FAST' },
          { type: 'send_command', command: '/qwen', label: '🧠 QWEN' },
          { type: 'send_command', command: '/auto', label: '🤖 AUTO' }
        ],
        tokens: Math.ceil((rawMessage.length + nlModel.response.length) / 4),
        timestamp: new Date().toISOString()
      });
      return true;
    }

    // 1.2 Natural Language Confirmation Policy Switching
    if (lower.indexOf('não precisa confirmar') >= 0 || lower.indexOf('nao precisa confirmar') >= 0 || lower.indexOf('sem confirmação') >= 0) {
      setConfirmationMode(CONFIRMATION_MODES.NEVER);
      sendJson(res, 200, {
        ok: true,
        lane: 'FAST_LANE',
        response: '🔓 Política de confirmação configurada para `NEVER`: tarefas permitidas serão enfileiradas automaticamente.',
        confirmationMode: getConfirmationMode(),
        latencyMs: Date.now() - reqStart,
        timestamp: new Date().toISOString()
      });
      return true;
    }
    if (lower.indexOf('me pergunta antes de alterar') >= 0 || lower.indexOf('sempre confirme') >= 0 || lower.indexOf('peça confirmação') >= 0) {
      setConfirmationMode(CONFIRMATION_MODES.ALWAYS);
      sendJson(res, 200, {
        ok: true,
        lane: 'FAST_LANE',
        response: '🔒 Política de confirmação configurada para `ALWAYS`: qualquer tarefa exigirá aprovação prévia.',
        confirmationMode: getConfirmationMode(),
        latencyMs: Date.now() - reqStart,
        timestamp: new Date().toISOString()
      });
      return true;
    }
    if (lower.indexOf('confirmação inteligente') >= 0 || lower.indexOf('modo smart') >= 0) {
      setConfirmationMode(CONFIRMATION_MODES.SMART);
      sendJson(res, 200, {
        ok: true,
        lane: 'FAST_LANE',
        response: '🧠 Política de confirmação configurada para `SMART`: leitura e análises entram na fila automaticamente; alterações de código exigem confirmação.',
        confirmationMode: getConfirmationMode(),
        latencyMs: Date.now() - reqStart,
        timestamp: new Date().toISOString()
      });
      return true;
    }

    // 1.3 Natural Language Queue Confirmations
    if (lower === 'coloca na fila' || lower === 'colocar na fila' || lower === 'enfileirar' || lower === 'pode executar' || lower === 'confirme' || lower === 'confirmar' || lower === 'sim') {
      var pending = globalJobQueueManager.listJobs({ status: 'PENDING_CONFIRMATION' })[0];
      if (pending) {
        await globalJobQueueManager.confirmJob(pending.id, actorId);
        if (app && app.jobs && typeof app.jobs.submit === 'function') {
          try {
            await app.jobs.submit(tenantId, actorId, {
              type: 'development.execute',
              title: pending.title,
              payload: { prompt: pending.rawPrompt || pending.title, jobId: pending.id },
              source: 'dual-lane-confirm'
            });
          } catch (_) {}
        }
        sendJson(res, 200, {
          ok: true,
          lane: 'JOB_LANE',
          response: '▶ **Job #' + pending.id + '** (' + pending.title + ') confirmado e enviado para o worker BullMQ!\n\n[⚡ FAST] [🧠 QWEN] [🤖 AUTO]',
          job: pending,
          latencyMs: Date.now() - reqStart,
          actions: [
            { type: 'switch_view', view: 'view-operations', label: '📋 Ver Fila BullMQ' },
            { type: 'send_command', command: '/fast', label: '⚡ FAST' },
            { type: 'send_command', command: '/qwen', label: '🧠 QWEN' }
          ],
          timestamp: new Date().toISOString()
        });
        return true;
      }
    }

    // 1.3.1 Natural Language Project Awareness (V8.3)
    if (lower.indexOf('mostra meus projetos') >= 0 || lower.indexOf('quais projetos existem') >= 0 || lower.indexOf('listar projetos') >= 0 || lower === 'projetos') {
      var registry = require('../projects/project-registry');
      var allP = await registry.getAllProjects();
      var pList = allP.map(function(p) {
        return '• **' + (p.name || p.id) + '** (' + p.id + ') — [' + (p.status || 'ONLINE') + ']\n  ' + (p.description || '') + '\n  Branch: `' + (p.branch || 'main') + '` | Stack: ' + (p.frontend ? p.frontend.framework : 'N/A');
      }).join('\n\n');
      sendJson(res, 200, {
        ok: true,
        lane: 'FAST_LANE',
        response: '🏢 **Ecossistema de Projetos Gerenciados pelo FÊNIX:**\n\n' + pList,
        projects: allP,
        latencyMs: Date.now() - reqStart,
        actions: [
          { type: 'switch_view', view: 'view-projects', label: '🏢 Abrir Projetos' },
          { type: 'open_ide_project', projectId: 'api-platform-live', label: '📂 IDE API Platform' }
        ],
        tokens: 150,
        timestamp: new Date().toISOString()
      });
      return true;
    }

    if (lower.indexOf('abre o zapai') >= 0 || lower.indexOf('mostra o zapai') >= 0 || lower.indexOf('status do zapai') >= 0 || lower === 'zapai') {
      var registry = require('../projects/project-registry');
      var pageReg = require('../projects/page-registry');
      var zapai = registry.getProjectById('zapai-crm');
      var zapPages = pageReg.getAllPages('zapai-crm');
      var zapResp = '📱 **ZapAI CRM — Status Operacional:**\n' +
        '• Status: `ONLINE` (PM2 id 0: zapflow-api na porta 4025)\n' +
        '• Repositório: `Biel0071/ZAPAI-FINAL` (branch: `' + (zapai.branch || 'main') + '`)\n' +
        '• Frontend: React 18 + Vite + TypeScript + Tailwind CSS (' + zapPages.length + ' telas registradas)\n' +
        '• Telas principais: `/inbox`, `/dashboard`, `/contacts`, `/campaigns`, `/connections`, `/flows`\n' +
        '• Testes: Playwright UI suite (`hardening-stress.spec.ts`)';
      sendJson(res, 200, {
        ok: true,
        lane: 'FAST_LANE',
        response: zapResp,
        project: zapai,
        pages: zapPages,
        latencyMs: Date.now() - reqStart,
        actions: [
          { type: 'open_ide_project', projectId: 'zapai-crm', label: '📂 Abrir ZapAI no IDE' },
          { type: 'switch_view', view: 'view-projects', label: '📱 Ver Telas ZapAI' }
        ],
        tokens: 120,
        timestamp: new Date().toISOString()
      });
      return true;
    }

    if (lower.indexOf('abre o api platform') >= 0 || lower.indexOf('mostra o api platform') >= 0 || lower === 'api platform') {
      var registry = require('../projects/project-registry');
      var ap = registry.getProjectById('api-platform');
      var apResp = '🤖 **API Platform — Status Operacional:**\n' +
        '• Status: `ONLINE` (Docker container `api-platform-api-1` na porta 3001)\n' +
        '• Dashboard: Porta 8081 (`api-platform-dashboard-1`)\n' +
        '• Repositório: `Biel0071/API-PLATAFORM` (branch: `' + (ap.branch || 'main') + '`)\n' +
        '• Stack: Fastify + TypeScript + Prisma ORM + BullMQ\n' +
        '• Provedores: Qwen 2.5 (3B), Ollama, BullMQ Image Workers';
      sendJson(res, 200, {
        ok: true,
        lane: 'FAST_LANE',
        response: apResp,
        project: ap,
        latencyMs: Date.now() - reqStart,
        actions: [
          { type: 'open_ide_project', projectId: 'api-platform-live', label: '📂 Abrir no IDE' },
          { type: 'switch_view', view: 'view-projects', label: '🤖 Detalhes do Projeto' }
        ],
        tokens: 110,
        timestamp: new Date().toISOString()
      });
      return true;
    }

    if (lower.indexOf('mostra todas as telas') >= 0 || lower.indexOf('quais telas existem') >= 0 || lower.indexOf('mostra as telas') >= 0 || lower === 'telas') {
      var pageReg = require('../projects/page-registry');
      var allPages = pageReg.getAllPages();
      var pagesByProj = {};
      allPages.forEach(function(p) {
        pagesByProj[p.project] = pagesByProj[p.project] || [];
        pagesByProj[p.project].push('`' + p.route + '` (' + p.title + ')');
      });
      var pageTxt = Object.keys(pagesByProj).map(function(proj) {
        return '**' + proj.toUpperCase() + '**:\n' + pagesByProj[proj].join('\n');
      }).join('\n\n');
      sendJson(res, 200, {
        ok: true,
        lane: 'FAST_LANE',
        response: '🖥️ **Telas Mapeadas no Page Registry Universal:**\n\n' + pageTxt,
        total: allPages.length,
        latencyMs: Date.now() - reqStart,
        actions: [
          { type: 'switch_view', view: 'view-projects', label: '🖥️ Central de Telas' }
        ],
        tokens: 180,
        timestamp: new Date().toISOString()
      });
      return true;
    }

    if (lower.indexOf('o que você aprendeu') >= 0 || lower.indexOf('o que voce aprendeu') >= 0 || lower.indexOf('aprendizados') >= 0 || lower === 'conhecimento') {
      var { globalGraphBrain } = require('../brain/graph-brain');
      var patterns = globalGraphBrain.findPatterns();
      var patTxt = patterns.map(function(p) {
        return '• **' + (p.properties.title || p.id) + '**\n  ' + (p.properties.solution || p.properties.principle || '');
      }).join('\n\n');
      sendJson(res, 200, {
        ok: true,
        lane: 'FAST_LANE',
        response: '🧠 **Graph Brain — Padrões e Aprendizados Consolidados:**\n\n' + (patTxt || 'Nenhum padrão registrado ainda.'),
        patterns: patterns,
        latencyMs: Date.now() - reqStart,
        actions: [
          { type: 'switch_view', view: 'view-knowledge', label: '🧠 Graph Brain' }
        ],
        tokens: 130,
        timestamp: new Date().toISOString()
      });
      return true;
    }

    if (lower.indexOf('componentes podem ser reutilizados') >= 0 || lower.indexOf('reutilizar componentes') >= 0 || lower.indexOf('reutiliza aquela') >= 0) {
      var compReg = require('../projects/component-registry');
      var comps = compReg.COMPONENTS;
      var cTxt = comps.map(function(c) {
        return '• **' + c.name + '** [' + c.category + '] (Origem: ' + c.project + ')\n  Stack: ' + c.stack + '\n  Comportamento: ' + c.behavior;
      }).join('\n\n');
      sendJson(res, 200, {
        ok: true,
        lane: 'FAST_LANE',
        response: '🧩 **Component Registry — Catálogo de Reutilização Cross-Project:**\n\n' + cTxt,
        components: comps,
        latencyMs: Date.now() - reqStart,
        actions: [
          { type: 'switch_view', view: 'view-projects', label: '🧩 Componentes' }
        ],
        tokens: 160,
        timestamp: new Date().toISOString()
      });
      return true;
    }

    // 1.4 Handle Slash Commands
    if (rawMessage.startsWith('/')) {
      var parts = rawMessage.slice(1).split(/\s+/);
      var cmd = parts[0].toLowerCase();
      var arg = parts[1] ? parts[1].toLowerCase() : '';

      if (cmd === 'fast') {
        setSelectorMode('FAST');
        sendJson(res, 200, { ok: true, lane: 'FAST_LANE', response: '⚡ Modo FAST ativado. Priorizando velocidade máxima com IA rápida.' });
        return true;
      }
      if (cmd === 'auto') {
        setSelectorMode('AUTO');
        sendJson(res, 200, { ok: true, lane: 'FAST_LANE', response: '🤖 Modo AUTO ativado. O Fênix escolherá o modelo conforme a complexidade.' });
        return true;
      }
      if (cmd === 'qwen') {
        setSelectorMode('QWEN');
        sendJson(res, 200, { ok: true, lane: 'FAST_LANE', response: '🧠 Modo QWEN ativado para raciocínio profundo e engenharia.' });
        return true;
      }
      if (cmd === 'model') {
        if (arg) setSelectorMode(arg);
        sendJson(res, 200, { ok: true, lane: 'FAST_LANE', response: 'Modelo configurado para: `' + getSelectorMode() + '`.' });
        return true;
      }
      if (cmd === 'confirm') {
        if (arg === 'always') setConfirmationMode(CONFIRMATION_MODES.ALWAYS);
        else if (arg === 'never') setConfirmationMode(CONFIRMATION_MODES.NEVER);
        else if (arg === 'smart') setConfirmationMode(CONFIRMATION_MODES.SMART);
        sendJson(res, 200, { ok: true, lane: 'FAST_LANE', response: 'Política de confirmação: `' + getConfirmationMode() + '`.' });
        return true;
      }
      if (cmd === 'queue') {
        if (arg === 'pause' || arg === 'off') {
          await globalJobQueueManager.pauseQueue();
          sendJson(res, 200, { ok: true, lane: 'FAST_LANE', response: '⏸ Fila de jobs pausada.' });
          return true;
        }
        if (arg === 'resume' || arg === 'on') {
          await globalJobQueueManager.resumeQueue();
          sendJson(res, 200, { ok: true, lane: 'FAST_LANE', response: '▶ Fila de jobs retomada.' });
          return true;
        }
        var qStatus = globalJobQueueManager.getQueueStatus();
        sendJson(res, 200, { ok: true, lane: 'FAST_LANE', response: '⚙ Status da Fila: ' + JSON.stringify(qStatus) });
        return true;
      }
      if (cmd === 'jobs') {
        var jList = globalJobQueueManager.listJobs().slice(0, 5);
        var txt = jList.length ? jList.map(function(j) { return '#' + j.id + ' [' + j.status + '] ' + j.title; }).join('\n') : 'Fila vazia.';
        sendJson(res, 200, { ok: true, lane: 'FAST_LANE', response: '📋 Jobs:\n' + txt });
        return true;
      }
      if (cmd === 'job') {
        if (arg === 'retry' && parts[2]) {
          try {
            var ret = await globalJobQueueManager.retryJob(parts[2]);
            sendJson(res, 200, { ok: true, lane: 'FAST_LANE', response: '🔄 Job #' + ret.id + ' recolocado na fila.' });
          } catch (e) {
            sendJson(res, 200, { ok: false, lane: 'FAST_LANE', response: '❌ Erro ao retentar job: ' + e.message });
          }
          return true;
        }
        if (arg === 'cancel' && parts[2]) {
          try {
            var canc = await globalJobQueueManager.cancelJob(parts[2]);
            sendJson(res, 200, { ok: true, lane: 'FAST_LANE', response: '🛑 Job #' + canc.id + ' cancelado.' });
          } catch (e) {
            sendJson(res, 200, { ok: false, lane: 'FAST_LANE', response: '❌ Erro ao cancelar job: ' + e.message });
          }
          return true;
        }
        var targetId = arg || parts[1];
        if (targetId) {
          var sJob = globalJobQueueManager.getJob(targetId);
          if (sJob) {
            sendJson(res, 200, {
              ok: true,
              lane: 'FAST_LANE',
              response: '📋 **Job #' + sJob.id + '** [' + sJob.status + ']\n• Título: ' + sJob.title + '\n• Projeto: ' + sJob.projectId + '\n• Modelo: ' + sJob.model + '\n• Tokens: Est ~' + (sJob.tokens ? sJob.tokens.estimated : 0) + ' | Real: ' + (sJob.tokens ? sJob.tokens.actual : 0) + (sJob.result ? '\n• Resultado: ' + sJob.result.slice(0, 150) + '...' : '')
            });
          } else {
            sendJson(res, 200, { ok: false, lane: 'FAST_LANE', response: 'Job #' + targetId + ' não encontrado.' });
          }
          return true;
        }
      }
      if (cmd === 'tokens') {
        var tk = getTokenReport();
        sendJson(res, 200, { ok: true, lane: 'FAST_LANE', response: '📊 Tokens: Total ' + tk.totalActualTokens + ' (Fast: ' + tk.fastLaneTokens + ' | Jobs: ' + tk.jobLaneTokens + ')' });
        return true;
      }
      if (cmd === 'models' || cmd === 'providers') {
        var pv = getProviderStatus();
        sendJson(res, 200, { ok: true, lane: 'FAST_LANE', response: 'Providers:\n' + pv.map(function(p) { return p.name + ': ' + p.status + ' (' + p.model + ')'; }).join('\n') });
        return true;
      }
    }

    // Step 1: Classify message
    var classification = classify(rawMessage, { confirmationMode: body.confirmationMode || getConfirmationMode() });

    // Step 2: Route according to Lane
    if (classification.lane === 'FAST_LANE') {
      var fastResult = await handleFastLane(rawMessage, classification, { actorId: actorId });
      var fastActions = [
        { type: 'send_command', command: '/fast', label: '⚡ FAST' },
        { type: 'send_command', command: '/qwen', label: '🧠 QWEN' },
        { type: 'send_command', command: '/auto', label: '🤖 AUTO' }
      ];
      if (lower.indexOf('projeto') >= 0 || lower.indexOf('ide') >= 0) {
        fastActions.unshift({ type: 'switch_view', view: 'view-projects', label: '🏢 Projetos' });
        fastActions.unshift({ type: 'open_ide_project', projectId: 'api-platform-live', label: '📂 Abrir IDE' });
      } else if (lower.indexOf('cidade') >= 0 || lower.indexOf('city') >= 0) {
        fastActions.unshift({ type: 'switch_view', view: 'view-city', label: '🏙️ Cidade IA' });
      } else if (lower.indexOf('agente') >= 0) {
        fastActions.unshift({ type: 'switch_view', view: 'view-agents', label: '👥 Agentes' });
      }
      sendJson(res, 200, {
        ok: true,
        lane: 'FAST_LANE',
        response: fastResult.response,
        classification: classification,
        latencyMs: fastResult.latencyMs || (Date.now() - reqStart),
        tokens: fastResult.tokens,
        model: fastResult.model,
        provider: fastResult.provider,
        usedAI: fastResult.usedAI,
        actions: fastActions,
        timestamp: new Date().toISOString()
      });
      return true;
    }

    // Step 3: JOB LANE Execution Flow with Multi-Layer Enhanced Prompt
    var enhanced = enhance(rawMessage, classification, {
      conversationContext: body.conversationContext || null,
      projectId: classification.targetProject
    });
    var selectedModel = selectModelForTask(classification);

    var jobTitle = enhanced.objective.length > 50 ? enhanced.objective.slice(0, 47) + '...' : enhanced.objective;
    if (classification.classification === 'ANALYSIS') {
      jobTitle = 'Analisar ' + enhanced.projectName;
    } else if (classification.classification === 'CODE_CHANGE') {
      jobTitle = 'Alterar código em ' + enhanced.projectName;
    }

    var requiresConf = classification.requires_confirmation;

    var newJob = globalJobQueueManager.createJob({
      title: jobTitle,
      type: classification.classification.toLowerCase(),
      projectId: enhanced.projectId,
      agentId: 'Gabriel',
      agentName: 'Agente Gabriel',
      model: selectedModel.model,
      provider: selectedModel.provider,
      priority: body.priority || 'NORMAL',
      estimatedTokens: classification.estimated_tokens,
      estimatedTimeSec: classification.estimated_time,
      requiresConfirmation: requiresConf,
      rawPrompt: rawMessage,
      enhancedPrompt: enhanced.formattedPrompt,
      objective: enhanced.objective,
      scope: enhanced.scope
    });

    if (!requiresConf && app && app.jobs && typeof app.jobs.submit === 'function') {
      try {
        await app.jobs.submit(tenantId, actorId, {
          type: classification.classification === 'CODE_CHANGE' ? 'development.execute' : 'analysis.inspect',
          title: jobTitle,
          payload: { prompt: rawMessage, projectId: enhanced.projectId, model: selectedModel.model, jobId: newJob.id },
          source: 'dual-lane-chat'
        });
      } catch (_) {}
    }

    var responseText = '';
    var interactiveActions = [
      { type: 'send_command', command: '/fast', label: '⚡ FAST' },
      { type: 'send_command', command: '/qwen', label: '🧠 QWEN' },
      { type: 'send_command', command: '/auto', label: '🤖 AUTO' }
    ];

    if (requiresConf) {
      interactiveActions.unshift({ type: 'confirm_job', jobId: newJob.id, label: '▶ Confirmar e Iniciar' });
      responseText = 'Posso fazer pela Fast Lane ou criar um Job estruturado.\n\n' +
        'Preparei a tarefa:\n' +
        '**' + jobTitle + '**\n\n' +
        '• **Projeto:** ' + enhanced.projectName + '\n' +
        '• **Modelo:** ' + selectedModel.model + ' (' + selectedModel.provider + ')\n' +
        '• **Estimativa:** ~' + classification.estimated_tokens + ' tokens (~' + classification.estimated_time + 's)\n' +
        '• **Status:** `PENDING_CONFIRMATION`';
    } else {
      interactiveActions.unshift({ type: 'switch_view', view: 'view-operations', label: '📋 Ver no BullMQ' });
      responseText = 'Entendi. Preparei a missão de **' + jobTitle + '** e enfileirei no BullMQ (Job #' + newJob.id + ').\n' +
        'O Agente especialista foi designado e iniciará o processamento em background.';
    }

    sendJson(res, 200, {
      ok: true,
      lane: 'JOB_LANE',
      response: responseText,
      job: newJob,
      confirmationRequired: requiresConf,
      classification: classification,
      selectedModel: selectedModel,
      enhancedPrompt: enhanced.formattedPrompt,
      latencyMs: Date.now() - reqStart,
      actions: interactiveActions,
      interactive: true,
      timestamp: new Date().toISOString()
    });
    return true;
  }

  // 2. Queue control endpoints
  if (method === 'POST' && pathname === '/api/v2/queue/pause') {
    var pRes = await globalJobQueueManager.pauseQueue();
    sendJson(res, 200, pRes);
    return true;
  }
  if (method === 'POST' && pathname === '/api/v2/queue/resume') {
    var rRes = await globalJobQueueManager.resumeQueue();
    sendJson(res, 200, rRes);
    return true;
  }
  if (method === 'GET' && pathname === '/api/v2/queue/status') {
    sendJson(res, 200, globalJobQueueManager.getQueueStatus());
    return true;
  }
  if (method === 'POST' && pathname === '/api/v2/queue/clear-completed') {
    sendJson(res, 200, globalJobQueueManager.clearCompleted());
    return true;
  }

  // 3. Job action endpoints
  var confirmMatch = pathname.match(/^\/api\/v2\/jobs\/([^/]+)\/confirm$/);
  if (method === 'POST' && confirmMatch) {
    var targetJobId = confirmMatch[1];
    try {
      var confJob = await globalJobQueueManager.confirmJob(targetJobId, actorId);
      sendJson(res, 200, { ok: true, job: confJob });
    } catch (e) {
      sendJson(res, 404, { ok: false, error: e.message });
    }
    return true;
  }

  var cancelMatch = pathname.match(/^\/api\/v2\/jobs\/([^/]+)\/cancel$/);
  if (method === 'POST' && cancelMatch) {
    var cancelTargetId = cancelMatch[1];
    try {
      var cancJob = await globalJobQueueManager.cancelJob(cancelTargetId);
      sendJson(res, 200, { ok: true, job: cancJob });
    } catch (e) {
      sendJson(res, 404, { ok: false, error: e.message });
    }
    return true;
  }

  var pauseMatch = pathname.match(/^\/api\/v2\/jobs\/([^/]+)\/pause$/);
  if (method === 'POST' && pauseMatch) {
    var pauseTargetId = pauseMatch[1];
    try {
      var pJob = await globalJobQueueManager.pauseJob(pauseTargetId);
      sendJson(res, 200, { ok: true, job: pJob });
    } catch (e) {
      sendJson(res, 400, { ok: false, error: e.message });
    }
    return true;
  }

  var resumeMatch = pathname.match(/^\/api\/v2\/jobs\/([^/]+)\/resume$/);
  if (method === 'POST' && resumeMatch) {
    var resumeTargetId = resumeMatch[1];
    try {
      var rJob = await globalJobQueueManager.resumeJob(resumeTargetId);
      sendJson(res, 200, { ok: true, job: rJob });
    } catch (e) {
      sendJson(res, 400, { ok: false, error: e.message });
    }
    return true;
  }

  var approveMatch = pathname.match(/^\/api\/v2\/jobs\/([^/]+)\/approve$/);
  if (method === 'POST' && approveMatch) {
    var approveTargetId = approveMatch[1];
    try {
      var appJob = await globalJobQueueManager.confirmJob(approveTargetId, actorId);
      sendJson(res, 200, { ok: true, job: appJob });
    } catch (e) {
      sendJson(res, 400, { ok: false, error: e.message });
    }
    return true;
  }

  var retryMatch = pathname.match(/^\/api\/v2\/jobs\/([^/]+)\/retry$/);
  if (method === 'POST' && retryMatch) {
    var retryTargetId = retryMatch[1];
    try {
      var retJob = await globalJobQueueManager.retryJob(retryTargetId);
      sendJson(res, 200, { ok: true, job: retJob });
    } catch (e) {
      sendJson(res, 404, { ok: false, error: e.message });
    }
    return true;
  }

  // Model update endpoint: POST /api/v2/jobs/:id/model
  var modelMatch = pathname.match(/^\/api\/v2\/jobs\/([^/]+)\/model$/);
  if (method === 'POST' && modelMatch) {
    var mTargetId = modelMatch[1];
    var mBody = await readJson(req).catch(function() { return {}; });
    var newModel = mBody.model;
    var newProv = mBody.provider;
    if (!newModel) {
      sendJson(res, 400, { ok: false, error: 'model is required' });
      return true;
    }
    try {
      var updated = globalJobQueueManager.updateJobModel(mTargetId, newModel, newProv);
      sendJson(res, 200, { ok: true, job: updated });
    } catch (e) {
      sendJson(res, 400, { ok: false, error: e.message });
    }
    return true;
  }

  // 4. Job inspect endpoints
  var singleJobMatch = pathname.match(/^\/api\/v2\/jobs\/([^/]+)$/);
  if (method === 'GET' && singleJobMatch) {
    var sJobId = singleJobMatch[1];
    var sJob = globalJobQueueManager.getJob(sJobId);
    if (sJob) {
      sendJson(res, 200, { ok: true, job: sJob });
    } else {
      sendJson(res, 404, { ok: false, error: 'Job not found' });
    }
    return true;
  }

  // 5. POST & GET /api/v2/jobs — Create and List jobs
  if (method === 'POST' && pathname === '/api/v2/jobs') {
    var cBody = await readJson(req).catch(function() { return {}; });
    var createdJob = globalJobQueueManager.createJob({
      title: cBody.title || ('Job #' + (cBody.type || 'task')),
      type: cBody.type || 'task',
      projectId: cBody.projectId || 'fenix-os',
      agentId: cBody.agentId || 'Gabriel',
      agentName: cBody.agentName || 'Agente Gabriel',
      model: cBody.model || 'qwen2.5:3b',
      provider: cBody.provider || 'API Platform',
      priority: cBody.priority || 'NORMAL',
      estimatedTokens: cBody.estimatedTokens || 600,
      estimatedTimeSec: cBody.estimatedTimeSec || 20,
      requiresConfirmation: Boolean(cBody.requiresConfirmation),
      rawPrompt: cBody.prompt || cBody.rawPrompt || '',
      enhancedPrompt: cBody.enhancedPrompt || '',
      objective: cBody.objective || '',
      scope: cBody.scope || []
    });
    sendJson(res, 201, { ok: true, job: createdJob });
    return true;
  }

  if (method === 'GET' && pathname === '/api/v2/jobs') {
    var statusFilter = url.searchParams.get('status') || undefined;
    var projectFilter = url.searchParams.get('projectId') || undefined;
    var jobsList = globalJobQueueManager.listJobs({ status: statusFilter, projectId: projectFilter });
    var queueStatus = globalJobQueueManager.getQueueStatus();
    sendJson(res, 200, { ok: true, jobs: jobsList, queue: queueStatus });
    return true;
  }

  // 5.5 POST /api/v2/chat/inspect-file — Universal File Forensic & Reverse Analysis
  if (method === 'POST' && pathname === '/api/v2/chat/inspect-file') {
    var fBody = await readJson(req).catch(function() { return {}; });
    var fileName = String(fBody.name || 'arquivo_desconhecido');
    var fileSize = Number(fBody.size || 0);
    var sha256 = String(fBody.sha256 || '');
    var entropy = Number(fBody.entropy || 0);
    var format = String(fBody.format || 'UNKNOWN');
    var details = fBody.details || {};
    var strings = Array.isArray(fBody.strings) ? fBody.strings : [];

    var isHighEntropy = entropy >= 7.65;
    var isCompressed = entropy >= 6.80 && entropy < 7.65;

    var recommendations = [];
    if (isHighEntropy) {
      recommendations.push('Heurística de decriptografia: testar entropia de blocos de 16/32 bytes para identificar CBC/GCM.');
      recommendations.push('Verificar packers conhecidos (UPX, VMProtect, Themida) ou dados empacotados.');
    }
    if (format === 'ANDROID_APK') {
      recommendations.push('Desempacotar classes.dex para Smali ou bytecode Java.');
      recommendations.push('Auditar permissões perigosas em AndroidManifest.xml.');
    } else if (format === 'IOS_IPA') {
      recommendations.push('Extrair Info.plist e verificar entitlements de segurança.');
    } else if (format === 'PDF_DOCUMENT') {
      if (details.isEncrypted) {
        recommendations.push('Documento PDF com dicionário /Encrypt ativo (requer senha de abertura/permissão).');
      } else {
        recommendations.push('Documento PDF não criptografado. Metadados e streams acessíveis.');
      }
    } else if (format.startsWith('EXEC_')) {
      recommendations.push('Desmontar cabeçalhos de seções (.text, .data, .rodata) e tabela de símbolos.');
    }

    var result = {
      ok: true,
      analyzedAt: new Date().toISOString(),
      file: {
        name: fileName,
        size: fileSize,
        sha256: sha256,
        entropy: entropy,
        entropyVerdict: isHighEntropy ? 'ENCRYPTED_OR_PACKED' : (isCompressed ? 'COMPRESSED' : 'STRUCTURED_OR_PLAIN'),
        format: format,
        details: details,
        stringsExtracted: strings.length,
        recommendations: recommendations
      }
    };

    if (fBody.createJob) {
      var revJob = globalJobQueueManager.createJob({
        title: 'Engenharia Reversa: ' + fileName + ' (' + format + ')',
        type: 'reverse_engineering',
        projectId: fBody.projectId || 'fenix-os',
        agentId: 'Gabriel',
        agentName: 'Agente Gabriel (Security & Reverse Brain)',
        model: 'qwen2.5:3b',
        provider: 'API Platform',
        priority: 'HIGH',
        estimatedTokens: 1200,
        estimatedTimeSec: 45,
        rawPrompt: 'Realizar análise forense aprofundada, decriptografia heurística e extração de símbolos do arquivo ' + fileName + ' (SHA-256: ' + sha256 + ', Entropia: ' + entropy + ')',
        objective: 'Extrair IOCs, desempacotar estruturas e gerar relatório de engenharia reversa',
        scope: [fileName]
      });
      result.job = revJob;
    }

    sendJson(res, 200, result);
    return true;
  }

  // 6. Telemetry & Models endpoints
  if (method === 'GET' && pathname === '/api/v2/models') {
    sendJson(res, 200, {
      ok: true,
      currentMode: getSelectorMode(),
      availableModes: ['AUTO', 'FAST', 'QWEN', 'OLLAMA', 'API_PLATFORM'],
      models: [
        { id: 'qwen2.5:3b', name: 'Qwen 2.5 (3B)', provider: 'ollama', role: 'Reasoning & Architecture' },
        { id: 'fast', name: 'Fast AI Model', provider: 'fastEngine', role: 'Instant Chat & Fast Lane' }
      ]
    });
    return true;
  }

  if (method === 'GET' && pathname === '/api/v2/providers') {
    sendJson(res, 200, { ok: true, providers: getProviderStatus() });
    return true;
  }

  if (method === 'GET' && pathname === '/api/v2/tokens') {
    sendJson(res, 200, { ok: true, tokens: getTokenReport() });
    return true;
  }

  return false;
}

module.exports = {
  handleConversationRoutes: handleConversationRoutes
};
