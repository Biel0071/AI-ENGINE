'use strict';
/**
 * FÊNIX OS — Autonomous Loop Routes
 * Expõe controle, status, heartbeat, dashboard, memórias e fila de missões via REST.
 *
 * Endpoints:
 *   GET  /api/v2/autonomous/status    — estado atual do loop e scores
 *   GET  /api/v2/autonomous/heartbeat — heartbeat estruturado (Section 17)
 *   GET  /api/v2/autonomous/dashboard — telemetria completa para a UI Fênix Evolution
 *   GET  /api/v2/autonomous/memories  — histórico de memórias e aprendizados
 *   GET  /api/v2/autonomous/queue     — fila de missões autônomas (P0-P7)
 *   POST /api/v2/autonomous/mission   — enfileira uma nova missão com problemHash
 *   POST /api/v2/autonomous/start     — inicia o loop contínuo
 *   POST /api/v2/autonomous/stop      — para o loop
 *   POST /api/v2/autonomous/cycle     — dispara um ciclo manual imediato
 */

async function handleAutonomousLoopRoutes(req, res, { url, sendJson, readJson, app, autonomousLoop }) {
  const path = url.pathname;

  // GET /api/v2/autonomous/heartbeat
  if (req.method === 'GET' && path === '/api/v2/autonomous/heartbeat') {
    if (!autonomousLoop) {
      return sendJson(res, 503, { ok: false, error: 'Autonomous loop not initialized', status: 'UNAVAILABLE' });
    }
    return sendJson(res, 200, { ok: true, heartbeat: autonomousLoop.getHeartbeat() });
  }

  // GET /api/v2/autonomous/dashboard
  if (req.method === 'GET' && path === '/api/v2/autonomous/dashboard') {
    if (!autonomousLoop) {
      return sendJson(res, 503, { ok: false, error: 'Autonomous loop not initialized', status: 'UNAVAILABLE' });
    }
    const dashboard = await autonomousLoop.getDashboardData();
    return sendJson(res, 200, { ok: true, dashboard });
  }

  // GET /api/v2/autonomous/memories
  if (req.method === 'GET' && path === '/api/v2/autonomous/memories') {
    if (!autonomousLoop?.evolutionMemory) {
      return sendJson(res, 503, { ok: false, error: 'Evolution memory not available' });
    }
    const limit = Number(url.searchParams.get('limit') || 50);
    const pattern = url.searchParams.get('pattern') || undefined;
    const memories = await autonomousLoop.evolutionMemory.list({ limit, pattern });
    const summary = await autonomousLoop.evolutionMemory.getSummary();
    return sendJson(res, 200, { ok: true, memories, summary });
  }

  // GET /api/v2/autonomous/queue
  if (req.method === 'GET' && path === '/api/v2/autonomous/queue') {
    if (!autonomousLoop?.missionQueue) {
      return sendJson(res, 503, { ok: false, error: 'Mission queue not available' });
    }
    return sendJson(res, 200, { ok: true, queue: autonomousLoop.missionQueue.getSnapshot() });
  }

  // POST /api/v2/autonomous/mission
  if (req.method === 'POST' && path === '/api/v2/autonomous/mission') {
    if (!autonomousLoop?.missionQueue) {
      return sendJson(res, 503, { ok: false, error: 'Mission queue not available' });
    }
    try {
      const body = await readJson(req);
      const enqueued = autonomousLoop.missionQueue.enqueue({
        problem: body.problem,
        priority: body.priority || 'P3',
        hypothesis: body.hypothesis,
        context: body.context
      });
      return sendJson(res, 201, { ok: true, ...enqueued });
    } catch (err) {
      return sendJson(res, 400, { ok: false, error: err.message });
    }
  }

  // GET /api/v2/autonomous/status
  if (req.method === 'GET' && path === '/api/v2/autonomous/status') {
    if (!autonomousLoop) {
      return sendJson(res, 503, { ok: false, error: 'Autonomous loop not initialized', status: 'UNAVAILABLE' });
    }
    return sendJson(res, 200, { ok: true, loop: autonomousLoop.getStatus() });
  }

  // POST /api/v2/autonomous/start
  if (req.method === 'POST' && path === '/api/v2/autonomous/start') {
    if (!autonomousLoop) return sendJson(res, 503, { ok: false, error: 'Loop not initialized' });
    autonomousLoop.start();
    return sendJson(res, 200, { ok: true, message: 'Loop iniciado', loop: autonomousLoop.getStatus() });
  }

  // POST /api/v2/autonomous/stop
  if (req.method === 'POST' && path === '/api/v2/autonomous/stop') {
    if (!autonomousLoop) return sendJson(res, 503, { ok: false, error: 'Loop not initialized' });
    autonomousLoop.stop();
    return sendJson(res, 200, { ok: true, message: 'Loop parado', loop: autonomousLoop.getStatus() });
  }

  // POST /api/v2/autonomous/cycle — dispara ciclo manual imediato
  if (req.method === 'POST' && path === '/api/v2/autonomous/cycle') {
    if (!autonomousLoop) return sendJson(res, 503, { ok: false, error: 'Loop not initialized' });
    autonomousLoop._tick().catch(err =>
      console.error('[FenixAutonomousLoop] manual cycle error:', err.message)
    );
    return sendJson(res, 202, { ok: true, message: 'Ciclo manual disparado', cycleCount: autonomousLoop._cycleCount });
  }

  return false;
}

module.exports = { handleAutonomousLoopRoutes };
