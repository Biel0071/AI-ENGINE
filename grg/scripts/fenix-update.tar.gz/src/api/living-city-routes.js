const os = require('node:os');
const { globalBus } = require('../eventing/fenix-event-bus');

async function livingCityState(app, tenantId, actorId, { agentsOnly = false } = {}) {
  await app.controlPlane.authorize(tenantId, actorId, 'runtime:read');
  const [state, jobs, missions, projects, workers] = await Promise.all([
    app.store.read(), app.jobs.list(tenantId, actorId),
    agentsOnly ? Promise.resolve([]) : app.missions.list(tenantId, actorId),
    agentsOnly ? Promise.resolve([]) : app.projectKernel.list(tenantId, actorId),
    agentsOnly ? Promise.resolve([]) : app.jobs.workers(tenantId, actorId),
  ]);
  const profiles = state.agentProfiles || [];
  const catalog = [
    ...(app.ceoAgent ? [app.ceoAgent.identity] : []),
    ...(app.agentRegistry?.list() || []),
    ...(state.agents || []).filter((agent) => agent.tenantId === tenantId),
    ...(state.cognitiveAgents || []).filter((agent) => agent.tenantId === tenantId),
  ];
  const seen = new Set();
  const agents = catalog.filter((agent) => {
    const id = String(agent.id || agent.agentId || '');
    if (!id || seen.has(id.toLowerCase())) return false;
    seen.add(id.toLowerCase()); return true;
  }).map((agent) => {
    const id = String(agent.id || agent.agentId);
    const profile = profiles.find((item) => String(item.id || '').toLowerCase() === id.toLowerCase());
    const currentJob = jobs.find((job) => job.status === 'RUNNING' && (job.agent?.agentId === id || job.agentId === id));
    const storedStatus = String(profile?.status || agent.status || 'AVAILABLE').toUpperCase();
    const status = currentJob ? 'WORKING' : (storedStatus === 'ACTIVE' ? 'AVAILABLE' : storedStatus);
    return {
      id, agentId: id, name: profile?.displayName || agent.name || id,
      role: profile?.role || agent.role || agent.domain || 'agent',
      district: profile?.district || agent.district || null,
      status, state: status, provider: currentJob?.agent?.provider || agent.provider || null,
      model: currentJob?.agent?.model || agent.model || null,
      currentJob: currentJob ? { id: currentJob.id, name: currentJob.prompt || currentJob.type, progress: currentJob.progress } : null,
      currentTask: currentJob?.prompt || null,
      projectId: currentJob?.projectId || null,
      avatar: profile?.avatar || agent.avatar || null,
      kind: (state.cognitiveAgents || []).some((item) => item.id === id && item.tenantId === tenantId) ? 'cognitive' : 'registered',
    };
  });
  const activeMissions = missions.filter((mission) => ['RUNNING', 'QUEUED', 'PAUSED', 'AWAITING_APPROVAL'].includes(String(mission.status).toUpperCase())).length;
  const hostMachine = {
    id: `runtime:${os.hostname()}`, name: 'Nó Fênix', kind: 'runtime', status: 'ONLINE',
    hostname: os.hostname(), uptimeSeconds: Math.round(os.uptime()),
    memoryTotalBytes: os.totalmem(), memoryFreeBytes: os.freemem(),
    cpuLoad1m: os.loadavg()[0], measuredAt: new Date().toISOString(),
  };
  const recentWorkerCutoff = Date.now() - 24 * 60 * 60 * 1000;
  const workerMachines = workers.filter((worker) => worker.status === 'ONLINE' || Date.parse(worker.lastHeartbeat) >= recentWorkerCutoff)
    .sort((left, right) => Date.parse(right.lastHeartbeat || 0) - Date.parse(left.lastHeartbeat || 0))
    .slice(0, 8).map((worker) => ({
      id: `worker:${worker.id || worker.workerId}`, name: `Worker ${worker.id || worker.workerId}`, kind: 'worker',
      status: worker.status, workerId: worker.id || worker.workerId, currentJob: worker.currentJob,
      processed: worker.processed, failed: worker.failed, lastHeartbeat: worker.lastHeartbeat,
    }));
  return {
    source: 'JobEngine/ProjectKernel', measuredAt: new Date().toISOString(), agents,
    projects: projects.map((project) => {
      const heartState = app.fenixHeart ? app.fenixHeart.getProjectState(project.id) : null;
      const absorbed = app.absorptionEngine ? app.absorptionEngine.getAbsorbedProject(project.id) : null;
      const lifecycleState = heartState?.state || absorbed?.lifecycleState || project.lifecycleState || project.status || 'IDLE';
      return {
        id: project.id,
        name: project.name,
        workspace: project.workspace || null,
        status: lifecycleState,
        lifecycleState,
        absorbed: Boolean(absorbed),
      };
    }),
    recentJobs: agentsOnly ? [] : jobs.slice(-20).reverse().map((job) => ({
      id: job.id, title: job.title || job.objective || job.prompt || job.type || 'Job',
      type: job.type || null, status: job.status, projectId: job.projectId || null,
      agentId: job.agent?.agentId || job.agentId || null,
      progress: Number.isFinite(Number(job.progress)) ? Number(job.progress) : null,
      createdAt: job.createdAt || null,
    })),
    machines: agentsOnly ? [] : [hostMachine, ...workerMachines],
    workers: workers.map((worker) => ({ id: worker.workerId, status: worker.status, currentJob: worker.currentJob, processed: worker.processed, failed: worker.failed, lastHeartbeat: worker.lastHeartbeat })),
    metrics: {
      registeredAgents: agents.length,
      workingAgents: agents.filter((agent) => agent.status === 'WORKING').length,
      projectsCount: projects.length, activeMissions,
      runningJobs: jobs.filter((job) => job.status === 'RUNNING').length,
      failedJobs: jobs.filter((job) => ['FAILED', 'DEAD_LETTER'].includes(job.status)).length,
      memoriesCount: (state.memories || []).filter((item) => item.tenantId === tenantId && item.status === 'ACTIVE').length,
    },
  };
}

async function handleLivingCityRoutes(req, res, url, app, sendJson, identity) {
  if (req.method !== 'GET') return false;

  if (['/api/v2/living-city/agents', '/api/v2/living-city/state'].includes(url.pathname)) {
    const data = await livingCityState(app, identity.tenantId, identity.actorId, { agentsOnly: url.pathname.endsWith('/agents') });
    sendJson(res, 200, url.pathname.endsWith('/agents') ? { source: data.source, measuredAt: data.measuredAt, count: data.agents.length, agents: data.agents } : data);
    return true;
  }

  if (url.pathname === '/api/v2/living-city/events/stream') {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*',
      'X-Accel-Buffering': 'no',
    });
    if (typeof res.flushHeaders === 'function') res.flushHeaders();
    res.write('data: {"type":"ping","message":"connected"}\n\n');
    globalBus.addSSEClient(res);
    const hb = setInterval(() => {
      try { res.write(': heartbeat ' + new Date().toISOString() + '\n\n'); } catch (_) { clearInterval(hb); }
    }, 15000);
    if (hb.unref) hb.unref();
    res.on('close', () => { clearInterval(hb); });
    return true;
  }

  if (url.pathname === '/api/v2/living-city/events') {
    const limit = parseInt(url.searchParams.get('limit') || '30', 10);
    const category = url.searchParams.get('category') || 'ALL';
    let events = globalBus.getHistory(limit);
    if ((!events || events.length === 0) && app.jobs) {
      try {
        const jobs = await app.jobs.list(identity.tenantId, identity.actorId);
        events = jobs.slice(-limit).reverse().map(j => ({
          id: `job-${j.id || j.jobId}`,
          type: 'job.state',
          category: 'JOBS',
          description: `Job ${j.title || j.type || j.id} status: ${j.status}`,
          timestamp: j.createdAt || new Date().toISOString(),
          payload: { jobId: j.id || j.jobId, status: j.status, progress: j.progress }
        }));
      } catch (_) {}
    }
    const formatted = (events || []).map(ev => ({
      id: ev.id,
      type: ev.type,
      category: ev.category || (ev.type?.startsWith('agent') ? 'AGENTS' : (ev.type?.startsWith('job') ? 'JOBS' : 'SYSTEM')),
      description: ev.description || ev.data?.message || ev.data?.prompt || ev.type,
      timestamp: ev.timestamp || new Date().toISOString(),
      payload: ev.data || ev.payload || {}
    }));
    sendJson(res, 200, { ok: true, source: 'LivingCityEvents/EventBus', count: formatted.length, events: formatted });
    return true;
  }

  if (url.pathname === '/api/v2/living-city/projects') {
    const data = await livingCityState(app, identity.tenantId, identity.actorId);
    sendJson(res, 200, { source: data.source, measuredAt: data.measuredAt, count: data.projects.length, projects: data.projects });
    return true;
  }

  if (url.pathname.startsWith('/api/v2/living-city/agent/')) {
    const agentId = decodeURIComponent(url.pathname.replace('/api/v2/living-city/agent/', ''));
    const isCeo = agentId.toLowerCase() === 'agent.ceo' || agentId.toLowerCase() === 'ceo';
    if (isCeo && app.ceoAgent) {
      try {
        const company = app.companyBrain ? await app.companyBrain.getCompany(identity.tenantId) : null;
        const telemetry = app.companyBrain ? await app.companyBrain.getTelemetry(identity.tenantId, company?.id) : {};
        const hypotheses = typeof app.evolutionLab?.listHypotheses === 'function' ? app.evolutionLab.listHypotheses() : [];
        const experiments = typeof app.evolutionLab?.listExperiments === 'function' ? app.evolutionLab.listExperiments() : [];
        return sendJson(res, 200, {
          ok: true,
          source: 'CEOAgent/CompanyBrain',
          agent: {
            id: 'agent.ceo',
            agentId: 'agent.ceo',
            name: 'CEO Agent',
            role: 'CHIEF_EXECUTIVE_OFFICER',
            level: 'EXECUTIVE',
            department: 'EXECUTIVE',
            company: company?.name || 'Fênix Enterprise',
            companyStatus: company?.status || 'OPERATIONAL',
            status: 'ACTIVE',
            state: 'ACTIVE',
            location: 'command-center',
            district: 'command-center',
            emoji: '👔',
            currentJob: null,
            currentTask: 'Observing enterprise telemetry and company health',
            currentGoal: 'Maximal autonomous alignment and economic efficiency',
            model: app.ceoAgent.identity?.model || 'qwen2.5:3b',
            tools: app.ceoAgent.identity?.tools || ['company_metrics', 'delegate_job', 'observe_enterprise'],
            permissions: app.ceoAgent.identity?.permissions || ['*'],
            tokens: 0,
            latency: '12ms',
            goals: company?.goals || [],
            metrics: telemetry,
            activeAgents: company?.agents?.length || 1,
            jobs: app.companyBrain?.jobDelegations?.length || 0,
            problems: [],
            hypotheses,
            experiments,
            recentDecisions: app.ceoAgent.decisions || [],
            memory: app.ceoAgent.episodicMemory || [],
            episodicMemory: app.ceoAgent.episodicMemory || [],
            lastAction: app.ceoAgent.decisions?.slice(-1)[0]?.action || 'Observing enterprise health',
            nextAction: 'Ready for executive directives'
          }
        });
      } catch (err) {
        return sendJson(res, 200, {
          ok: true,
          source: 'CEOAgent/Fallback',
          agent: {
            id: 'agent.ceo',
            agentId: 'agent.ceo',
            name: 'CEO Agent',
            role: 'CHIEF_EXECUTIVE_OFFICER',
            level: 'EXECUTIVE',
            department: 'EXECUTIVE',
            company: 'Fênix Enterprise',
            status: 'ACTIVE',
            state: 'ACTIVE',
            location: 'command-center',
            district: 'command-center',
            emoji: '👔',
            currentJob: null,
            currentTask: 'Observing enterprise telemetry and company health',
            model: 'qwen2.5:3b',
            tools: ['company_metrics', 'delegate_job', 'observe_enterprise'],
            permissions: ['*'],
            tokens: 0,
            latency: '12ms',
            memory: [],
            episodicMemory: [],
            lastAction: 'Observing enterprise health',
            nextAction: 'Ready for executive directives'
          }
        });
      }
    }

    try {
      const data = await livingCityState(app, identity.tenantId, identity.actorId);
      const ag = data.agents.find(a => String(a.id || a.agentId).toLowerCase() === agentId.toLowerCase());
      if (ag) {
        return sendJson(res, 200, {
          ok: true,
          source: 'JobEngine/ProjectKernel',
          agent: {
            id: ag.id,
            agentId: ag.id,
            name: ag.name,
            role: ag.role,
            department: ag.district || 'TECHNOLOGY',
            company: app.companyBrain?.company?.name || 'Fênix Enterprise',
            currentJob: ag.currentJob,
            model: ag.model || 'qwen2.5:3b',
            tools: ['file_read', 'git_inspect', 'command_exec', 'test_runner'],
            permissions: ['read', 'write', 'execute'],
            status: ag.status || 'AVAILABLE',
            state: ag.state || 'AVAILABLE',
            location: ag.district || 'dev-district',
            district: ag.district || 'dev-district',
            emoji: ag.avatar || '🤖',
            tokens: 0,
            latency: '—',
            memory: [],
            episodicMemory: [
              { timestamp: new Date().toISOString(), content: `Agente sincronizado no distrito ${ag.district || 'dev-district'}` }
            ],
            lastAction: ag.currentTask || (ag.currentJob ? ag.currentJob.name : 'Standby aguardando atribuição no distrito'),
            nextAction: 'Pronto para execução de tarefas'
          }
        });
      }
    } catch (err) {
      // Ignore and proceed to 404
    }

    return sendJson(res, 404, { ok: false, error: `Agente '${agentId}' não encontrado` });
  }

  if (url.pathname.startsWith('/api/v2/living-city/building/')) {
    const buildingId = decodeURIComponent(url.pathname.replace('/api/v2/living-city/building/', ''));
    return sendJson(res, 200, {
      ok: true,
      source: 'LivingCityState',
      building: {
        id: buildingId,
        name: buildingId.toUpperCase().replace(/-/g, ' '),
        district: buildingId,
        subsystem: 'Core Infrastructure',
        health: 'HEALTHY',
        emoji: '🏛️',
        description: 'Edifício operacional conectado ao runtime'
      }
    });
  }

  return false;
}

module.exports = { handleLivingCityRoutes, livingCityState };
