(() => {
  const state = {
    projectId: null,
    requestedProjectId: null,
    path: null,
    hash: null,
    savedContent: '',
    dirty: false,
    generation: 0,
    openToken: 0,
    projects: [],
    mode: localStorage.getItem('fenix_ide_mode') || 'split',
    viewport: 'desktop',
    previewUrl: '',
    treeData: []
  };

  let loadPromise = null;
  const endpoint = (suffix = '') => `/api/fenix/projects/${encodeURIComponent(state.projectId)}${suffix}`;

  async function json(url, options = {}) {
    const token = localStorage.getItem('grg_token') || localStorage.getItem('fenix_token');
    const response = await fetch(url, {
      signal: AbortSignal.timeout(30000),
      credentials: 'same-origin',
      ...options,
      headers: {
        ...(token ? { authorization: `Bearer ${token}` } : {}),
        ...options.headers
      }
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
    return data;
  }

  function status(message, error = false) {
    const node = document.getElementById('fenixIdeLiveStatus');
    if (node) {
      node.textContent = message;
      node.dataset.error = String(error);
    }
  }

  function getPreviewUrlForProject(projectId) {
    const host = window.location.hostname || '209.50.241.22';
    const protocol = window.location.protocol === 'https:' ? 'http:' : window.location.protocol;
    if (projectId === 'api-platform-live') {
      return `${protocol}//${host}:8081`;
    }
    if (projectId === 'zapai-crm') {
      return `${protocol}//${host}:4025`;
    }
    if (projectId === 'fenix-os-master' || projectId === 'fenix-core') {
      return `${protocol}//${host}:3000`;
    }
    return `${protocol}//${host}:8081`;
  }

  function setMode(newMode) {
    state.mode = newMode;
    localStorage.setItem('fenix_ide_mode', newMode);
    const container = document.querySelector('.fenix-live-ide');
    if (container) container.dataset.mode = newMode;

    const btns = document.querySelectorAll('.fenix-live-ide-mode-btn');
    btns.forEach(btn => {
      btn.classList.toggle('active', btn.dataset.mode === newMode);
    });

    if (newMode !== 'code' && state.previewUrl) {
      const frame = document.getElementById('fenixIdeLiveFrame');
      const loading = document.getElementById('fenixIdePreviewLoading');
      if (frame && (!frame.src || frame.src === 'about:blank')) {
        if (loading) loading.style.display = 'flex';
        frame.src = state.previewUrl;
      }
    }
  }

  function setViewport(vp) {
    state.viewport = vp;
    const wrap = document.getElementById('fenixIdeFrameWrap');
    if (wrap) wrap.dataset.viewport = vp;

    const btns = document.querySelectorAll('.fenix-live-ide-vp-btn');
    btns.forEach(btn => {
      btn.classList.toggle('active', btn.dataset.vp === vp);
    });
  }

  function updatePreview(url) {
    state.previewUrl = url;
    const urlEl = document.getElementById('fenixIdePreviewUrl');
    if (urlEl) urlEl.textContent = url;

    const frame = document.getElementById('fenixIdeLiveFrame');
    const loading = document.getElementById('fenixIdePreviewLoading');
    if (frame && state.mode !== 'code') {
      if (loading) loading.style.display = 'flex';
      frame.src = url;
    }
  }

  function updateLineNumbers() {
    const code = document.getElementById('fenixIdeLiveCode');
    const linesNode = document.getElementById('fenixIdeLineNumbers');
    if (!code || !linesNode) return;
    const lineCount = (code.value || '').split('\n').length;
    linesNode.textContent = Array.from({ length: Math.max(1, lineCount) }, (_, i) => i + 1).join('\n');
  }

  function renderShell() {
    const view = document.getElementById('view-ide');
    if (!view || view.dataset.liveIde === 'true') return;
    view.dataset.liveIde = 'true';

    view.innerHTML = `<section class="fenix-live-ide" data-mode="${state.mode}">
      <header class="fenix-live-ide-header">
        <div>
          <span class="fenix-live-ide-eyebrow">PROJECT KERNEL · WORKSPACE REAL · LOVABLE LIVE</span>
          <h1>IDE de Projetos</h1>
          <p>Leia, edite código e visualize a aplicação real em execução lado a lado.</p>
        </div>
        <div class="fenix-live-ide-controls">
          <label for="fenixIdeProject">Projeto</label>
          <select id="fenixIdeProject" aria-label="Projeto do IDE"></select>

          <!-- Lovable Mode Switcher -->
          <div class="fenix-live-ide-mode-switcher" role="radiogroup" aria-label="Modo de Visualização">
            <button type="button" class="fenix-live-ide-mode-btn ${state.mode === 'code' ? 'active' : ''}" data-mode="code" title="Apenas Editor de Código">💻 Código</button>
            <button type="button" class="fenix-live-ide-mode-btn ${state.mode === 'split' ? 'active' : ''}" data-mode="split" title="Split Screen: Código e Tela Real">◫ Split</button>
            <button type="button" class="fenix-live-ide-mode-btn ${state.mode === 'preview' ? 'active' : ''}" data-mode="preview" title="Apenas Tela Real">👁️ Tela Real</button>
          </div>

          <button id="fenixIdeAnalyze" type="button">Analisar projeto</button>
        </div>
      </header>

      <div class="fenix-live-ide-meta">
        <span id="fenixIdeProjectMeta">—</span>
        <span id="fenixIdeLiveStatus" role="status">—</span>
      </div>

      <div class="fenix-live-ide-body">
        <aside class="fenix-live-ide-tree">
          <div class="fenix-live-ide-panel-head">
            <span>Arquivos</span>
            <button id="fenixIdeRefresh" type="button" title="Atualizar árvore">↻</button>
          </div>
          <div class="fenix-live-ide-tree-search-wrap">
            <span class="fenix-live-ide-tree-search-icon">🔍</span>
            <input type="text" id="fenixIdeTreeSearch" class="fenix-live-ide-tree-search" placeholder="Filtrar arquivos..." aria-label="Filtrar arquivos">
          </div>
          <div id="fenixIdeLiveTree"></div>
        </aside>

        <div class="fenix-live-ide-workspace">
          <!-- Code Editor Pane -->
          <main class="fenix-live-ide-editor">
            <div class="fenix-live-ide-panel-head">
              <span id="fenixIdeLivePath">Selecione um arquivo</span>
              <div class="fenix-live-ide-save-actions">
                <span id="fenixIdeDirtyState" role="status">Nenhum arquivo aberto</span>
                <button id="fenixIdeLiveSave" type="button" disabled>Salvar alteração</button>
              </div>
            </div>
            <div class="fenix-live-ide-editor-container">
              <div class="fenix-live-ide-line-numbers" id="fenixIdeLineNumbers" aria-hidden="true">1</div>
              <textarea id="fenixIdeLiveCode" spellcheck="false" aria-label="Conteúdo do arquivo" placeholder="Selecione um arquivo na árvore para começar."></textarea>
            </div>
          </main>

          <!-- Lovable Live Preview Pane -->
          <section class="fenix-live-ide-preview-pane" id="fenixIdePreviewPane">
            <div class="fenix-live-ide-preview-toolbar">
              <div class="fenix-live-ide-preview-url-box">
                <span class="fenix-live-ide-preview-dot"></span>
                <span class="fenix-live-ide-preview-url" id="fenixIdePreviewUrl">—</span>
              </div>
              <div class="fenix-live-ide-viewport-btns">
                <button type="button" class="fenix-live-ide-vp-btn active" data-vp="desktop" title="Desktop View (100%)">🖥️ <span class="hide-compact">Desktop</span></button>
                <button type="button" class="fenix-live-ide-vp-btn" data-vp="tablet" title="Tablet View (768px)">📱 <span class="hide-compact">Tablet</span></button>
                <button type="button" class="fenix-live-ide-vp-btn" data-vp="mobile" title="Mobile View (375px)">📱 <span class="hide-compact">Mobile</span></button>
              </div>
              <div class="fenix-live-ide-preview-actions">
                <button type="button" id="fenixIdePreviewReload" class="fenix-live-ide-preview-btn" title="Recarregar tela real">↻ <span class="hide-compact">Recarregar</span></button>
                <button type="button" id="fenixIdePreviewExternal" class="fenix-live-ide-preview-btn" title="Abrir em nova aba">↗ <span class="hide-compact">Nova Aba</span></button>
              </div>
            </div>
            <div class="fenix-live-ide-preview-canvas">
              <div class="fenix-live-ide-preview-frame-wrap" id="fenixIdeFrameWrap" data-viewport="desktop">
                <div class="fenix-live-ide-preview-loading" id="fenixIdePreviewLoading" style="display:none;">
                  <div class="fenix-live-ide-preview-spinner"></div>
                  <span>Carregando Tela Real (:8081)…</span>
                </div>
                <iframe id="fenixIdeLiveFrame" title="Tela Real do Sistema" src="about:blank" sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-modals"></iframe>
              </div>
            </div>
          </section>
        </div>
      </div>
    </section>`;

    // Event Listeners
    document.getElementById('fenixIdeProject').addEventListener('change', (event) => selectProject(event.target.value));
    document.getElementById('fenixIdeRefresh').addEventListener('click', () => loadTree());
    document.getElementById('fenixIdeLiveSave').addEventListener('click', saveFile);
    
    const codeArea = document.getElementById('fenixIdeLiveCode');
    const lineNumbers = document.getElementById('fenixIdeLineNumbers');
    codeArea.addEventListener('input', () => {
      updateDirty();
      updateLineNumbers();
    });
    codeArea.addEventListener('scroll', () => {
      if (lineNumbers) lineNumbers.scrollTop = codeArea.scrollTop;
    });
    codeArea.addEventListener('keydown', (event) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') {
        event.preventDefault();
        if (state.dirty) saveFile();
      }
    });

    document.getElementById('fenixIdeAnalyze').addEventListener('click', analyzeProject);

    // Mode Switcher listeners
    document.querySelectorAll('.fenix-live-ide-mode-btn').forEach(btn => {
      btn.addEventListener('click', () => setMode(btn.dataset.mode));
    });

    // Viewport switcher listeners
    document.querySelectorAll('.fenix-live-ide-vp-btn').forEach(btn => {
      btn.addEventListener('click', () => setViewport(btn.dataset.vp));
    });

    // Preview Frame load and error listeners
    const frame = document.getElementById('fenixIdeLiveFrame');
    const loading = document.getElementById('fenixIdePreviewLoading');
    if (frame) {
      frame.addEventListener('load', () => {
        if (loading) loading.style.display = 'none';
      });
      frame.addEventListener('error', () => {
        if (loading) loading.style.display = 'none';
      });
    }

    // Preview Toolbar buttons
    document.getElementById('fenixIdePreviewReload')?.addEventListener('click', () => {
      if (frame && state.previewUrl) {
        if (loading) loading.style.display = 'flex';
        frame.src = state.previewUrl + (state.previewUrl.includes('?') ? '&' : '?') + '_t=' + Date.now();
      }
    });

    document.getElementById('fenixIdePreviewExternal')?.addEventListener('click', () => {
      if (state.previewUrl) window.open(state.previewUrl, '_blank');
    });

    // Search input listener
    document.getElementById('fenixIdeTreeSearch').addEventListener('input', (e) => {
      filterTree(e.target.value);
    });
  }

  function filterTree(query) {
    const q = (query || '').toLowerCase().trim();
    const treeNode = document.getElementById('fenixIdeLiveTree');
    if (!treeNode) return;
    const files = treeNode.querySelectorAll('.fenix-live-ide-file');
    const folders = treeNode.querySelectorAll('.fenix-live-ide-folder');
    if (!q) {
      files.forEach(f => { f.style.display = ''; });
      folders.forEach(f => { f.style.display = ''; f.open = false; });
      return;
    }
    folders.forEach(f => { f.open = true; });
    files.forEach(f => {
      const name = (f.textContent || '').toLowerCase();
      const path = (f.title || '').toLowerCase();
      const match = name.includes(q) || path.includes(q);
      f.style.display = match ? '' : 'none';
    });
    folders.forEach(folder => {
      const hasVisible = folder.querySelector('.fenix-live-ide-file:not([style*="display: none"])');
      folder.style.display = hasVisible ? '' : 'none';
    });
  }

  function updateDirty() {
    state.dirty = Boolean(state.path && state.hash && document.getElementById('fenixIdeLiveCode').value !== state.savedContent);
    document.getElementById('fenixIdeLiveSave').disabled = !state.dirty;
    const label = document.getElementById('fenixIdeDirtyState');
    label.textContent = !state.path ? 'Nenhum arquivo aberto' : state.dirty ? 'Alterações não salvas' : 'Salvo';
    label.dataset.dirty = String(state.dirty);
  }

  function mayDiscardChanges() {
    return !state.dirty || window.confirm('Há alterações não salvas. Descartar e continuar?');
  }

  window.addEventListener('beforeunload', (event) => {
    if (state.dirty) {
      event.preventDefault();
      event.returnValue = '';
    }
  });

  async function loadProjects() {
    renderShell();
    try {
      const data = await json('/api/fenix/projects');
      state.projects = (data.projects || []).filter((project) => project.workspace);
      const select = document.getElementById('fenixIdeProject');
      select.replaceChildren();
      if (!state.projects.length) {
        select.add(new Option('Nenhum workspace registrado', ''));
        status('Registre um projeto com workspace no Project Kernel.', true);
        return;
      }
      for (const project of state.projects) {
        select.add(new Option(project.name, project.id));
      }
      const saved = localStorage.getItem('fenix_ide_project');
      const preferred = state.projects.find((project) => project.id === state.requestedProjectId) ||
                        state.projects.find((project) => project.id === saved) ||
                        state.projects.find((project) => project.id === 'api-platform-live') ||
                        state.projects[0];
      state.requestedProjectId = null;
      select.value = preferred.id;
      await selectProject(preferred.id);
    } catch (error) {
      status(`Falha ao carregar projetos: ${error.message}`, true);
    }
  }

  async function selectProject(id) {
    if (id !== state.projectId && !mayDiscardChanges()) {
      document.getElementById('fenixIdeProject').value = state.projectId;
      return false;
    }
    state.projectId = id;
    state.path = null;
    state.hash = null;
    state.savedContent = '';
    state.generation++;
    state.openToken++;
    const generation = state.generation;
    localStorage.setItem('fenix_ide_project', id);

    const project = state.projects.find((item) => item.id === id);
    document.getElementById('fenixIdeProjectMeta').textContent = project ? `${project.workspace} · consultando Git…` : '—';
    document.getElementById('fenixIdeLivePath').textContent = 'Selecione um arquivo';
    document.getElementById('fenixIdeLiveCode').value = '';
    updateLineNumbers();
    updateDirty();

    // Update real preview URL
    const previewUrl = getPreviewUrlForProject(id);
    updatePreview(previewUrl);

    const [gitState] = await Promise.all([
      json(endpoint('/git')).catch(() => null),
      loadTree(generation),
    ]);
    if (generation !== state.generation) return false;
    document.getElementById('fenixIdeProjectMeta').textContent = project
      ? `${project.workspace} · ${gitState?.branch || 'branch indisponível'} · ${gitState?.head ? gitState.head.slice(0, 12) : 'versão indisponível'}`
      : '—';
    return true;
  }

  function appendNodes(parent, nodes) {
    for (const item of nodes) {
      if (item.type === 'directory') {
        const group = document.createElement('details');
        group.className = 'fenix-live-ide-folder';
        const summary = document.createElement('summary');
        summary.innerHTML = `<span class="fenix-live-ide-folder-icon">📁</span> <span>${item.name}</span>`;
        group.appendChild(summary);
        appendNodes(group, item.children || []);
        parent.appendChild(group);
      } else {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'fenix-live-ide-file';
        button.title = item.path;
        button.dataset.path = item.path;

        const ext = String(item.name || '').split('.').pop().toLowerCase();
        let icon = '📄';
        if (['js', 'mjs', 'ts'].includes(ext)) icon = '⚡';
        else if (['json', 'yaml', 'yml'].includes(ext)) icon = '⚙️';
        else if (['html', 'htm'].includes(ext)) icon = '🌐';
        else if (['css', 'scss'].includes(ext)) icon = '🎨';
        else if (['md', 'txt'].includes(ext)) icon = '📝';
        else if (['sh', 'bat', 'ps1'].includes(ext)) icon = '🐚';

        button.innerHTML = `<span class="fenix-live-ide-file-icon">${icon}</span> <span>${item.name}</span>`;
        button.addEventListener('click', () => openFile(item.path));
        parent.appendChild(button);
      }
    }
  }

  async function loadTree(generation = state.generation) {
    if (!state.projectId) return;
    const tree = document.getElementById('fenixIdeLiveTree');
    tree.textContent = 'Carregando arquivos…';
    try {
      const data = await json(endpoint('/tree'));
      if (generation !== state.generation) return;
      tree.replaceChildren();
      state.treeData = data.tree || [];
      appendNodes(tree, state.treeData);
      if (!state.treeData.length) tree.textContent = 'Nenhum arquivo acessível neste workspace.';
      status(`${state.treeData.length} entradas na raiz · fonte: Project Kernel`);
      if (!state.path && Array.isArray(data.tree) && data.tree.length > 0) {
        const findFirstFile = (nodes) => {
          for (const item of nodes) {
            if (item.type === 'file') return item;
            if (item.type === 'directory' && item.children) {
              const sub = findFirstFile(item.children);
              if (sub) return sub;
            }
          }
          return null;
        };
        const first = findFirstFile(data.tree);
        if (first) openFile(first.path);
      }
    } catch (error) {
      if (generation === state.generation) {
        tree.textContent = 'Não foi possível carregar a árvore.';
        status(error.message, true);
      }
    }
  }

  async function openFile(filePath) {
    if (!mayDiscardChanges()) return false;
    const cleanPath = String(filePath || '').replace(/\\/g, '/').replace(/^\/+/, '').trim();
    if (!cleanPath) return false;
    const generation = state.generation, token = ++state.openToken;
    status(`Abrindo ${cleanPath}…`);
    try {
      const data = await json(`${endpoint('/file')}?path=${encodeURIComponent(cleanPath)}`);
      if (generation !== state.generation || token !== state.openToken) return false;
      state.path = data.path;
      state.hash = data.hash;
      document.getElementById('fenixIdeLivePath').textContent = data.path;
      document.getElementById('fenixIdeLiveCode').value = data.content;
      state.savedContent = data.content;
      updateDirty();
      updateLineNumbers();

      // Highlight active file in tree
      const allFiles = document.querySelectorAll('.fenix-live-ide-file');
      allFiles.forEach(f => {
        f.classList.toggle('active', f.title === cleanPath || f.dataset.path === cleanPath);
      });

      status(`${data.size} bytes · pronto para edição`);
      return true;
    } catch (error) {
      if (generation === state.generation && token === state.openToken) status(`Falha ao abrir: ${error.message}`, true);
      return false;
    }
  }

  async function saveFile() {
    if (!state.projectId || !state.path || !state.hash) return;
    const button = document.getElementById('fenixIdeLiveSave');
    button.disabled = true;
    status('Salvando alteração…');
    const content = document.getElementById('fenixIdeLiveCode').value;
    const generation = state.generation, token = state.openToken, filePath = state.path;
    try {
      const data = await json(endpoint('/file'), {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ path: state.path, content, expectedHash: state.hash })
      });
      if (generation !== state.generation || token !== state.openToken || filePath !== state.path) return;
      state.hash = data.hash;
      state.savedContent = content;
      updateDirty();
      status(data.warning ? `Arquivo salvo; atenção: ${data.warning}` : `Salvo em ${new Date(data.savedAt).toLocaleTimeString()} · memória v${data.memoryVersion}`, Boolean(data.warning));
    } catch (error) {
      if (generation === state.generation && token === state.openToken) status(`Falha ao salvar: ${error.message}`, true);
    } finally {
      button.disabled = !state.dirty;
    }
  }

  async function analyzeProject() {
    if (!state.projectId) return;
    status('Analisando estado do Git…');
    try {
      const data = await json(endpoint('/analyze'), { method: 'POST' });
      status(`Análise registrada · HEAD ${String(data.head || '').slice(0, 12)} · artefato ${data.artifact?.name || 'criado'}`);
    } catch (error) {
      status(`Falha na análise: ${error.message}`, true);
    }
  }

  window.loadIdeView = () => {
    if (loadPromise) return loadPromise;
    if (state.projectId && state.projects.length) return Promise.resolve();
    loadPromise = loadProjects().finally(() => { loadPromise = null; });
    return loadPromise;
  };

  window.fenixSelectIdeFile = async (filePath) => {
    if (!state.projectId) await window.loadIdeView();
    return state.projectId ? openFile(filePath) : false;
  };

  window.fenixSelectIdeProject = async (projectId) => {
    state.requestedProjectId = projectId;
    await window.loadIdeView();
    state.requestedProjectId = null;
    if (!state.projects.some((project) => project.id === projectId)) throw new Error('Projeto sem workspace registrado na IDE');
    if (state.projectId !== projectId) {
      document.getElementById('fenixIdeProject').value = projectId;
      if (!await selectProject(projectId)) throw new Error('Troca de projeto cancelada');
    }
    return true;
  };

  window.FenixProjectIDE = {
    selectProject: window.fenixSelectIdeProject,
    openFile: window.fenixSelectIdeFile,
    load: window.loadIdeView
  };
})();
