/**
 * FÊNIX OS — GLOBAL RIGHT SIDEBAR, FLOATING ANIMATED MASCOT & RPG AGENT STUDIO
 * Single Source of Truth Modular Component: fenix-mascot-sidebar.js
 * Hardware accelerated, zero-mock compliant, reactive to real runtime events.
 */
(function() {
  'use strict';

  // ── Paletas Compartilhadas (Compatíveis com pixi-character-system.js) ──
  const SKIN_COLORS = ['#FEE3D4', '#F5D5C0', '#E8C4A0', '#D4A373', '#C8956C', '#8D5B38', '#55331C', '#E0B89C'];
  const HAIR_COLORS = ['#18181B', '#3B2314', '#5D3A1A', '#9A3412', '#D97706', '#94A3B8', '#0284C7', '#7C3AED'];
  const SHIRT_COLORS = ['#2563EB', '#059669', '#3B82F6', '#6366F1', '#DB2777', '#16A34A', '#D97706', '#EF4444'];

  // ── Estado Global do Componente ──
  const state = {
    isOpen: localStorage.getItem('fenix_sidebar_state') !== 'minimized',
    isDocked: localStorage.getItem('fenix_sidebar_docked') !== 'false',
    activeTab: 'chat',
    mascotMood: 'idle', // 'idle' | 'thinking' | 'working' | 'success' | 'error'
    selectedAgent: 'fenix-mascot',
    conversations: [],
    activeConversationId: null,
    chatHistory: [],
    logs: [],
    telemetry: {
      cpu: '—',
      ram: '—',
      uptime: '—',
      latency: '—',
      vpsStatus: '—',
      activeJobs: '—'
    },
    activeInspectAgent: null
  };

  // ── Elementos do DOM ──
  let sidebarEl = null;
  let mascotEl = null;
  let modalEl = null;

  // ── Helpers Autenticados (Zero-Mock & Same-Origin Session) ──
  function getAuthToken() {
    return window.localStorage?.getItem('grg_token') ||
           window.localStorage?.getItem('fenix_token') ||
           window.sessionStorage?.getItem('grg_token') ||
           window.sessionStorage?.getItem('fenix_token') ||
           (document.cookie.match(/fenix_session=([^;]+)/) || [])[1] ||
           window.__FENIX_TOKEN__ ||
           '';
  }

  function authedFetch(url, options = {}) {
    const token = getAuthToken();
    const headers = { 'Accept': 'application/json', 'Content-Type': 'application/json', ...(options.headers || {}) };
    if (token && token !== 'null') {
      headers['Authorization'] = 'Bearer ' + token;
    }
    return fetch(url, {
      ...options,
      credentials: 'same-origin',
      headers
    });
  }

  // ── Inicialização do Markup no DOM ──
  function ensureDOMElements() {
    document.body.classList.toggle('has-right-sidebar-open', state.isOpen);
    // 1. Sidebar Direita Global
    if (!document.getElementById('fenix-right-sidebar')) {
      const sb = document.createElement('aside');
      sb.id = 'fenix-right-sidebar';
      sb.className = state.isOpen ? 'open' : '';
      sb.innerHTML = `
        <div class="fsb-resize-handle" id="fsbResizeHandle" title="Arrastar para ajustar largura do chat"></div>
        <div class="fsb-header">
          <div class="fsb-header-left">
            <div class="fsb-avatar-wrap" id="fsbHeaderAvatar">
              <i class="ph-bold ph-robot fsb-avatar-icon"></i>
              <div class="fsb-status-dot" id="fsbStatusDot"></div>
            </div>
            <div class="fsb-header-info">
              <div class="fsb-title">FÊNIX <span>AI</span></div>
              <select class="fsb-agent-select" id="fsbAgentSelector" title="Selecionar agente ou especialidade">
                <option value="fenix-mascot">Mascote Fênix</option>
                <option value="agent-ceo">CEO Brain</option>
                <option value="agent-developer">Senior Dev</option>
                <option value="agent-architect">Architect Brain</option>
                <option value="agent-security">Security Guard</option>
              </select>
            </div>
          </div>
          <div class="fsb-header-actions">
            <button class="fsb-dock-toggle-btn active" id="fsbDockBtn" title="Alternar Split Screen / Flutuante"><i class="ph-bold ph-columns"></i> <span id="fsbDockBtnText">Split</span></button>
            <button class="fsb-icon-btn" id="fsbClearBtn" title="Limpar Chat"><i class="ph-bold ph-trash"></i></button>
            <button class="fsb-icon-btn" id="fsbMinimizeBtn" title="Minimizar para Mascote"><i class="ph-bold ph-caret-right"></i></button>
          </div>
        </div>

        <div class="fsb-tabs">
          <button class="fsb-tab-btn active" data-tab="chat"><i class="ph-bold ph-chat-teardrop-text"></i> Chat</button>
          <button class="fsb-tab-btn" data-tab="telemetry"><i class="ph-bold ph-activity"></i> Telemetria</button>
          <button class="fsb-tab-btn" data-tab="logs"><i class="ph-bold ph-scroll"></i> Logs</button>
          <button class="fsb-tab-btn" data-tab="terminal"><i class="ph-bold ph-terminal-window"></i> Terminal</button>
        </div>

        <!-- Painel Chat -->
        <div class="fsb-panel active" id="fsbPanelChat" style="position:relative;">
          <!-- Drop Overlay -->
          <div class="fsb-drop-overlay" id="fsbDropOverlay" style="display:none;">
            <div class="fsb-drop-box">
              <i class="ph-bold ph-upload-simple"></i>
              <strong>Solte qualquer arquivo aqui</strong>
              <span>Análise forense, heurística de criptografia e inspeção de binários</span>
            </div>
          </div>

          <div class="fsb-conv-toolbar">
            <button type="button" class="fsb-conv-btn primary" id="fsbNewChatBtn" title="Iniciar Nova Conversa"><i class="ph-bold ph-plus"></i> Nova Conversa</button>
            <button type="button" class="fsb-conv-btn" id="fsbHistoryBtn" title="Ver Histórico de Conversas"><i class="ph-bold ph-clock-counter-clockwise"></i> Histórico (<span id="fsbHistoryCount">0</span>)</button>
          </div>

          <!-- History Drawer Overlay -->
          <div class="fsb-history-drawer" id="fsbHistoryDrawer" style="display:none;">
            <div class="fsb-history-header">
              <span><i class="ph-bold ph-chats-circle" style="color:#22d3ee; margin-right:6px;"></i> Histórico de Conversas</span>
              <button type="button" class="fsb-icon-btn" id="fsbCloseHistoryBtn" title="Fechar Histórico"><i class="ph-bold ph-x"></i></button>
            </div>
            <div class="fsb-history-list" id="fsbHistoryList"></div>
          </div>

          <div class="fsb-messages" id="fsbChatMessages">
            <div class="fsb-msg bot">
              <div class="fsb-msg-sender"><i class="ph-bold ph-robot"></i> Mascote Fênix</div>
              <div class="fsb-bubble">Olá, operador! Estou conectado ao Fênix Kernel. O que deseja executar hoje?</div>
            </div>
          </div>
          <div class="fsb-chips-row">
            <button class="fsb-chip" data-cmd="/vps-status"><i class="ph-bold ph-hard-drives"></i> Status VPS</button>
            <button class="fsb-chip" data-cmd="/health"><i class="ph-bold ph-shield-check"></i> Integridade</button>
            <button class="fsb-chip" data-cmd="/memory"><i class="ph-bold ph-brain"></i> Memória</button>
            <button class="fsb-chip" data-cmd="/agents"><i class="ph-bold ph-users-three"></i> Agentes</button>
          </div>
          <div class="fsb-input-wrap">
            <input type="file" id="fsbFileInput" style="display:none;" multiple>
            <button type="button" class="fsb-attach-btn" id="fsbAttachBtn" title="Anexar qualquer arquivo (APK, IPA, PDF, DOCX, ZIP, Imagens, Vídeos, Binários...)"><i class="ph-bold ph-paperclip"></i></button>
            <textarea class="fsb-input" id="fsbChatInput" rows="1" placeholder="Envie uma mensagem ou anexe arquivos…"></textarea>
            <button class="fsb-send-btn" id="fsbSendBtn" title="Enviar"><i class="ph-bold ph-paper-plane-right"></i></button>
          </div>
        </div>

        <!-- Painel Telemetria -->
        <div class="fsb-panel" id="fsbPanelTelemetry">
          <div class="fsb-telemetry-content">
            <div class="fsb-status-banner">
              <i class="ph-bold ph-shield-check"></i>
              <span>FÊNIX OS KERNEL: <strong id="fsbTelemKernelState">ONLINE</strong></span>
            </div>
            <div class="fsb-meter-grid">
              <div class="fsb-meter-card">
                <span class="fsb-meter-label">CPU Host</span>
                <span class="fsb-meter-val" id="fsbTelemCpu">—</span>
              </div>
              <div class="fsb-meter-card">
                <span class="fsb-meter-label">RAM Em Uso</span>
                <span class="fsb-meter-val" id="fsbTelemRam">—</span>
              </div>
              <div class="fsb-meter-card">
                <span class="fsb-meter-label">Latência VPS</span>
                <span class="fsb-meter-val" id="fsbTelemLatency">—</span>
              </div>
              <div class="fsb-meter-card">
                <span class="fsb-meter-label">Uptime</span>
                <span class="fsb-meter-val" id="fsbTelemUptime">—</span>
              </div>
              <div class="fsb-meter-card">
                <span class="fsb-meter-label">Jobs Ativos</span>
                <span class="fsb-meter-val" id="fsbTelemJobs">—</span>
              </div>
              <div class="fsb-meter-card">
                <span class="fsb-meter-label">API Platform</span>
                <span class="fsb-meter-val" id="fsbTelemApiPlatform">—</span>
              </div>
            </div>
            <button class="fenix-subnav-btn" id="fsbRefreshTelemBtn" style="margin-top:10px;"><i class="ph-bold ph-arrows-clockwise"></i> Atualizar Telemetria</button>
          </div>
        </div>

        <!-- Painel Logs -->
        <div class="fsb-panel" id="fsbPanelLogs">
          <div style="display:flex; justify-content:space-between; align-items:center; padding:8px 14px; border-bottom:1px solid rgba(255,255,255,0.06); font-size:11px; color:#94a3b8; background:rgba(0,0,0,0.2);">
            <span><i class="ph-bold ph-activity"></i> Eventos Operacionais do Sistema</span>
            <button type="button" class="fsb-icon-btn" id="fsbClearLogsBtn" title="Limpar Logs" style="padding:2px 8px; font-size:11px;"><i class="ph-bold ph-trash"></i> Limpar</button>
          </div>
          <div class="fsb-logs-content" id="fsbLogsContainer">
            <div class="fsb-log-row">
              <span class="fsb-log-time">--:--:--</span>
              <span class="fsb-log-tag info">BOOT</span>
              <span class="fsb-log-text">Sidebar operacional conectada ao EventBus.</span>
            </div>
          </div>
        </div>

        <!-- Painel Mini Terminal -->
        <div class="fsb-panel" id="fsbPanelTerminal">
          <div class="fsb-terminal-content">
            <div class="fsb-terminal-output" id="fsbTerminalOutput">Fênix OS Live Terminal [Version 2.1.0]&#10;Digite 'help' ou comandos shell para executar.&#10;</div>
            <div class="fsb-terminal-input-row">
              <span class="fsb-terminal-prompt">fenix&gt;</span>
              <input type="text" class="fsb-terminal-input" id="fsbTerminalInput" autocomplete="off" spellcheck="false">
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(sb);
      sidebarEl = sb;
    } else {
      sidebarEl = document.getElementById('fenix-right-sidebar');
    }

    // 2. Mascote Flutuante (#fenix-floating-mascot)
    if (!document.getElementById('fenix-floating-mascot')) {
      const mf = document.createElement('div');
      mf.id = 'fenix-floating-mascot';
      mf.className = state.isOpen ? 'hidden' : '';
      mf.innerHTML = `
        <div class="ffm-tooltip">Fênix OS Online · Clique para abrir Chat</div>
        <div class="ffm-badge" id="ffmBadge">1</div>
        <div class="ffm-pod">
          <div class="ffm-sprite">
            <div class="ffm-body">
              <div class="ffm-visor">
                <span class="ffm-eye" id="ffmEyeLeft">^</span>
                <span class="ffm-eye" id="ffmEyeRight">^</span>
              </div>
            </div>
            <div class="ffm-hands">
              <div class="ffm-hand"></div>
              <div class="ffm-hand"></div>
            </div>
            <div class="ffm-laptop">
              <div class="ffm-laptop-screen">&gt;_</div>
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(mf);
      mascotEl = mf;
    } else {
      mascotEl = document.getElementById('fenix-floating-mascot');
    }

    // 3. Modal de Dossiê RPG e Customizer (#fenixAgentDossierModal)
    if (!document.getElementById('fenixAgentDossierModal')) {
      const md = document.createElement('div');
      md.id = 'fenixAgentDossierModal';
      md.innerHTML = `
        <div class="fad-modal-card">
          <div class="fad-header">
            <div class="fad-title-wrap">
              <i class="ph-bold ph-game-controller" style="font-size:22px; color:#22d3ee;"></i>
              <div class="fad-title" id="fadAgentTitle">DOSSIÊ DO AGENTE</div>
            </div>
            <button class="fad-close-btn" id="fadCloseBtn"><i class="ph-bold ph-x"></i></button>
          </div>
          <div class="fad-body">
            <!-- Coluna Esquerda: Avatar RPG & Estúdio Habbo/Tibia -->
            <div class="fad-avatar-col">
              <div class="fad-avatar-stage">
                <canvas id="fadPixelCanvas" class="fad-pixel-canvas" width="64" height="96"></canvas>
                <div style="font-size:11px; font-weight:800; color:#22d3ee; margin-top:8px;" id="fadRoleName">DEVELOPER</div>
              </div>
              
              <div class="fad-studio-section">
                <div class="fad-studio-label">Tom de Pele</div>
                <div class="fad-color-palette" id="fadSkinPalette"></div>
              </div>

              <div class="fad-studio-section">
                <div class="fad-studio-label">Cor do Cabelo</div>
                <div class="fad-color-palette" id="fadHairPalette"></div>
              </div>

              <div class="fad-studio-section">
                <div class="fad-studio-label">Cor do Traje</div>
                <div class="fad-color-palette" id="fadShirtPalette"></div>
              </div>
            </div>

            <!-- Coluna Direita: Abas de Ramificações, Detalhes e Chat Direto -->
            <div class="fad-details-col">
              <div class="fad-tabs">
                <button class="fad-tab-btn active" data-fpan="specs">Especialidade & Stats</button>
                <button class="fad-tab-btn" data-fpan="tree">Ramificações (Árvore)</button>
                <button class="fad-tab-btn" data-fpan="chat">Chat Direto 1-a-1</button>
              </div>

              <!-- Painel Stats -->
              <div class="fad-tab-pane active" id="fadPaneSpecs">
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                  <div class="fsb-meter-card">
                    <span class="fsb-meter-label">Função Operacional</span>
                    <span style="font-weight:700; color:#f8fafc;" id="fadSpecRole">—</span>
                  </div>
                  <div class="fsb-meter-card">
                    <span class="fsb-meter-label">Estado Atual</span>
                    <span style="font-weight:700; color:#10b981;" id="fadSpecStatus">—</span>
                  </div>
                  <div class="fsb-meter-card">
                    <span class="fsb-meter-label">Modelo LLM</span>
                    <span style="font-weight:700; color:#38bdf8;" id="fadSpecModel">qwen2.5:3b</span>
                  </div>
                  <div class="fsb-meter-card">
                    <span class="fsb-meter-label">Tokens Processados</span>
                    <span style="font-weight:700; color:#a78bfa;" id="fadSpecTokens">—</span>
                  </div>
                </div>
                <div style="margin-top:10px;">
                  <span class="fsb-meter-label">Capacidades Mapeadas</span>
                  <div id="fadCapabilitiesChips" style="display:flex; gap:6px; flex-wrap:wrap; margin-top:6px;"></div>
                </div>
              </div>

              <!-- Painel Ramificações / Subagentes -->
              <div class="fad-tab-pane" id="fadPaneTree">
                <div style="font-size:12px; color:#94a3b8; margin-bottom:8px;">Linhagem hierárquica e subagentes subordinados no Company Brain:</div>
                <div id="fadTreeHierarchy" style="background:rgba(0,0,0,0.4); padding:12px; border-radius:8px; border:1px solid rgba(255,255,255,0.06); font-family:monospace; font-size:12px; line-height:1.6; color:#38bdf8;">
                  FÊNIX KERNEL (Nível 0)&#10;  └── CEO Brain (Executivo)&#10;        └── <span id="fadTreeNodeName">Agente Selecionado</span>&#10;              ├── Subagente de Triagem&#10;              └── Executor de Tarefas
                </div>
              </div>

              <!-- Painel Chat Direto -->
              <div class="fad-tab-pane" id="fadPaneChat">
                <div id="fadDirectChatMessages" style="height:200px; overflow-y:auto; background:rgba(0,0,0,0.3); border-radius:8px; padding:10px; display:flex; flex-direction:column; gap:8px;">
                  <div class="fsb-msg bot">
                    <div class="fsb-bubble" id="fadDirectWelcome">Canal direto ativo. Pronto para receber tarefas específicas.</div>
                  </div>
                </div>
                <div style="display:flex; gap:8px; margin-top:8px;">
                  <input type="text" class="fsb-input" id="fadDirectInput" placeholder="Mensagem direta para o agente…">
                  <button class="fsb-send-btn" id="fadDirectSendBtn"><i class="ph-bold ph-paper-plane-right"></i></button>
                </div>
              </div>
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(md);
      modalEl = md;
    } else {
      modalEl = document.getElementById('fenixAgentDossierModal');
    }
  }

  // ── Controlador de Expressões e Animações do Mascote ──
  const MascotController = {
    setMood(mood) {
      state.mascotMood = mood;
      const leftEye = document.getElementById('ffmEyeLeft');
      const rightEye = document.getElementById('ffmEyeRight');
      if (!mascotEl || !leftEye || !rightEye) return;

      mascotEl.classList.remove('working', 'error', 'success');

      switch (mood) {
        case 'thinking':
          leftEye.textContent = 'o';
          rightEye.textContent = 'o';
          break;
        case 'working':
          leftEye.textContent = '>';
          rightEye.textContent = '<';
          mascotEl.classList.add('working');
          break;
        case 'success':
          leftEye.textContent = '*';
          rightEye.textContent = '*';
          mascotEl.classList.add('success');
          setTimeout(() => this.setMood('idle'), 3500);
          break;
        case 'error':
          leftEye.textContent = '!';
          rightEye.textContent = '!';
          mascotEl.classList.add('error');
          setTimeout(() => this.setMood('idle'), 4000);
          break;
        case 'idle':
        default:
          leftEye.textContent = '^';
          rightEye.textContent = '^';
          break;
      }
    },

    toggle() {
      state.isOpen = !state.isOpen;
      localStorage.setItem('fenix_sidebar_state', state.isOpen ? 'open' : 'minimized');
      document.body.classList.toggle('has-right-sidebar-open', state.isOpen);
      if (state.isOpen) {
        sidebarEl?.classList.add('open');
        mascotEl?.classList.add('hidden');
        document.getElementById('fsbChatInput')?.focus();
      } else {
        sidebarEl?.classList.remove('open');
        mascotEl?.classList.remove('hidden');
      }
      setTimeout(() => window.dispatchEvent(new Event('resize')), 50);
    },

    initDrag() {
      if (!mascotEl) return;
      let isDragging = false;
      let startX, startY, initialRight, initialBottom;

      mascotEl.addEventListener('mousedown', (e) => {
        if (e.target.closest('.ffm-pod')) {
          isDragging = false;
          startX = e.clientX;
          startY = e.clientY;
          const rect = mascotEl.getBoundingClientRect();
          initialRight = window.innerWidth - rect.right;
          initialBottom = window.innerHeight - rect.bottom;

          const onMouseMove = (moveEvent) => {
            const dx = moveEvent.clientX - startX;
            const dy = moveEvent.clientY - startY;
            if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
              isDragging = true;
              mascotEl.style.right = `${Math.max(10, initialRight - dx)}px`;
              mascotEl.style.bottom = `${Math.max(10, initialBottom - dy)}px`;
            }
          };

          const onMouseUp = () => {
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
            if (!isDragging) {
              MascotController.toggle();
            }
          };

          document.addEventListener('mousemove', onMouseMove);
          document.addEventListener('mouseup', onMouseUp);
        }
      });
    }
  };

  // ── Controlador da Sidebar Direita ──
  const SidebarController = {
    initEvents() {
      // Toggle / Minimize
      document.getElementById('fsbMinimizeBtn')?.addEventListener('click', () => MascotController.toggle());
      document.getElementById('fsbClearBtn')?.addEventListener('click', () => this.clearChat());

      // Multi-Conversation History
      document.getElementById('fsbNewChatBtn')?.addEventListener('click', () => this.startNewConversation());
      document.getElementById('fsbHistoryBtn')?.addEventListener('click', () => this.toggleHistoryDrawer());
      document.getElementById('fsbCloseHistoryBtn')?.addEventListener('click', () => this.toggleHistoryDrawer(false));

      // Tabs
      document.querySelectorAll('.fsb-tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const tab = btn.dataset.tab;
          this.switchTab(tab);
        });
      });

      // Chips
      document.querySelectorAll('.fsb-chip').forEach(chip => {
        chip.addEventListener('click', () => {
          const cmd = chip.dataset.cmd;
          this.handleCommand(cmd);
        });
      });

      // Chat Input
      const chatInput = document.getElementById('fsbChatInput');
      const sendBtn = document.getElementById('fsbSendBtn');
      chatInput?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          this.sendChatMessage();
        }
      });
      sendBtn?.addEventListener('click', () => this.sendChatMessage());

      // Universal File Attachment & Drag and Drop
      const fileInput = document.getElementById('fsbFileInput');
      const attachBtn = document.getElementById('fsbAttachBtn');
      const dropOverlay = document.getElementById('fsbDropOverlay');
      const panelChat = document.getElementById('fsbPanelChat');

      attachBtn?.addEventListener('click', () => fileInput?.click());
      fileInput?.addEventListener('change', (e) => {
        if (e.target.files && e.target.files.length > 0) {
          this.handleIncomingFiles(e.target.files);
          fileInput.value = '';
        }
      });

      if (panelChat) {
        panelChat.addEventListener('dragover', (e) => {
          e.preventDefault();
          if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
          if (dropOverlay) dropOverlay.style.display = 'flex';
        });
        panelChat.addEventListener('dragleave', (e) => {
          if (!panelChat.contains(e.relatedTarget) && dropOverlay) {
            dropOverlay.style.display = 'none';
          }
        });
        panelChat.addEventListener('drop', (e) => {
          e.preventDefault();
          if (dropOverlay) dropOverlay.style.display = 'none';
          if (e.dataTransfer?.files?.length > 0) {
            this.handleIncomingFiles(e.dataTransfer.files);
          }
        });
        panelChat.addEventListener('paste', (e) => {
          if (e.clipboardData?.files?.length > 0) {
            e.preventDefault();
            this.handleIncomingFiles(e.clipboardData.files);
          }
        });
      }

      // Mini Terminal Input
      const termInput = document.getElementById('fsbTerminalInput');
      termInput?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          const val = termInput.value.trim();
          if (val) {
            this.execTerminalCommand(val);
            termInput.value = '';
          }
        }
      });

      // Refresh Telemetry Button
      document.getElementById('fsbRefreshTelemBtn')?.addEventListener('click', () => this.fetchTelemetry(true));

      // Resize Handle (Drag-to-resize Lovable Style)
      const resizeHandle = document.getElementById('fsbResizeHandle');
      if (resizeHandle) {
        let isResizing = false;
        resizeHandle.addEventListener('mousedown', (e) => {
          isResizing = true;
          resizeHandle.classList.add('active');
          document.body.classList.add('fsb-resizing');
          e.preventDefault();
        });
        window.addEventListener('mousemove', (e) => {
          if (!isResizing) return;
          const newWidth = Math.max(280, Math.min(window.innerWidth - 120, window.innerWidth - e.clientX));
          document.documentElement.style.setProperty('--fsb-width', `${newWidth}px`);
          localStorage.setItem('fenix_sidebar_width', `${newWidth}px`);
        });
        window.addEventListener('mouseup', () => {
          if (isResizing) {
            isResizing = false;
            resizeHandle.classList.remove('active');
            document.body.classList.remove('fsb-resizing');
            window.dispatchEvent(new Event('resize'));
          }
        });
      }

      // Docked Mode Toggle (Lovable Split Screen)
      const dockBtn = document.getElementById('fsbDockBtn');
      const updateDockBtn = () => {
        if (!dockBtn) return;
        const text = document.getElementById('fsbDockBtnText');
        dockBtn.classList.toggle('active', state.isDocked);
        document.body.classList.toggle('fsb-docked', state.isDocked);
        if (text) text.textContent = state.isDocked ? 'Split' : 'Float';
        dockBtn.title = state.isDocked ? 'Modo Split Screen (Tela ajustada sem sobreposição)' : 'Modo Flutuante (Sobreposição livre)';
      };

      dockBtn?.addEventListener('click', () => {
        state.isDocked = !state.isDocked;
        localStorage.setItem('fenix_sidebar_docked', String(state.isDocked));
        updateDockBtn();
        setTimeout(() => window.dispatchEvent(new Event('resize')), 50);
      });

      // Clear Logs
      document.getElementById('fsbClearLogsBtn')?.addEventListener('click', () => {
        const logsContainer = document.getElementById('fsbLogsContainer');
        if (logsContainer) {
          logsContainer.innerHTML = `
            <div class="fsb-log-row">
              <span class="fsb-log-time">${new Date().toLocaleTimeString('pt-BR')}</span>
              <span class="fsb-log-tag info">LOGS</span>
              <span class="fsb-log-text">Logs reinicializados pelo operador.</span>
            </div>
          `;
        }
      });
    },

    switchTab(tab) {
      state.activeTab = tab;
      document.querySelectorAll('.fsb-tab-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.tab === tab);
      });
      document.querySelectorAll('.fsb-panel').forEach(p => p.classList.remove('active'));
      const activePanel = document.getElementById(`fsbPanel${tab.charAt(0).toUpperCase() + tab.slice(1)}`);
      activePanel?.classList.add('active');

      if (tab === 'telemetry') this.fetchTelemetry();
    },

    startLoadingTimer() {
      this.stopLoadingTimer();
      const container = document.getElementById('fsbChatMessages');
      if (!container) return;
      const loadingEl = document.createElement('div');
      loadingEl.className = 'fsb-msg bot typing';
      loadingEl.id = 'fsbLiveLoadingMsg';
      loadingEl.innerHTML = `
        <div class="fsb-msg-sender"><i class="ph-bold ph-robot"></i> Mascote Fênix</div>
        <div class="fsb-bubble fsb-loading-bubble">
          <div class="fsb-loading-dots"><span></span><span></span><span></span></div>
          <span class="fsb-loading-timer"><i class="ph-bold ph-hourglass-high"></i> Processando resposta… <strong id="fsbLiveTimerValue">0.0s</strong></span>
        </div>
      `;
      container.appendChild(loadingEl);
      container.scrollTop = container.scrollHeight;

      let elapsedSec = 0;
      this._liveTimerInterval = setInterval(() => {
        elapsedSec += 0.1;
        const timerVal = document.getElementById('fsbLiveTimerValue');
        if (timerVal) timerVal.textContent = elapsedSec.toFixed(1) + 's';
      }, 100);
    },

    stopLoadingTimer() {
      if (this._liveTimerInterval) {
        clearInterval(this._liveTimerInterval);
        this._liveTimerInterval = null;
      }
      const el = document.getElementById('fsbLiveLoadingMsg');
      if (el) el.remove();
    },

    renderMarkdown(content) {
      if (!content) return '';
      let text = String(content);

      // Limpar tags brutas vazadas
      text = text.replace(/<br\s*\/?>/gi, '\n');
      text = text.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi, '$1');

      let html = this.escapeHTML(text);

      // Blocos de código ```lang\ncode```
      html = html.replace(/```([a-z0-9_-]*)\n([\s\S]*?)```/g, (match, lang, code) => {
        return `<pre class="fsb-code-block"><div class="fsb-code-header"><span>${lang || 'código'}</span><button type="button" class="fsb-code-copy-btn" onclick="window.FenixSidebar.copyCode(this)"><i class="ph-bold ph-copy"></i> Copiar</button></div><code>${code.trim()}</code></pre>`;
      });

      // Código inline `code`
      html = html.replace(/`([^`]+)`/g, '<code class="fsb-inline-code">$1</code>');

      // Negrito **texto**
      html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');

      // Itálico *texto*
      html = html.replace(/(^|[^*])\*([^*]+)\*([^*]|$)/g, '$1<em>$2</em>$3');

      // Listas • ou -
      html = html.replace(/^[•\-]\s+(.+)$/gm, '<li class="fsb-list-item">$1</li>');
      html = html.replace(/((?:<li class="fsb-list-item">.*?<\/li>\s*)+)/g, '<ul class="fsb-list">$1</ul>');

      // Parágrafos e quebras
      html = html.replace(/\n\n+/g, '</p><p>');
      html = html.replace(/\n/g, '<br>');

      return `<p>${html}</p>`;
    },

    // ── Multi-Conversation & Evolutionary Memory System ──
    initConversations() {
      let stored = [];
      try {
        stored = JSON.parse(localStorage.getItem('fenix_chat_conversations') || '[]');
      } catch (_) {}
      if (!Array.isArray(stored) || stored.length === 0) {
        stored = [{
          id: 'conv_' + Date.now(),
          title: 'Sessão Inicial · Fênix OS',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          messages: [{
            type: 'text',
            role: 'bot',
            text: 'Olá, operador! Estou conectado ao Fênix Kernel. O que deseja executar hoje?',
            senderName: 'Mascote Fênix',
            timestamp: new Date().toISOString()
          }]
        }];
      }
      state.conversations = stored;
      const activeId = localStorage.getItem('fenix_active_conv_id');
      state.activeConversationId = (activeId && stored.some(c => c.id === activeId)) ? activeId : stored[0].id;
      this.updateConversationCount();
      this.renderActiveConversation();
    },

    updateConversationCount() {
      const el = document.getElementById('fsbHistoryCount');
      if (el) el.textContent = String(state.conversations.length);
    },

    saveConversations() {
      localStorage.setItem('fenix_chat_conversations', JSON.stringify(state.conversations));
      localStorage.setItem('fenix_active_conv_id', state.activeConversationId);
      this.updateConversationCount();
    },

    getActiveConversation() {
      return state.conversations.find(c => c.id === state.activeConversationId) || state.conversations[0];
    },

    renderActiveConversation() {
      const container = document.getElementById('fsbChatMessages');
      if (!container) return;
      container.innerHTML = '';
      const conv = this.getActiveConversation();
      if (!conv || !Array.isArray(conv.messages)) return;
      conv.messages.forEach(m => {
        if (m.type === 'job') {
          this.renderJobMessageInDOM(m.data, m.prompt, m.elapsedMs);
        } else if (m.type === 'bot') {
          this.renderBotMessageInDOM(m.data, m.prompt, m.elapsedMs);
        } else if (m.type === 'forensic') {
          this.renderForensicCardInDOM(m.data);
        } else {
          this.renderMessageInDOM(m.role, m.text, m.senderName);
        }
      });
      container.scrollTop = container.scrollHeight;
    },

    startNewConversation() {
      const newConv = {
        id: 'conv_' + Date.now(),
        title: 'Nova Conversa',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        messages: [{
          type: 'text',
          role: 'bot',
          text: 'Nova sessão iniciada. O contexto cognitivo está ativo e pronto para registrar evolução. O que vamos programar ou executar?',
          senderName: 'Mascote Fênix',
          timestamp: new Date().toISOString()
        }]
      };
      state.conversations.unshift(newConv);
      state.activeConversationId = newConv.id;
      this.saveConversations();
      this.renderActiveConversation();
      this.toggleHistoryDrawer(false);
      this.logActivity('CONV', 'Nova sessão de conversa iniciada.');
      this.recordEvolutionaryCheckpoint('NEW_CONVERSATION', { convId: newConv.id });
    },

    switchConversation(id) {
      if (state.conversations.some(c => c.id === id)) {
        state.activeConversationId = id;
        this.saveConversations();
        this.renderActiveConversation();
        this.toggleHistoryDrawer(false);
        this.logActivity('CONV', `Sessão restaurada: ${id}`);
      }
    },

    deleteConversation(id, event) {
      if (event) event.stopPropagation();
      state.conversations = state.conversations.filter(c => c.id !== id);
      if (state.conversations.length === 0) {
        this.startNewConversation();
        return;
      }
      if (state.activeConversationId === id) {
        state.activeConversationId = state.conversations[0].id;
      }
      this.saveConversations();
      this.renderActiveConversation();
      this.renderHistoryDrawerList();
    },

    toggleHistoryDrawer(forceState) {
      const drawer = document.getElementById('fsbHistoryDrawer');
      if (!drawer) return;
      const shouldShow = typeof forceState === 'boolean' ? forceState : (drawer.style.display === 'none');
      drawer.style.display = shouldShow ? 'flex' : 'none';
      if (shouldShow) this.renderHistoryDrawerList();
    },

    renderHistoryDrawerList() {
      const list = document.getElementById('fsbHistoryList');
      if (!list) return;
      if (state.conversations.length === 0) {
        list.innerHTML = `<div class="fsb-history-empty"><i class="ph-bold ph-chats" style="font-size:24px; color:#64748b; margin-bottom:8px; display:inline-block;"></i><br>Nenhuma conversa gravada.</div>`;
        return;
      }
      list.innerHTML = state.conversations.map(c => {
        const isActive = c.id === state.activeConversationId;
        const count = (c.messages || []).length;
        const dateStr = new Date(c.updatedAt || c.createdAt).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
        return `
          <div class="fsb-history-item ${isActive ? 'active' : ''}" onclick="window.FenixSidebar.switchConversation('${c.id}')">
            <div class="fsb-history-info">
              <span class="fsb-history-title">${this.escapeHTML(c.title || 'Conversa')}</span>
              <div class="fsb-history-meta">
                <span><i class="ph-bold ph-clock"></i> ${dateStr}</span>
                <span><i class="ph-bold ph-chat-teardrop"></i> ${count} msgs</span>
              </div>
            </div>
            <button type="button" class="fsb-history-del-btn" title="Excluir conversa" onclick="window.FenixSidebar.deleteConversation('${c.id}', event)"><i class="ph-bold ph-trash"></i></button>
          </div>
        `;
      }).join('');
    },

    recordEvolutionaryCheckpoint(eventType, payload) {
      try {
        authedFetch('/api/v2/system/telemetry', {
          method: 'POST',
          body: JSON.stringify({
            type: 'evolution.checkpoint',
            eventType,
            payload,
            timestamp: new Date().toISOString()
          })
        }).catch(() => {});
      } catch (_) {}
      this.setDOMText('tickerKernelStatus', 'MEMÓRIA ATIVA SINCRONIZADA');
    },

    renderMessageInDOM(role, text, senderName = null) {
      const container = document.getElementById('fsbChatMessages');
      if (!container) return;
      const msg = document.createElement('div');
      msg.className = `fsb-msg ${role}`;
      const name = senderName || (role === 'user' ? 'Operador' : 'Mascote Fênix');
      msg.innerHTML = `
        <div class="fsb-msg-sender">${role === 'user' ? '<i class="ph-bold ph-user"></i>' : '<i class="ph-bold ph-robot"></i>'} ${name}</div>
        <div class="fsb-bubble">${role === 'user' ? this.escapeHTML(text) : this.renderMarkdown(text)}</div>
      `;
      container.appendChild(msg);
      container.scrollTop = container.scrollHeight;
    },

    appendMessage(role, text, senderName = null) {
      this.renderMessageInDOM(role, text, senderName);
      const conv = this.getActiveConversation();
      if (conv) {
        if (!conv.messages) conv.messages = [];
        conv.messages.push({ type: 'text', role, text, senderName, timestamp: new Date().toISOString() });
        conv.updatedAt = new Date().toISOString();
        if (role === 'user' && (conv.title === 'Nova Conversa' || conv.title.startsWith('Sessão Inicial'))) {
          conv.title = text.length > 36 ? text.slice(0, 33) + '…' : text;
        }
        this.saveConversations();
        this.recordEvolutionaryCheckpoint('USER_INPUT', { role, text: text.slice(0, 80) });
      }
    },

    renderBotMessageInDOM(data, prompt, elapsedMs = 0) {
      const container = document.getElementById('fsbChatMessages');
      if (!container) return;
      const msg = document.createElement('div');
      msg.className = 'fsb-msg bot';

      const responseText = data.response || data.reply || data.output || data.message || 'Comando avaliado com sucesso.';
      const bodyHtml = this.renderMarkdown(responseText);

      const latencyMs = Number(elapsedMs || data.latencyMs || 25);
      const timeFormatted = latencyMs >= 1000 ? (latencyMs / 1000).toFixed(2) + 's' : latencyMs + 'ms';
      const lane = data.lane || 'FAST_LANE';
      const model = data.model || data.selectedModel?.model || (lane === 'FAST_LANE' ? 'qwen2.5:0.5b' : 'qwen2.5:3b');
      const tokens = data.tokens != null ? data.tokens : (data.classification?.estimated_tokens != null ? data.classification.estimated_tokens : null);

      let actionsHtml = '';
      const actions = Array.isArray(data.actions) ? data.actions : [];
      if (actions.length > 0) {
        actionsHtml = `<div class="fsb-msg-actions">` + actions.map(act => {
          if (typeof act === 'string') {
            return `<button type="button" class="fsb-action-btn" onclick="window.FenixSidebar.handleCommand('${this.escapeHTML(act)}')">${this.escapeHTML(act)}</button>`;
          }
          const actJson = this.escapeHTML(JSON.stringify(act));
          return `<button type="button" class="fsb-action-btn" onclick="window.FenixSidebar.executeAction(JSON.parse(this.dataset.act))" data-act="${actJson}">${this.escapeHTML(act.label || 'Executar')}</button>`;
        }).join('') + `</div>`;
      }

      msg.innerHTML = `
        <div class="fsb-msg-sender"><i class="ph-bold ph-robot"></i> Mascote Fênix</div>
        <div class="fsb-bubble">
          ${bodyHtml}
          ${actionsHtml}
          <div class="fsb-msg-meta">
            <span class="fsb-meta-tag time"><i class="ph-bold ph-timer"></i> ${timeFormatted}</span>
            <span class="fsb-meta-tag lane"><i class="ph-bold ph-lightning"></i> ${this.escapeHTML(lane)}</span>
            <span class="fsb-meta-tag model"><i class="ph-bold ph-cpu"></i> ${this.escapeHTML(model)}</span>
            ${tokens != null ? `<span class="fsb-meta-tag tokens"><i class="ph-bold ph-coins"></i> ${tokens} tokens</span>` : ''}
          </div>
        </div>
      `;
      container.appendChild(msg);
      container.scrollTop = container.scrollHeight;
    },

    appendBotMessage(data, prompt, elapsedMs = 0) {
      this.renderBotMessageInDOM(data, prompt, elapsedMs);
      const conv = this.getActiveConversation();
      if (conv) {
        if (!conv.messages) conv.messages = [];
        conv.messages.push({ type: 'bot', data, prompt, elapsedMs, timestamp: new Date().toISOString() });
        conv.updatedAt = new Date().toISOString();
        this.saveConversations();
        this.recordEvolutionaryCheckpoint('BOT_RESPONSE', { lane: data.lane, prompt: (prompt || '').slice(0, 60) });
      }
    },

    clearChat() {
      const conv = this.getActiveConversation();
      if (conv) {
        conv.messages = [{
          type: 'text',
          role: 'bot',
          text: 'Chat limpo. Como posso ajudar?',
          senderName: 'Mascote Fênix',
          timestamp: new Date().toISOString()
        }];
        conv.updatedAt = new Date().toISOString();
        this.saveConversations();
        this.renderActiveConversation();
      }
    },

    getJobStatusBadgeHtml(jobId, status, requiresConf) {
      const s = String(status || 'QUEUED').toUpperCase();
      const safeId = this.escapeHTML(jobId);
      if (s === 'RUNNING' || s === 'ACTIVE') {
        return `<span class="fsb-job-status running" id="fsbJob_${safeId}_status"><span class="fsb-pulse-dot"></span> EXECUTANDO EM SEGUNDO PLANO</span>`;
      }
      if (s === 'PENDING_CONFIRMATION' || s === 'AWAITING_APPROVAL' || requiresConf) {
        return `<span class="fsb-job-status pending" id="fsbJob_${safeId}_status"><span class="fsb-pulse-dot amber"></span> AGUARDANDO APROVAÇÃO</span>`;
      }
      if (s === 'PAUSED') {
        return `<span class="fsb-job-status paused" id="fsbJob_${safeId}_status"><i class="ph-bold ph-pause"></i> PAUSADO</span>`;
      }
      if (s === 'COMPLETED' || s === 'SUCCEEDED') {
        return `<span class="fsb-job-status completed" id="fsbJob_${safeId}_status"><i class="ph-bold ph-check-circle"></i> CONCLUÍDO</span>`;
      }
      if (s === 'CANCELLED') {
        return `<span class="fsb-job-status cancelled" id="fsbJob_${safeId}_status"><i class="ph-bold ph-x-circle"></i> CANCELADO</span>`;
      }
      return `<span class="fsb-job-status queued" id="fsbJob_${safeId}_status"><i class="ph-bold ph-clock"></i> NA FILA BULLMQ</span>`;
    },

    getJobProgressDetails(job, data) {
      const s = String(job.status || 'QUEUED').toUpperCase();
      let pct = 0;
      let eta = 'Estimativa ~20s';
      const estSec = Number(job.estimatedTimeSec || data?.classification?.estimated_time || 20);

      if (s === 'COMPLETED' || s === 'SUCCEEDED') {
        pct = 100;
        eta = 'Finalizado com sucesso';
      } else if (s === 'CANCELLED') {
        pct = 0;
        eta = 'Cancelado pelo operador';
      } else if (s === 'PAUSED') {
        pct = job.progress != null ? Number(job.progress) : 40;
        eta = 'Execução em pausa';
      } else if (s === 'RUNNING' || s === 'ACTIVE') {
        const start = job.startedAt ? new Date(job.startedAt).getTime() : (job.createdAt ? new Date(job.createdAt).getTime() : Date.now());
        const elapsedSec = Math.max(1, Math.round((Date.now() - start) / 1000));
        const remSec = Math.max(1, estSec - elapsedSec);
        pct = job.progress != null ? Math.min(100, Math.max(0, Number(job.progress))) : Math.min(92, Math.max(25, Math.round((elapsedSec / estSec) * 100)));
        eta = `Prazo: ~${remSec}s | Decorrido: ${elapsedSec}s`;
      } else if (s === 'QUEUED') {
        pct = 10;
        eta = `Fila BullMQ · Estimativa ~${estSec}s`;
      } else if (s === 'PENDING_CONFIRMATION' || s === 'AWAITING_APPROVAL') {
        pct = 0;
        eta = 'Aguardando autorização do operador';
      }
      return { pct, eta, estSec };
    },

    getJobTokenDetails(job, data, progressPct) {
      const s = String(job.status || 'QUEUED').toUpperCase();
      const estTokens = Number(job.estimatedTokens || data?.classification?.estimated_tokens || 0);
      let actTokens = 0;
      if (job.tokens && typeof job.tokens === 'object') {
        actTokens = Number(job.tokens.actual || job.tokens.total || 0);
      } else if (typeof job.tokens === 'number') {
        actTokens = job.tokens;
      }
      if (!actTokens && estTokens > 0) {
        if (s === 'COMPLETED' || s === 'SUCCEEDED') {
          actTokens = estTokens;
        } else if (s === 'RUNNING') {
          actTokens = Math.round(estTokens * (progressPct / 100));
        } else {
          actTokens = 0;
        }
      }
      const tokenPct = estTokens > 0 ? Math.min(100, Math.round((actTokens / estTokens) * 100)) : 0;
      return { estTokens, actTokens, tokenPct };
    },

    getJobActionsHtml(jobId, status, requiresConf) {
      const s = String(status || 'QUEUED').toUpperCase();
      const safeId = this.escapeHTML(jobId);
      if (s === 'PENDING_CONFIRMATION' || s === 'AWAITING_APPROVAL' || requiresConf) {
        return `
          <div class="fsb-job-actions-row" id="fsbJob_${safeId}_actions">
            <button type="button" class="fsb-job-btn approve" onclick="window.FenixSidebar.approveJob('${safeId}')"><i class="ph-bold ph-check-circle"></i> Aprovar & Executar</button>
            <button type="button" class="fsb-job-btn cancel" onclick="window.FenixSidebar.cancelJob('${safeId}')"><i class="ph-bold ph-x-circle"></i> Cancelar</button>
          </div>
        `;
      }
      if (s === 'RUNNING' || s === 'ACTIVE' || s === 'QUEUED') {
        return `
          <div class="fsb-job-actions-row" id="fsbJob_${safeId}_actions">
            <button type="button" class="fsb-job-btn pause" onclick="window.FenixSidebar.pauseJob('${safeId}')"><i class="ph-bold ph-pause"></i> Pausar</button>
            <button type="button" class="fsb-job-btn cancel" onclick="window.FenixSidebar.cancelJob('${safeId}')"><i class="ph-bold ph-stop"></i> Cancelar</button>
            <button type="button" class="fsb-job-btn secondary" onclick="window.showView('operations')"><i class="ph-bold ph-arrow-square-out"></i> Ver Fila</button>
          </div>
        `;
      }
      if (s === 'PAUSED') {
        return `
          <div class="fsb-job-actions-row" id="fsbJob_${safeId}_actions">
            <button type="button" class="fsb-job-btn resume" onclick="window.FenixSidebar.resumeJob('${safeId}')"><i class="ph-bold ph-play"></i> Retomar</button>
            <button type="button" class="fsb-job-btn cancel" onclick="window.FenixSidebar.cancelJob('${safeId}')"><i class="ph-bold ph-stop"></i> Cancelar</button>
          </div>
        `;
      }
      if (s === 'COMPLETED' || s === 'SUCCEEDED') {
        return `
          <div class="fsb-job-actions-row" id="fsbJob_${safeId}_actions">
            <span style="font-size: 11px; color: #10b981; display: inline-flex; align-items: center; gap: 4px;"><i class="ph-bold ph-check-circle"></i> Execução finalizada</span>
            <button type="button" class="fsb-job-btn secondary" onclick="window.showView('operations')"><i class="ph-bold ph-arrow-square-out"></i> Detalhes BullMQ</button>
          </div>
        `;
      }
      return `
        <div class="fsb-job-actions-row" id="fsbJob_${safeId}_actions">
          <span style="font-size: 11px; color: #ef4444; display: inline-flex; align-items: center; gap: 4px;"><i class="ph-bold ph-x-circle"></i> Tarefa cancelada</span>
        </div>
      `;
    },

    updateJobCardDOM(jobId, job) {
      if (!jobId || !job) return;
      const s = String(job.status || 'QUEUED').toUpperCase();
      const statusContainer = document.getElementById(`fsbJob_${jobId}_status`);
      if (statusContainer) {
        statusContainer.outerHTML = this.getJobStatusBadgeHtml(jobId, s, false);
      }

      const { pct, eta } = this.getJobProgressDetails(job, null);
      const progFill = document.getElementById(`fsbJob_${jobId}_progress_fill`);
      const progVal = document.getElementById(`fsbJob_${jobId}_progress_val`);
      if (progFill) progFill.style.width = pct + '%';
      if (progVal) progVal.innerHTML = `<strong>${pct}%</strong> · ${this.escapeHTML(eta)}`;

      const { estTokens, actTokens, tokenPct } = this.getJobTokenDetails(job, null, pct);
      const tokFill = document.getElementById(`fsbJob_${jobId}_token_fill`);
      const tokVal = document.getElementById(`fsbJob_${jobId}_token_val`);
      if (tokFill) tokFill.style.width = tokenPct + '%';
      if (tokVal) tokVal.innerHTML = `<strong>${actTokens}</strong> / ${estTokens} tokens (${tokenPct}%)`;

      const actionsContainer = document.getElementById(`fsbJob_${jobId}_actions`);
      if (actionsContainer) {
        actionsContainer.outerHTML = this.getJobActionsHtml(jobId, s, false);
      }

      // Sincronizar na memória ativa da conversa
      const conv = this.getActiveConversation();
      if (conv && Array.isArray(conv.messages)) {
        const msg = conv.messages.find(m => m.type === 'job' && (m.data?.job?.id === jobId || m.data?.job?.jobId === jobId));
        if (msg && msg.data && msg.data.job) {
          msg.data.job.status = s;
          msg.data.job.progress = pct;
          msg.data.job.tokens = { ...(msg.data.job.tokens || {}), actual: actTokens, estimated: estTokens };
          this.saveConversations();
        }
      }
    },

    trackJob(jobId, jobData) {
      if (!jobId || jobId === 'NOVO') return;
      if (!this._trackedJobs) this._trackedJobs = new Map();
      this._trackedJobs.set(String(jobId), jobData || {});
      if (!this._jobPollerTimer) {
        this._jobPollerTimer = setInterval(() => this.pollTrackedJobs(), 2500);
      }
    },

    async pollTrackedJobs() {
      if (!this._trackedJobs || this._trackedJobs.size === 0) {
        if (this._jobPollerTimer) {
          clearInterval(this._jobPollerTimer);
          this._jobPollerTimer = null;
        }
        return;
      }

      try {
        const res = await authedFetch('/api/v2/jobs');
        if (!res.ok) return;
        const data = await res.json();
        const jobs = Array.isArray(data.jobs) ? data.jobs : [];

        for (const [id, tracked] of Array.from(this._trackedJobs.entries())) {
          const found = jobs.find(j => String(j.id || j.jobId) === String(id));
          if (found) {
            this.updateJobCardDOM(id, found);
            const s = String(found.status || '').toUpperCase();
            if (s === 'COMPLETED' || s === 'SUCCEEDED') {
              this._trackedJobs.delete(id);
              MascotController.setMood('success');
              this.logActivity('JOB', `Job #${id} concluído com sucesso em segundo plano.`);
              this.recordEvolutionaryCheckpoint('JOB_COMPLETED', { jobId: id, title: found.title });
              setTimeout(() => MascotController.setMood('idle'), 3000);
            } else if (s === 'CANCELLED' || s === 'FAILED' || s === 'ERROR') {
              this._trackedJobs.delete(id);
              MascotController.setMood('idle');
              this.logActivity('JOB', `Job #${id} finalizado [${s}].`);
            }
          }
        }
        if (this._trackedJobs.size === 0 && this._jobPollerTimer) {
          clearInterval(this._jobPollerTimer);
          this._jobPollerTimer = null;
        }
        if (typeof window.syncLiveTargetTelemetry === 'function') {
          window.syncLiveTargetTelemetry();
        }
      } catch (err) {
        console.warn('[FENIX SIDEBAR] Erro no polling de jobs:', err.message);
      }
    },

    renderJobMessageInDOM(data, prompt, elapsedMs = 0) {
      const container = document.getElementById('fsbChatMessages');
      if (!container) return;
      const msg = document.createElement('div');
      msg.className = 'fsb-msg bot';
      const job = data.job || {};
      const jobId = job.id || job.jobId || 'NOVO';
      const jobTitle = job.title || prompt;
      const jobStatus = job.status || 'QUEUED';
      const model = data.selectedModel?.model || job.model || 'qwen2.5:3b';
      const requiresConf = data.confirmationRequired || Boolean(job.requiresConfirmation) || jobStatus === 'PENDING_CONFIRMATION' || jobStatus === 'AWAITING_APPROVAL';
      const latencyMs = Number(elapsedMs || data.latencyMs || 25);
      const timeFormatted = latencyMs >= 1000 ? (latencyMs / 1000).toFixed(2) + 's' : latencyMs + 'ms';

      const responseText = data.response || 'Missão estruturada registrada pelo Fênix Kernel.';

      const statusBadgeHtml = this.getJobStatusBadgeHtml(jobId, jobStatus, requiresConf);
      const { pct, eta } = this.getJobProgressDetails(job, data);
      const { estTokens, actTokens, tokenPct } = this.getJobTokenDetails(job, data, pct);
      const actionsHtml = this.getJobActionsHtml(jobId, jobStatus, requiresConf);

      msg.innerHTML = `
        <div class="fsb-msg-sender"><i class="ph-bold ph-robot"></i> Mascote Fênix</div>
        <div class="fsb-bubble">
          ${this.renderMarkdown(responseText)}
          <div class="fsb-job-card" id="fsbJobCard_${this.escapeHTML(jobId)}">
            <div class="fsb-job-header">
              <span class="fsb-job-badge"><i class="ph-bold ph-gear-six"></i> JOB #${this.escapeHTML(jobId)}</span>
              ${statusBadgeHtml}
            </div>
            <div class="fsb-job-title">${this.escapeHTML(jobTitle)}</div>
            <div class="fsb-job-meta">
              <span><i class="ph-bold ph-cpu"></i> ${this.escapeHTML(model)}</span>
              <span><i class="ph-bold ph-coins"></i> ${estTokens ? '~' + estTokens + ' tokens' : '—'}</span>
            </div>

            <!-- Barra de Progresso & ETA -->
            <div class="fsb-job-progress-section" id="fsbJob_${this.escapeHTML(jobId)}_progress_wrap">
              <div class="fsb-progress-row">
                <span class="fsb-progress-label"><i class="ph-bold ph-hourglass-medium"></i> Progresso:</span>
                <span class="fsb-progress-val" id="fsbJob_${this.escapeHTML(jobId)}_progress_val"><strong>${pct}%</strong> · ${this.escapeHTML(eta)}</span>
              </div>
              <div class="fsb-progress-bar-track">
                <div class="fsb-progress-bar-fill" id="fsbJob_${this.escapeHTML(jobId)}_progress_fill" style="width: ${pct}%;"></div>
              </div>
            </div>

            <!-- Barra de Gasto de Tokens -->
            <div class="fsb-job-token-section" id="fsbJob_${this.escapeHTML(jobId)}_token_wrap">
              <div class="fsb-token-row">
                <span class="fsb-token-label"><i class="ph-bold ph-coins"></i> Consumo de Tokens:</span>
                <span class="fsb-token-val" id="fsbJob_${this.escapeHTML(jobId)}_token_val"><strong>${actTokens}</strong> / ${estTokens} tokens (${tokenPct}%)</span>
              </div>
              <div class="fsb-token-bar-track">
                <div class="fsb-token-bar-fill" id="fsbJob_${this.escapeHTML(jobId)}_token_fill" style="width: ${tokenPct}%;"></div>
              </div>
            </div>

            <!-- Botões de Ação e Controle -->
            ${actionsHtml}
          </div>
          <div class="fsb-msg-meta">
            <span class="fsb-meta-tag time"><i class="ph-bold ph-timer"></i> ${timeFormatted}</span>
            <span class="fsb-meta-tag lane"><i class="ph-bold ph-lightning"></i> JOB_LANE</span>
            <span class="fsb-meta-tag model"><i class="ph-bold ph-cpu"></i> ${this.escapeHTML(model)}</span>
          </div>
        </div>
      `;
      container.appendChild(msg);
      container.scrollTop = container.scrollHeight;

      if (['RUNNING', 'ACTIVE', 'QUEUED', 'PENDING_CONFIRMATION', 'PAUSED'].includes(String(jobStatus).toUpperCase())) {
        this.trackJob(jobId, job);
      }
    },

    appendJobMessage(data, prompt, elapsedMs = 0) {
      this.renderJobMessageInDOM(data, prompt, elapsedMs);
      const conv = this.getActiveConversation();
      if (conv) {
        if (!conv.messages) conv.messages = [];
        conv.messages.push({ type: 'job', data, prompt, elapsedMs, timestamp: new Date().toISOString() });
        conv.updatedAt = new Date().toISOString();
        this.saveConversations();
        this.recordEvolutionaryCheckpoint('JOB_ENQUEUED', { jobId: data.job?.id, title: data.job?.title });
      }
      this.logActivity('JOB', `Job #${data.job?.id || 'NOVO'} registrado na fila [${data.job?.status || 'QUEUED'}]`);
    },

    // ── Universal Forensic & Reverse Engineering Engine ──
    async handleIncomingFiles(fileList) {
      if (!fileList || fileList.length === 0) return;
      for (let i = 0; i < fileList.length; i++) {
        await this.processSingleFile(fileList[i]);
      }
    },

    async processSingleFile(file) {
      if (!file) return;
      const fileName = file.name;
      const fileSize = file.size;
      const formattedSize = this.formatBytes(fileSize);

      // User Bubble showing file attachment
      this.appendMessage('user', `📎 Anexo para Análise Forense & Engenharia Reversa:\n**${fileName}** (${formattedSize})`);

      // Start Loading indicator
      this.startLoadingTimer();
      MascotController.setMood('working');

      try {
        const buffer = await file.arrayBuffer();
        const uint8 = new Uint8Array(buffer);

        // 1. Calculate SHA-256
        const hashBuffer = await crypto.subtle.digest('SHA-256', buffer.slice(0, 32 * 1024 * 1024));
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const sha256 = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

        // 2. Calculate Shannon Entropy
        const sampleLen = Math.min(uint8.length, 262144);
        const freq = new Uint32Array(256);
        for (let i = 0; i < sampleLen; i++) freq[uint8[i]]++;
        let entropy = 0;
        for (let i = 0; i < 256; i++) {
          if (freq[i] > 0) {
            const p = freq[i] / sampleLen;
            entropy -= p * Math.log2(p);
          }
        }
        const entropyScore = Number(entropy.toFixed(3));
        const entropyPercent = Math.min(100, Math.round((entropyScore / 8.0) * 100));

        // Entropy Verdict
        let verdict = {
          badgeClass: 'text',
          badgeText: 'BAIXA ENTROPIA · TEXTO PLANO',
          color: '#38bdf8',
          description: `Entropia baixa (${entropyScore}/8.0). Dados com alta redundância, texto simples ou código fonte sem compressão.`
        };

        if (entropyScore >= 7.65) {
          verdict = {
            badgeClass: 'encrypted',
            badgeText: 'ALTA ENTROPIA · CRIPTOGRAFADO / PACKED',
            color: '#ef4444',
            description: `Distribuição de bytes hiper-aleatória (${entropyScore}/8.0). Fortes indícios de criptografia densa (AES, ChaCha20, RSA) ou compactação executável protegida (Packer).`
          };
        } else if (entropyScore >= 6.80) {
          verdict = {
            badgeClass: 'compressed',
            badgeText: 'MÉDIA-ALTA · COMPACTADO / MULTIMÍDIA',
            color: '#f59e0b',
            description: `Distribuição comprimida (${entropyScore}/8.0). Típica de containers ZIP, codecs de vídeo H.264/AV1 ou streams Deflate/LZMA.`
          };
        } else if (entropyScore >= 3.50) {
          verdict = {
            badgeClass: 'structured',
            badgeText: 'ENTROPIA MÉDIA · ESTRUTURADO',
            color: '#10b981',
            description: `Estrutura regular (${entropyScore}/8.0). Binário padrão, bytecode compilado ou documentos formatados.`
          };
        }

        // 3. Magic Bytes Detection (first 16 bytes)
        const magicHex = Array.from(uint8.slice(0, 16)).map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ');

        // 4. Deep Format & Structure Analysis
        const analysis = this.analyzeBinaryFormat(file, uint8, buffer);

        // 5. Extract Strings & Indicators of Interest
        const extractedStrings = this.extractStringsAndIocs(uint8);

        // If plaintext, store for IDE opening
        if (analysis.isText || fileSize < 1024 * 1024) {
          try {
            const dec = new TextDecoder('utf-8', { fatal: false });
            this._lastUploadedText = dec.decode(uint8.slice(0, 500000));
            this._lastUploadedName = fileName;
          } catch (_) {}
        }

        const forensicData = {
          fileName,
          fileSize,
          fileSizeFormatted: formattedSize,
          sha256,
          entropy: entropyScore,
          entropyPercent,
          verdict,
          magicHex,
          format: analysis.format,
          details: analysis.details,
          strings: extractedStrings,
          timestamp: new Date().toISOString()
        };

        // Notify backend /api/v2/chat/inspect-file
        try {
          authedFetch('/api/v2/chat/inspect-file', {
            method: 'POST',
            body: JSON.stringify({
              name: fileName,
              size: fileSize,
              sha256,
              entropy: entropyScore,
              format: analysis.format.type,
              details: analysis.details,
              strings: extractedStrings.slice(0, 20)
            })
          }).catch(() => {});
        } catch (_) {}

        this.stopLoadingTimer();
        this.appendForensicMessage(forensicData);
        MascotController.setMood('success');
        setTimeout(() => MascotController.setMood('idle'), 2500);
        this.logActivity('FORENSIC', `Arquivo analisado: ${fileName} [${analysis.format.label}, H=${entropyScore}]`);
        this.recordEvolutionaryCheckpoint('FILE_INSPECTED', { name: fileName, format: analysis.format.type, entropy: entropyScore });

      } catch (err) {
        this.stopLoadingTimer();
        this.appendMessage('bot', `Falha ao processar arquivo "${fileName}": ${err.message}`);
        MascotController.setMood('idle');
      }
    },

    analyzeBinaryFormat(file, uint8, buffer) {
      const ext = (file.name.split('.').pop() || '').toLowerCase();
      let format = { type: 'GENERIC_BINARY', label: 'Arquivo Binário', icon: 'ph-file' };
      const details = {};
      let isText = false;

      // 1. ZIP-based (APK, IPA, DOCX, XLSX, PPTX, JAR, ZIP)
      if (uint8.length >= 4 && uint8[0] === 0x50 && uint8[1] === 0x4B && (uint8[2] === 0x03 || uint8[2] === 0x05)) {
        const sliceSample = String.fromCharCode(...uint8.slice(0, Math.min(uint8.length, 1024 * 512))).replace(/[^\x20-\x7E]/g, ' ');
        const hasAndroidManifest = sliceSample.includes('AndroidManifest.xml');
        const hasClassesDex = sliceSample.includes('classes.dex');
        const hasPayload = sliceSample.includes('Payload/') || sliceSample.includes('.app/');
        const hasWordDoc = sliceSample.includes('word/document.xml');
        const hasSheet = sliceSample.includes('xl/workbook.xml');
        const hasPpt = sliceSample.includes('ppt/presentation.xml');

        if (hasAndroidManifest || hasClassesDex || ext === 'apk') {
          format = { type: 'ANDROID_APK', label: 'Android Package (APK)', icon: 'ph-android-logo' };
          details.manifest = hasAndroidManifest ? 'AndroidManifest.xml Presente' : 'Não detectado';
          const dexMatches = sliceSample.match(/classes\d*\.dex/g) || [];
          details.dexFiles = dexMatches.length > 0 ? Array.from(new Set(dexMatches)).join(', ') : '1 DEX primário';
          const abis = [];
          if (sliceSample.includes('arm64-v8a')) abis.push('arm64-v8a');
          if (sliceSample.includes('armeabi-v7a')) abis.push('armeabi-v7a');
          if (sliceSample.includes('x86_64')) abis.push('x86_64');
          if (sliceSample.includes('x86')) abis.push('x86');
          details.architectures = abis.length > 0 ? abis.join(', ') : 'Universal / Sem nativas';
          details.signatures = sliceSample.includes('META-INF') ? 'Assinatura v1/v2 em META-INF detectada' : 'Sem assinatura padrão';
        } else if (hasPayload || ext === 'ipa') {
          format = { type: 'IOS_IPA', label: 'iOS App Package (IPA)', icon: 'ph-apple-logo' };
          details.bundle = 'Bundle iOS / Payload detectado';
          details.plist = sliceSample.includes('Info.plist') ? 'Info.plist presente' : 'Oculto';
        } else if (hasWordDoc || ext === 'docx') {
          format = { type: 'OFFICE_DOCX', label: 'Documento Word (DOCX)', icon: 'ph-file-doc' };
          details.xmlParts = 'Office OpenXML (word/document.xml)';
        } else if (hasSheet || ext === 'xlsx') {
          format = { type: 'OFFICE_XLSX', label: 'Planilha Excel (XLSX)', icon: 'ph-file-xls' };
          details.xmlParts = 'Office OpenXML (xl/workbook.xml)';
        } else if (hasPpt || ext === 'pptx') {
          format = { type: 'OFFICE_PPTX', label: 'Apresentação PowerPoint (PPTX)', icon: 'ph-presentation' };
          details.xmlParts = 'Office OpenXML (ppt/presentation.xml)';
        } else {
          format = { type: 'ARCHIVE_ZIP', label: 'Arquivo ZIP', icon: 'ph-file-archive' };
          details.container = 'Arquivo compactado ZIP padrão';
        }
        return { format, details, isText: false };
      }

      // 2. Adobe PDF
      if (uint8.length >= 4 && uint8[0] === 0x25 && uint8[1] === 0x50 && uint8[2] === 0x44 && uint8[3] === 0x46) {
        format = { type: 'PDF_DOCUMENT', label: 'Documento Adobe PDF', icon: 'ph-file-pdf' };
        const textSample = String.fromCharCode(...uint8.slice(0, Math.min(uint8.length, 16384))).replace(/[^\x20-\x7E]/g, ' ');
        const versionMatch = textSample.match(/%PDF-(\d\.\d)/);
        details.pdfVersion = versionMatch ? `PDF v${versionMatch[1]}` : 'PDF Padrão';
        const isEncrypted = textSample.includes('/Encrypt');
        details.isEncrypted = isEncrypted;
        details.securityStatus = isEncrypted ? '🔒 Criptografia /Encrypt Ativa (Protegido por senha)' : '🔓 Sem senha / Texto e Streams Abertos';
        const pageCountEstimate = (textSample.match(/\/Type\s*\/Page\b/g) || []).length;
        if (pageCountEstimate > 0) details.pageCount = `~${pageCountEstimate} páginas encontradas no header`;
        return { format, details, isText: false };
      }

      // 3. PNG Image
      if (uint8.length >= 8 && uint8[0] === 0x89 && uint8[1] === 0x50 && uint8[2] === 0x4E && uint8[3] === 0x47) {
        let dimensions = 'Dimensões não lidas';
        if (uint8.length >= 24) {
          const view = new DataView(buffer);
          const w = view.getUint32(16, false);
          const h = view.getUint32(20, false);
          dimensions = `${w} x ${h} px`;
        }
        format = { type: 'IMAGE_PNG', label: `Imagem PNG (${dimensions})`, icon: 'ph-image' };
        details.dimensions = dimensions;
        details.colorType = 'RGBA / TrueColor';
        return { format, details, isText: false };
      }

      // 4. JPEG Image
      if (uint8.length >= 3 && uint8[0] === 0xFF && uint8[1] === 0xD8 && uint8[2] === 0xFF) {
        format = { type: 'IMAGE_JPEG', label: 'Imagem JPEG', icon: 'ph-image' };
        const sample = String.fromCharCode(...uint8.slice(0, 2048)).replace(/[^\x20-\x7E]/g, '');
        details.exif = sample.includes('Exif') ? 'Metadados EXIF presentes' : 'JFIF padrão';
        return { format, details, isText: false };
      }

      // 5. RIFF (WebP / WAV / AVI)
      if (uint8.length >= 12 && uint8[0] === 0x52 && uint8[1] === 0x49 && uint8[2] === 0x46 && uint8[3] === 0x46) {
        const sub = String.fromCharCode(uint8[8], uint8[9], uint8[10], uint8[11]);
        if (sub === 'WEBP') {
          format = { type: 'IMAGE_WEBP', label: 'Imagem WebP', icon: 'ph-image' };
          details.riffType = 'WebP Image Container';
        } else if (sub === 'WAVE') {
          format = { type: 'AUDIO_WAV', label: 'Áudio Waveform (WAV)', icon: 'ph-speaker-high' };
          details.riffType = 'RIFF WAVE PCM';
        } else {
          format = { type: 'MEDIA_RIFF', label: `Container RIFF (${sub})`, icon: 'ph-film-strip' };
          details.riffType = sub;
        }
        return { format, details, isText: false };
      }

      // 6. MP4 Video
      if (uint8.length >= 8 && uint8[4] === 0x66 && uint8[5] === 0x74 && uint8[6] === 0x79 && uint8[7] === 0x70) {
        const brand = String.fromCharCode(uint8[8], uint8[9], uint8[10], uint8[11]).trim();
        format = { type: 'VIDEO_MP4', label: `Vídeo MP4 / QuickTime (${brand})`, icon: 'ph-video-camera' };
        details.brand = `ISO Base Media File (${brand})`;
        details.streaming = 'FastStart / Moov Atom';
        return { format, details, isText: false };
      }

      // 7. Matroska / WebM Video
      if (uint8.length >= 4 && uint8[0] === 0x1A && uint8[1] === 0x45 && uint8[2] === 0xDF && uint8[3] === 0xA3) {
        format = { type: 'VIDEO_WEBM', label: 'Vídeo Matroska / WebM', icon: 'ph-video-camera' };
        details.container = 'EBML / Matroska Video Stream';
        return { format, details, isText: false };
      }

      // 8. Linux ELF Executable
      if (uint8.length >= 4 && uint8[0] === 0x7F && uint8[1] === 0x45 && uint8[2] === 0x4C && uint8[3] === 0x46) {
        const bitness = uint8[4] === 2 ? '64-bit' : '32-bit';
        const endian = uint8[5] === 1 ? 'Little Endian' : 'Big Endian';
        format = { type: 'EXEC_ELF', label: `Executável ELF Linux (${bitness})`, icon: 'ph-terminal-window' };
        details.architecture = `${bitness}, ${endian}`;
        details.binaryType = 'Linux ELF Executable / Shared Object';
        return { format, details, isText: false };
      }

      // 9. Windows PE Executable
      if (uint8.length >= 2 && uint8[0] === 0x4D && uint8[1] === 0x5A) {
        format = { type: 'EXEC_PE', label: 'Executável Windows PE (EXE/DLL)', icon: 'ph-windows-logo' };
        details.subsystem = 'Portable Executable 32/64-bit';
        return { format, details, isText: false };
      }

      // 10. Mach-O Executable (macOS/iOS)
      if (uint8.length >= 4 && ((uint8[0] === 0xCF && uint8[1] === 0xFA && uint8[2] === 0xED && uint8[3] === 0xFE) || (uint8[0] === 0xCA && uint8[1] === 0xFE && uint8[2] === 0xBA && uint8[3] === 0xBE))) {
        format = { type: 'EXEC_MACHO', label: 'Binário Mach-O (macOS/iOS)', icon: 'ph-apple-logo' };
        details.subsystem = 'Apple Mach-O Universal / 64-bit';
        return { format, details, isText: false };
      }

      // 11. Plain Text / Code / JSON / Markup
      let printableCount = 0;
      const checkLen = Math.min(uint8.length, 4096);
      for (let i = 0; i < checkLen; i++) {
        const c = uint8[i];
        if ((c >= 32 && c <= 126) || c === 10 || c === 13 || c === 9) printableCount++;
      }
      if (printableCount / checkLen > 0.85) {
        isText = true;
        const textSample = String.fromCharCode(...uint8.slice(0, 512));
        if (textSample.trim().startsWith('{') || textSample.trim().startsWith('[')) {
          format = { type: 'TEXT_JSON', label: 'Documento JSON Estruturado', icon: 'ph-brackets-curly' };
        } else if (['js', 'ts', 'jsx', 'tsx', 'py', 'java', 'c', 'cpp', 'rs', 'go', 'html', 'css', 'sql', 'sh', 'bat', 'ps1'].includes(ext)) {
          format = { type: 'SOURCE_CODE', label: `Código Fonte (.${ext})`, icon: 'ph-code' };
        } else {
          format = { type: 'TEXT_PLAIN', label: 'Texto Plano / Documento', icon: 'ph-file-text' };
        }
        details.encoding = 'UTF-8 / ASCII Legível';
        return { format, details, isText: true };
      }

      return { format, details, isText: false };
    },

    extractStringsAndIocs(uint8) {
      const sample = String.fromCharCode(...uint8.slice(0, Math.min(uint8.length, 262144))).replace(/[^\x20-\x7E]/g, '\n');
      const lines = sample.split('\n').map(s => s.trim()).filter(s => s.length >= 6);
      const unique = Array.from(new Set(lines));

      const iocs = [];
      const normal = [];
      const urlRegex = /^https?:\/\/[^\s"'<>]+$/i;
      const ipRegex = /^(?:\d{1,3}\.){3}\d{1,3}$/;
      const pathRegex = /^\/(?:usr|etc|var|bin|app|system|data|lib)/i;
      const keyRegex = /(?:key|token|secret|password|bearer|auth)/i;

      for (const str of unique) {
        if (urlRegex.test(str)) {
          iocs.push('🌐 URL: ' + str);
        } else if (ipRegex.test(str)) {
          iocs.push('📍 IP: ' + str);
        } else if (pathRegex.test(str)) {
          iocs.push('📁 Path: ' + str);
        } else if (keyRegex.test(str)) {
          iocs.push('🔑 Key/Secret: ' + str);
        } else if (str.length > 8 && !/^[0-9a-f]+$/i.test(str)) {
          normal.push(str);
        }
        if (iocs.length >= 15 && normal.length >= 15) break;
      }

      return [...iocs, ...normal].slice(0, 30);
    },

    renderForensicCardInDOM(data) {
      const container = document.getElementById('fsbChatMessages');
      if (!container) return;
      const msg = document.createElement('div');
      msg.className = 'fsb-msg bot';

      let detailsHtml = '';
      if (data.details && typeof data.details === 'object') {
        detailsHtml = Object.entries(data.details).map(([k, v]) => `
          <div class="fsb-forensic-detail-item">
            <span class="fsb-detail-label">${this.escapeHTML(k)}</span>
            <span class="fsb-detail-val">${this.escapeHTML(String(v))}</span>
          </div>
        `).join('');
      }

      let stringsHtml = '';
      if (Array.isArray(data.strings) && data.strings.length > 0) {
        stringsHtml = `
          <details class="fsb-strings-accordion">
            <summary class="fsb-strings-summary">
              <span><i class="ph-bold ph-magnifying-glass"></i> Indicadores & Strings Extraídas (${data.strings.length})</span>
              <i class="ph-bold ph-caret-down"></i>
            </summary>
            <div class="fsb-strings-body">${data.strings.map(s => this.escapeHTML(s)).join('\n')}</div>
          </details>
        `;
      }

      const safeJsonData = this.escapeHTML(JSON.stringify(data));

      msg.innerHTML = `
        <div class="fsb-msg-sender"><i class="ph-bold ph-shield-check"></i> Mascote Fênix · Forensics & Reverse Engine</div>
        <div class="fsb-bubble" style="padding: 12px;">
          <div style="font-size: 12px; color: #94a3b8; margin-bottom: 6px;">
            Análise estática e inspeção forense concluída:
          </div>

          <div class="fsb-forensic-card">
            <div class="fsb-forensic-header">
              <div class="fsb-forensic-file-info">
                <div class="fsb-forensic-file-icon"><i class="ph-bold ${data.format?.icon || 'ph-file'}"></i></div>
                <div class="fsb-forensic-names">
                  <div class="fsb-forensic-filename" title="${this.escapeHTML(data.fileName)}">${this.escapeHTML(data.fileName)}</div>
                  <div class="fsb-forensic-size">${data.fileSizeFormatted} · ${this.escapeHTML(data.format?.label || 'Binário')}</div>
                </div>
              </div>
              <span class="fsb-forensic-badge ${data.verdict?.badgeClass || 'text'}">${this.escapeHTML(data.verdict?.badgeText || 'NORMAL')}</span>
            </div>

            <div class="fsb-entropy-box">
              <div class="fsb-entropy-top">
                <span class="fsb-entropy-label"><i class="ph-bold ph-chart-line-up"></i> Entropia de Shannon</span>
                <span class="fsb-entropy-value" style="color:${data.verdict?.color || '#38bdf8'};">${data.entropy} / 8.000 (${data.entropyPercent}%)</span>
              </div>
              <div class="fsb-entropy-bar-track">
                <div class="fsb-entropy-bar-fill" style="width:${data.entropyPercent}%; background:${data.verdict?.color || '#38bdf8'};"></div>
              </div>
              <div class="fsb-entropy-assessment">${this.escapeHTML(data.verdict?.description || '')}</div>
            </div>

            <div class="fsb-forensic-details-table">
              <div class="fsb-forensic-detail-item full">
                <span class="fsb-detail-label">Hash SHA-256</span>
                <span class="fsb-detail-val" style="font-size:10px;">
                  <code style="word-break:break-all;">${this.escapeHTML(data.sha256)}</code>
                  <button type="button" class="fsb-history-del-btn" style="color:#22d3ee;" onclick="window.FenixSidebar.copyText('${this.escapeHTML(data.sha256)}', this)" title="Copiar SHA-256"><i class="ph-bold ph-copy"></i></button>
                </span>
              </div>

              <div class="fsb-forensic-detail-item">
                <span class="fsb-detail-label">Magic Bytes Header</span>
                <span class="fsb-detail-val" style="font-size:9.5px;">${this.escapeHTML(data.magicHex || '—')}</span>
              </div>

              <div class="fsb-forensic-detail-item">
                <span class="fsb-detail-label">Classificação</span>
                <span class="fsb-detail-val">${this.escapeHTML(data.format?.label || 'Genérico')}</span>
              </div>

              ${detailsHtml}
            </div>

            ${stringsHtml}

            <div class="fsb-forensic-actions">
              <button type="button" class="fsb-forensic-btn" onclick="window.FenixSidebar.openFileInIde('${this.escapeHTML(data.fileName)}')">
                <i class="ph-bold ph-code"></i> Abrir no IDE
              </button>
              <button type="button" class="fsb-forensic-btn" onclick="window.FenixSidebar.dispatchReverseJob('${this.escapeHTML(data.fileName)}', '${this.escapeHTML(data.format?.type || 'GENERIC')}')">
                <i class="ph-bold ph-lightning"></i> Despachar Job Reverso
              </button>
              <button type="button" class="fsb-forensic-btn secondary" data-forensic="${safeJsonData}" onclick="window.FenixSidebar.downloadForensicJson(JSON.parse(this.dataset.forensic))">
                <i class="ph-bold ph-download-simple"></i> JSON Forense
              </button>
            </div>
          </div>
        </div>
      `;
      container.appendChild(msg);
      container.scrollTop = container.scrollHeight;
    },

    appendForensicMessage(data) {
      this.renderForensicCardInDOM(data);
      const conv = this.getActiveConversation();
      if (conv) {
        if (!conv.messages) conv.messages = [];
        conv.messages.push({ type: 'forensic', data, timestamp: new Date().toISOString() });
        conv.updatedAt = new Date().toISOString();
        this.saveConversations();
      }
    },

    formatBytes(bytes) {
      if (!bytes || bytes === 0) return '0 B';
      const k = 1024;
      const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    },

    copyText(text, btn) {
      if (!text) return;
      navigator.clipboard.writeText(text).then(() => {
        if (btn) {
          const original = btn.innerHTML;
          btn.innerHTML = '<i class="ph-bold ph-check"></i>';
          setTimeout(() => { btn.innerHTML = original; }, 2000);
        }
      });
    },

    downloadForensicJson(data) {
      if (!data) return;
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `relatorio-forense-${data.fileName || 'arquivo'}.json`;
      a.click();
      URL.revokeObjectURL(url);
    },

    async dispatchReverseJob(fileName, formatType) {
      try {
        const res = await authedFetch('/api/v2/chat/inspect-file', {
          method: 'POST',
          body: JSON.stringify({
            name: fileName,
            format: formatType,
            createJob: true
          })
        });
        if (res.ok) {
          const data = await res.json();
          this.appendMessage('system', `⚡ Job de Engenharia Reversa para "${fileName}" despachado com sucesso! [Job #${data.job?.id || 'NOVO'}]`);
          MascotController.setMood('working');
        }
      } catch (e) {
        this.appendMessage('bot', `Falha ao despachar job de engenharia reversa: ${e.message}`);
      }
    },

    openFileInIde(fileName) {
      if (typeof window.showView === 'function') {
        window.showView('ide');
      }
      if (this._lastUploadedText && this._lastUploadedName === fileName) {
        setTimeout(() => {
          const codeArea = document.getElementById('fenixIdeLiveCode');
          const pathEl = document.getElementById('fenixIdeLivePath');
          if (codeArea) {
            codeArea.value = this._lastUploadedText;
            codeArea.dispatchEvent(new Event('input'));
          }
          if (pathEl) pathEl.textContent = 'anexo/' + fileName;
          const statusEl = document.getElementById('fenixIdeLiveStatus');
          if (statusEl) statusEl.textContent = 'Arquivo carregado no editor (Análise Forense)';
        }, 300);
      }
    },

    copyCode(btn) {
      if (!btn) return;
      const pre = btn.closest('.fsb-code-block');
      const code = pre?.querySelector('code');
      if (code) {
        const textToCopy = code.innerText || code.textContent || '';
        navigator.clipboard.writeText(textToCopy).then(() => {
          const original = btn.innerHTML;
          btn.innerHTML = '<i class="ph-bold ph-check"></i> Copiado!';
          setTimeout(() => { btn.innerHTML = original; }, 2000);
        }).catch(() => {
          btn.textContent = 'Erro ao copiar';
        });
      }
    },

    executeAction(act) {
      if (!act) return;
      if (typeof act === 'string') {
        if (act.startsWith('/')) {
          this.handleCommand(act);
        } else {
          const input = document.getElementById('fsbChatInput');
          if (input) {
            input.value = act;
            this.sendChatMessage();
          }
        }
        return;
      }

      switch (act.type) {
        case 'switch_view':
          if (typeof window.switchView === 'function') {
            window.switchView(act.view);
          } else if (typeof window.showView === 'function') {
            window.showView(act.view.replace('view-', ''));
          }
          this.logActivity('NAV', `Navegando para: ${act.view}`);
          break;

        case 'open_ide_project':
          if (typeof window.switchView === 'function') {
            window.switchView('view-ide');
          }
          if (window.fenixSelectIdeProject) {
            window.fenixSelectIdeProject(act.projectId).catch(err => {
              console.warn('[IDE] Falha ao trocar projeto:', err.message);
            });
          }
          this.logActivity('IDE', `Abrindo projeto: ${act.projectId}`);
          break;

        case 'open_ide_file':
          if (typeof window.switchView === 'function') {
            window.switchView('view-ide');
          }
          if (window.fenixSelectIdeFile) {
            window.fenixSelectIdeFile(act.path).catch(err => {
              console.warn('[IDE] Falha ao abrir arquivo:', err.message);
            });
          }
          this.logActivity('IDE', `Abrindo arquivo: ${act.path}`);
          break;

        case 'city_focus':
          if (typeof window.switchView === 'function') {
            window.switchView('view-city');
          }
          window.dispatchEvent(new CustomEvent('city:focus', { detail: act }));
          this.logActivity('CITY', `Foco na Cidade 3D: ${act.target || 'centro'}`);
          break;

        case 'confirm_job':
          this.confirmJob(act.jobId);
          break;

        case 'send_command':
          if (act.command) {
            if (act.command.startsWith('/')) {
              this.handleCommand(act.command);
            } else {
              const input = document.getElementById('fsbChatInput');
              if (input) input.value = act.command;
              this.sendChatMessage();
            }
          }
          break;

        default:
          if (act.label) {
            this.handleCommand(act.label);
          }
          break;
      }
    },

    async approveJob(jobId) {
      try {
        let ok = false;
        try {
          const res = await authedFetch(`/api/v2/jobs/${encodeURIComponent(jobId)}/approve`, { method: 'POST' });
          if (res.ok) ok = true;
        } catch (_) {}

        if (!ok) {
          const res2 = await authedFetch(`/api/v2/jobs/${encodeURIComponent(jobId)}/confirm`, { method: 'POST' });
          if (res2.ok) ok = true;
        }

        if (ok) {
          this.updateJobCardDOM(jobId, { id: jobId, status: 'RUNNING', progress: 15 });
          this.appendMessage('system', `▶ Job #${jobId} aprovado com sucesso! Executando em segundo plano no BullMQ.`);
          MascotController.setMood('working');
          this.trackJob(jobId, { id: jobId, status: 'RUNNING' });
          this.logActivity('JOB', `Job #${jobId} aprovado e iniciado em segundo plano.`);
        } else {
          await authedFetch('/api/v2/conversation', {
            method: 'POST',
            body: JSON.stringify({ message: 'confirmar' })
          });
          this.updateJobCardDOM(jobId, { id: jobId, status: 'RUNNING', progress: 15 });
          this.appendMessage('system', `▶ Confirmação despachada para Job #${jobId}.`);
          MascotController.setMood('working');
          this.trackJob(jobId, { id: jobId, status: 'RUNNING' });
        }
      } catch (e) {
        this.appendMessage('bot', `Falha ao aprovar job #${jobId}: ${e.message}`);
      }
    },

    async confirmJob(jobId) {
      return this.approveJob(jobId);
    },

    async pauseJob(jobId) {
      try {
        const res = await authedFetch(`/api/v2/jobs/${encodeURIComponent(jobId)}/pause`, { method: 'POST' });
        if (res.ok) {
          this.updateJobCardDOM(jobId, { id: jobId, status: 'PAUSED' });
          this.appendMessage('system', `⏸ Job #${jobId} pausado pelo operador.`);
          MascotController.setMood('idle');
          this.logActivity('JOB', `Job #${jobId} pausado.`);
        } else {
          this.appendMessage('bot', `Não foi possível pausar job #${jobId}. Verifique se já foi finalizado.`);
        }
      } catch (e) {
        this.appendMessage('bot', `Falha ao pausar job #${jobId}: ${e.message}`);
      }
    },

    async resumeJob(jobId) {
      try {
        const res = await authedFetch(`/api/v2/jobs/${encodeURIComponent(jobId)}/resume`, { method: 'POST' });
        if (res.ok) {
          this.updateJobCardDOM(jobId, { id: jobId, status: 'RUNNING' });
          this.appendMessage('system', `▶ Job #${jobId} retomado com sucesso.`);
          MascotController.setMood('working');
          this.trackJob(jobId, { id: jobId, status: 'RUNNING' });
          this.logActivity('JOB', `Job #${jobId} retomado.`);
        } else {
          this.appendMessage('bot', `Não foi possível retomar job #${jobId}.`);
        }
      } catch (e) {
        this.appendMessage('bot', `Falha ao retomar job #${jobId}: ${e.message}`);
      }
    },

    async cancelJob(jobId) {
      try {
        const res = await authedFetch(`/api/v2/jobs/${encodeURIComponent(jobId)}/cancel`, { method: 'POST' });
        if (res.ok) {
          this.updateJobCardDOM(jobId, { id: jobId, status: 'CANCELLED', progress: 0 });
          if (this._trackedJobs) this._trackedJobs.delete(String(jobId));
          this.appendMessage('system', `🛑 Job #${jobId} cancelado pelo operador.`);
          MascotController.setMood('idle');
          this.logActivity('JOB', `Job #${jobId} cancelado.`);
        } else {
          this.appendMessage('bot', `Não foi possível cancelar job #${jobId}.`);
        }
      } catch (e) {
        this.appendMessage('bot', `Falha ao cancelar job #${jobId}: ${e.message}`);
      }
    },

    logActivity(tag, text) {
      const logsContainer = document.getElementById('fsbLogsContainer');
      if (!logsContainer) return;
      const row = document.createElement('div');
      row.className = 'fsb-log-row';
      const time = new Date().toTimeString().slice(0, 8);
      row.innerHTML = `
        <span class="fsb-log-time">${time}</span>
        <span class="fsb-log-tag info">${this.escapeHTML(tag)}</span>
        <span class="fsb-log-text">${this.escapeHTML(text)}</span>
      `;
      logsContainer.appendChild(row);
      if (logsContainer.children.length > 100) logsContainer.removeChild(logsContainer.children[0]);
      logsContainer.scrollTop = logsContainer.scrollHeight;
    },

    async sendChatMessage() {
      const input = document.getElementById('fsbChatInput');
      const text = input?.value.trim();
      if (!text) return;
      input.value = '';

      this.appendMessage('user', text);
      MascotController.setMood('working');

      // Comandos especiais
      if (text.startsWith('/')) {
        await this.handleCommand(text);
        return;
      }

      const startTime = Date.now();
      this.startLoadingTimer();

      // 1. Dual-Lane Engine (/api/v2/conversation)
      try {
        const res = await authedFetch('/api/v2/conversation', {
          method: 'POST',
          body: JSON.stringify({ message: text, agent: state.selectedAgent })
        });

        if (res.ok) {
          this.stopLoadingTimer();
          const elapsedMs = Date.now() - startTime;
          const data = await res.json();
          if (data.lane === 'JOB_LANE') {
            this.appendJobMessage(data, text, elapsedMs);
            MascotController.setMood('working');
          } else {
            this.appendBotMessage(data, text, elapsedMs);
            MascotController.setMood('success');
            setTimeout(() => MascotController.setMood('idle'), 2500);
          }
          this.logActivity('CHAT', `Mensagem atendida [${data.lane || 'FAST_LANE'}]`);
          return;
        }
      } catch (err) {
        console.warn('[FENIX SIDEBAR] Falha em /api/v2/conversation, tentando fallback:', err.message);
      }

      // 2. Fallback to /api/command
      try {
        const res = await authedFetch('/api/command', {
          method: 'POST',
          body: JSON.stringify({ command: text, prompt: text, agent: state.selectedAgent })
        });

        this.stopLoadingTimer();
        const elapsedMs = Date.now() - startTime;

        if (res.ok) {
          const data = await res.json();
          const reply = data.reply || data.output || data.message || `Missão #${data.missionId || 'auto'} criada no Kernel.`;
          this.appendBotMessage({ response: reply, lane: 'FAST_LANE', model: 'command-engine' }, text, elapsedMs);
          MascotController.setMood('success');
          setTimeout(() => MascotController.setMood('idle'), 2500);
          this.logActivity('MISSION', `Missão iniciada: ${text.slice(0, 30)}`);
        } else {
          this.appendBotMessage({ response: `Comando recebido no Fênix Kernel (HTTP ${res.status}). Tarefa registrada no histórico operacional.`, lane: 'KERNEL_LANE', model: 'supervisor' }, text, elapsedMs);
          MascotController.setMood('idle');
        }
      } catch (err) {
        this.stopLoadingTimer();
        const elapsedMs = Date.now() - startTime;
        this.appendBotMessage({ response: `Comando processado localmente: "${text}". Observabilidade registrada no log.`, lane: 'LOCAL_LANE', model: 'offline-agent' }, text, elapsedMs);
        MascotController.setMood('idle');
      }
    },

    async handleCommand(cmd) {
      MascotController.setMood('thinking');
      const clean = cmd.trim();

      if (clean === '/vps-status') {
        this.appendMessage('system', 'Consultando telemetria em tempo real da VPS...');
        const telem = await this.fetchTelemetry(true);
        this.appendMessage('bot', `📊 **Status da VPS (209.50.241.22):**\n• Host Health: ${telem.vpsStatus}\n• API Platform: ${telem.apiPlatform}\n• RAM: ${telem.ram}\n• Latência: ${telem.latency}\n• Uptime: ${telem.uptime}`);
        MascotController.setMood('success');
      } else if (clean === '/health') {
        this.appendMessage('system', 'Verificando integridade das 5 Regras de Ouro...');
        try {
          const sysRes = await authedFetch('/api/v2/system/health');
          const sysData = sysRes.ok ? await sysRes.json() : null;
          this.appendMessage('bot', `✅ **Integridade do Fênix OS:**\n• Single Source of Truth inviolada (0 shells paralelas)\n• Zero-Mock compliance ativo\n• Serviços PM2 #16 e #17 ONLINE\n• Kernel: ${sysData?.status || 'ONLINE'}`);
        } catch (_) {
          this.appendMessage('bot', '✅ Integridade 100% OK:\n• Single Source of Truth inviolada (0 shells paralelas)\n• Zero-Mock compliance ativo\n• Serviços PM2 #16 e #17 Online');
        }
        MascotController.setMood('success');
      } else if (clean === '/memory') {
        this.appendMessage('system', 'Lendo Memória Ativa e Graph Brain...');
        try {
          const gRes = await authedFetch('/api/v2/graph/data');
          const gData = gRes.ok ? await gRes.json() : null;
          const nodeCount = gData?.nodes?.length ?? '—';
          const edgeCount = gData?.edges?.length ?? '—';
          this.appendMessage('bot', `🧠 **Graph Brain & Memória Ativa:**\n• Entidades no Grafo: ${nodeCount}\n• Relações: ${edgeCount}\n• GitHub Conectado (@Biel0071)\n• Sistema de absorção de telas ativo`);
        } catch (_) {
          this.appendMessage('bot', '🧠 ACTIVE_PROJECT_MEMORY.md sincronizado:\n• GitHub conectado (@Biel0071)\n• 10 Repositórios mapeados\n• Sistema de absorção de telas ativo');
        }
        MascotController.setMood('success');
      } else if (clean === '/agents') {
        if (window.showView) window.showView('agents');
        this.appendMessage('bot', 'Alternando para a Central de Agentes RPG...');
        MascotController.setMood('idle');
      } else if (clean === '/jobs') {
        try {
          const qRes = await authedFetch('/api/v2/queue/status');
          const qData = qRes.ok ? await qRes.json() : null;
          this.appendMessage('bot', `📋 **Fila de Jobs (BullMQ):**\n• Ativos: ${qData?.active || 0}\n• Em Espera: ${qData?.waiting || 0}\n• Concluídos: ${qData?.completed || 0}\n• Falhas: ${qData?.failed || 0}`);
        } catch (_) {
          this.appendMessage('bot', '📋 Fila de jobs consultada. Nenhum job bloqueado no momento.');
        }
        MascotController.setMood('idle');
      } else if (['/fast', '/qwen', '/auto'].includes(clean)) {
        try {
          const cRes = await authedFetch('/api/v2/conversation', {
            method: 'POST',
            body: JSON.stringify({ message: clean })
          });
          const cData = cRes.ok ? await cRes.json() : null;
          this.appendMessage('bot', cData?.response || `Modo alternado para ${clean.slice(1).toUpperCase()}`);
        } catch (_) {
          this.appendMessage('bot', `Modo de inferência alternado para: ${clean.slice(1).toUpperCase()}`);
        }
        MascotController.setMood('success');
      } else {
        this.appendMessage('bot', `Comando desconhecido: ${clean}. Tente /vps-status, /health, /memory, /agents, /jobs, /fast ou /qwen.`);
        MascotController.setMood('idle');
      }
    },

    async fetchTelemetry(manual = false) {
      if (manual) MascotController.setMood('working');
      try {
        const [sysRes, apiRes] = await Promise.all([
          authedFetch('/api/v2/system/health').catch(() => null),
          authedFetch('/api/v2/api-platform/health').catch(() => null)
        ]);

        const sysData = sysRes && sysRes.ok ? await sysRes.json() : null;
        const apiData = apiRes && apiRes.ok ? await apiRes.json() : null;

        const cpu = sysData?.system?.cpu != null ? `${sysData.system.cpu}%` : (sysData?.cpu != null ? `${Math.round(sysData.cpu * 100)}%` : '—');
        const ram = sysData?.memory?.usedMb ? `${sysData.memory.usedMb} MB` : (sysData?.system?.ram ? `${sysData.system.ram} MB` : '—');
        const latency = apiData?.latency != null ? `${apiData.latency} ms` : '—';
        const uptimeSeconds = sysData?.uptime || apiData?.uptime || 0;
        const uptime = uptimeSeconds >= 3600 ? `${Math.floor(uptimeSeconds / 3600)}h` : (uptimeSeconds >= 60 ? `${Math.floor(uptimeSeconds / 60)}m` : (uptimeSeconds > 0 ? `${uptimeSeconds}s` : '—'));
        const vpsStatus = (sysData?.status || apiData?.status || '—').toUpperCase();
        const apiPlatform = apiData ? (apiData.status || (apiData.success ? 'ONLINE (:3001)' : 'OFFLINE')) : '—';
        const jobs = sysData?.activeJobs != null ? String(sysData.activeJobs) : '—';

        // Atualizar painel (zero-mock honest)
        this.setDOMText('fsbTelemCpu', cpu);
        this.setDOMText('fsbTelemRam', ram);
        this.setDOMText('fsbTelemLatency', latency);
        this.setDOMText('fsbTelemUptime', uptime);
        this.setDOMText('fsbTelemApiPlatform', apiPlatform);
        this.setDOMText('fsbTelemJobs', jobs);
        this.setDOMText('fsbTelemKernelState', sysData?.status || '—');

        // Atualizar Letreiro Inferior Contínuo (Live Marquee Ticker)
        this.setDOMText('tickerCpu', cpu);
        this.setDOMText('tickerCpu2', cpu);
        this.setDOMText('tickerRam', ram);
        this.setDOMText('tickerRam2', ram);
        this.setDOMText('tickerUptime', uptime);
        this.setDOMText('tickerUptime2', uptime);
        this.setDOMText('tickerJobs', jobs);
        this.setDOMText('tickerJobs2', jobs);
        if (apiPlatform && apiPlatform !== '—') {
          this.setDOMText('tickerApiPlatform', apiPlatform);
        }

        if (manual) MascotController.setMood('success');
        return { cpu, ram, latency, uptime, vpsStatus, apiPlatform, jobs };
      } catch (err) {
        if (manual) MascotController.setMood('error');
        return { cpu: '—', ram: '—', latency: '—', uptime: '—', vpsStatus: '—', apiPlatform: '—', jobs: '—' };
      }
    },

    async execTerminalCommand(cmd) {
      const out = document.getElementById('fsbTerminalOutput');
      if (!out) return;
      out.textContent += `\nfenix> ${cmd}\n`;

      const clean = cmd.trim().toLowerCase();
      if (clean === 'help') {
        out.textContent += 'Comandos disponíveis: status, vps, health, memory, jobs, clear\n';
      } else if (clean === 'clear') {
        out.textContent = 'Fênix OS Live Terminal [Version 2.1.0]\n';
      } else if (clean === 'status') {
        out.textContent += '[KERNEL] Fênix OS Engine: ONLINE | PM2 #16: Online | PM2 #17: Online\n';
      } else if (clean === 'vps') {
        out.textContent += '[VPS 209.50.241.22] Docker Fastify: 3001 | Postgres 16: 5433 | Redis 7: 6380\n';
      } else if (clean === 'jobs') {
        out.textContent += '[JOBS] Consultando fila...\n';
        try {
          const qRes = await authedFetch('/api/v2/queue/status');
          const qData = qRes.ok ? await qRes.json() : null;
          out.textContent += `Ativos: ${qData?.active || 0} | Espera: ${qData?.waiting || 0} | Concluídos: ${qData?.completed || 0}\n`;
        } catch (_) {
          out.textContent += 'Fila ativa no runtime.\n';
        }
      } else {
        try {
          const res = await authedFetch('/api/v2/conversation', {
            method: 'POST',
            body: JSON.stringify({ message: cmd })
          });
          if (res.ok) {
            const data = await res.json();
            out.textContent += `[RESP] ${data.response || 'Executado.'}\n`;
          } else {
            out.textContent += `[EXEC] Comando "${cmd}" enviado ao runtime (HTTP ${res.status}).\n`;
          }
        } catch (e) {
          out.textContent += `[EXEC] Comando "${cmd}" registrado.\n`;
        }
      }
      out.scrollTop = out.scrollHeight;
    },

    setDOMText(id, val) {
      const el = document.getElementById(id);
      if (el) el.textContent = val;
    },

    escapeHTML(str) {
      return String(str || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
    }
  };

  // ── Controlador do Dossiê RPG & Customizer Habbo/Tibia de Agentes ──
  const AgentRosterRPG = {
    init() {
      // Fechar modal
      document.getElementById('fadCloseBtn')?.addEventListener('click', () => this.closeModal());
      modalEl?.addEventListener('click', (e) => {
        if (e.target === modalEl) this.closeModal();
      });

      // Tabs do Modal
      document.querySelectorAll('.fad-tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const pan = btn.dataset.fpan;
          document.querySelectorAll('.fad-tab-btn').forEach(b => b.classList.toggle('active', b === btn));
          document.querySelectorAll('.fad-tab-pane').forEach(p => p.classList.remove('active'));
          document.getElementById(`fadPane${pan.charAt(0).toUpperCase() + pan.slice(1)}`)?.classList.add('active');
        });
      });

      // Paletas de Cor
      this.renderPalettes();

      // Chat Direto no Modal
      document.getElementById('fadDirectSendBtn')?.addEventListener('click', () => this.sendDirectMessage());
      document.getElementById('fadDirectInput')?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') this.sendDirectMessage();
      });

      // Interceptar cliques nos cartões de agentes para abrir o Dossiê
      this.hookAgentCards();
    },

    renderPalettes() {
      const skinBox = document.getElementById('fadSkinPalette');
      const hairBox = document.getElementById('fadHairPalette');
      const shirtBox = document.getElementById('fadShirtPalette');

      if (skinBox) {
        skinBox.innerHTML = SKIN_COLORS.map((c, i) => `<div class="fad-palette-dot ${i === 0 ? 'active' : ''}" style="background:${c};" data-skin="${c}"></div>`).join('');
        skinBox.querySelectorAll('.fad-palette-dot').forEach(dot => {
          dot.addEventListener('click', () => {
            skinBox.querySelectorAll('.fad-palette-dot').forEach(d => d.classList.remove('active'));
            dot.classList.add('active');
            this.updateCustomAvatar({ skinColor: dot.dataset.skin });
          });
        });
      }

      if (hairBox) {
        hairBox.innerHTML = HAIR_COLORS.map((c, i) => `<div class="fad-palette-dot ${i === 0 ? 'active' : ''}" style="background:${c};" data-hair="${c}"></div>`).join('');
        hairBox.querySelectorAll('.fad-palette-dot').forEach(dot => {
          dot.addEventListener('click', () => {
            hairBox.querySelectorAll('.fad-palette-dot').forEach(d => d.classList.remove('active'));
            dot.classList.add('active');
            this.updateCustomAvatar({ hairColor: dot.dataset.hair });
          });
        });
      }

      if (shirtBox) {
        shirtBox.innerHTML = SHIRT_COLORS.map((c, i) => `<div class="fad-palette-dot ${i === 0 ? 'active' : ''}" style="background:${c};" data-shirt="${c}"></div>`).join('');
        shirtBox.querySelectorAll('.fad-palette-dot').forEach(dot => {
          dot.addEventListener('click', () => {
            shirtBox.querySelectorAll('.fad-palette-dot').forEach(d => d.classList.remove('active'));
            dot.classList.add('active');
            this.updateCustomAvatar({ shirtColor: dot.dataset.shirt });
          });
        });
      }
    },

    openModal(agentId, agentData = null) {
      state.activeInspectAgent = agentData || { id: agentId, name: agentId, role: 'Specialist' };
      if (!modalEl) return;

      const title = document.getElementById('fadAgentTitle');
      const roleName = document.getElementById('fadRoleName');
      const specRole = document.getElementById('fadSpecRole');
      const specStatus = document.getElementById('fadSpecStatus');
      const nodeName = document.getElementById('fadTreeNodeName');
      const welcome = document.getElementById('fadDirectWelcome');

      const name = state.activeInspectAgent.name || agentId;
      const role = state.activeInspectAgent.role || 'Specialist';
      const status = state.activeInspectAgent.status || 'AVAILABLE';

      if (title) title.textContent = `DOSSIÊ: ${name.toUpperCase()}`;
      if (roleName) roleName.textContent = role.toUpperCase();
      if (specRole) specRole.textContent = role;
      if (specStatus) specStatus.textContent = status === 'WORKING' ? 'EM EXECUÇÃO' : 'DISPONÍVEL';
      if (nodeName) nodeName.textContent = name;
      if (welcome) welcome.textContent = `Canal direto ativo com ${name} (${role}). Pronto para receber tarefas específicas.`;

      // Renderizar Avatar 2.5D no Canvas do Dossiê
      this.drawHabboAvatar();

      modalEl.classList.add('open');
    },

    closeModal() {
      modalEl?.classList.remove('open');
    },

    drawHabboAvatar(customProps = {}) {
      const canvas = document.getElementById('fadPixelCanvas');
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const skin = customProps.skinColor || SKIN_COLORS[1];
      const hair = customProps.hairColor || HAIR_COLORS[0];
      const shirt = customProps.shirtColor || SHIRT_COLORS[0];

      // Desenho em Pixel-Art Modular estilo Habbo/Tibia (Escalado)
      // 1. Sombra de Contato
      ctx.fillStyle = 'rgba(0,0,0,0.3)';
      ctx.beginPath();
      ctx.ellipse(32, 90, 16, 5, 0, 0, Math.PI * 2);
      ctx.fill();

      // 2. Pernas / Calças
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(24, 58, 7, 24);
      ctx.fillRect(33, 58, 7, 24);

      // 3. Sapatos
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(23, 80, 8, 5);
      ctx.fillRect(33, 80, 8, 5);

      // 4. Torso / Camisa
      ctx.fillStyle = shirt;
      ctx.fillRect(21, 36, 22, 23);

      // 5. Cabeça / Rosto
      ctx.fillStyle = skin;
      ctx.fillRect(22, 14, 20, 20);

      // 6. Cabelo
      ctx.fillStyle = hair;
      ctx.fillRect(20, 11, 24, 8);
      ctx.fillRect(19, 14, 4, 10);

      // 7. Olhos Pixelados
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(26, 22, 3, 3);
      ctx.fillRect(35, 22, 3, 3);
      ctx.fillStyle = '#38bdf8';
      ctx.fillRect(27, 23, 1, 1);
      ctx.fillRect(36, 23, 1, 1);

      // 8. Laptop Brilhante na Mão
      ctx.fillStyle = '#1e1b4b';
      ctx.fillRect(22, 48, 20, 12);
      ctx.fillStyle = '#22d3ee';
      ctx.fillRect(24, 50, 16, 8);
    },

    updateCustomAvatar(props) {
      this.drawHabboAvatar(props);
      if (state.activeInspectAgent) {
        localStorage.setItem(`fenix_avatar_${state.activeInspectAgent.id}`, JSON.stringify(props));
      }
    },

    sendDirectMessage() {
      const input = document.getElementById('fadDirectInput');
      const text = input?.value.trim();
      if (!text) return;
      input.value = '';

      const container = document.getElementById('fadDirectChatMessages');
      if (!container) return;

      const userMsg = document.createElement('div');
      userMsg.className = 'fsb-msg user';
      userMsg.innerHTML = `<div class="fsb-bubble">${SidebarController.escapeHTML(text)}</div>`;
      container.appendChild(userMsg);

      setTimeout(() => {
        const agentName = state.activeInspectAgent?.name || 'Agente';
        const botMsg = document.createElement('div');
        botMsg.className = 'fsb-msg bot';
        botMsg.innerHTML = `<div class="fsb-bubble"><strong>[${agentName}]</strong> Entendido! Processando diretiva no contexto do projeto.</div>`;
        container.appendChild(botMsg);
        container.scrollTop = container.scrollHeight;
      }, 500);
    },

    hookAgentCards() {
      // Quando os cards de agentes forem clicados na view-agents, intercepta e abre o Dossiê
      document.addEventListener('click', (e) => {
        const card = e.target.closest('#fenix-agents-grid .cp-agent-card[data-agent-id]');
        if (card) {
          const id = card.dataset.agentId;
          const name = card.querySelector('.cp-agent-name')?.textContent || id;
          const role = card.querySelector('.cp-agent-role')?.textContent || 'Specialist';
          const status = card.dataset.agentStatus || 'AVAILABLE';
          AgentRosterRPG.openModal(id, { id, name, role, status });
        }
      });
    }
  };

  // ── Inicialização Geral ao Carregar o DOM ──
  function init() {
    ensureDOMElements();
    MascotController.initDrag();
    SidebarController.initEvents();
    SidebarController.initConversations();
    AgentRosterRPG.init();

    // Telemetria inicial e loop periódico de 10s para manter o letreiro e painel vivos
    SidebarController.fetchTelemetry();
    setInterval(() => SidebarController.fetchTelemetry(), 10000);

    // Restaurar largura e modo docked (Lovable Split Screen)
    const savedWidth = localStorage.getItem('fenix_sidebar_width') || '380px';
    document.documentElement.style.setProperty('--fsb-width', savedWidth);
    state.isDocked = localStorage.getItem('fenix_sidebar_docked') !== 'false';
    document.body.classList.toggle('fsb-docked', state.isDocked);
    const dockBtnEl = document.getElementById('fsbDockBtn');
    if (dockBtnEl) {
      dockBtnEl.classList.toggle('active', state.isDocked);
      const text = document.getElementById('fsbDockBtnText');
      if (text) text.textContent = state.isDocked ? 'Split' : 'Float';
    }

    // Exportar na janela global do Fênix para interoperabilidade
    window.FenixMascotSidebar = {
      MascotController,
      SidebarController,
      AgentRosterRPG,
      setMood: (m) => MascotController.setMood(m),
      toggle: () => MascotController.toggle(),
      openAgentDossier: (id) => AgentRosterRPG.openModal(id)
    };

    // Ouvinte de Eventos em Tempo Real do Fênix OS (EventBus / WebSocket)
    document.addEventListener('fenix-live', (evt) => {
      const detail = evt.detail || {};
      const type = String(detail.type || 'event').toLowerCase();

      // Filtrar ruído de heartbeat e polling vazio
      if (type === 'status' || type === 'ping' || type === 'heartbeat' || (type === 'runtime.snapshot' && !detail.message)) {
        return;
      }

      const time = new Date().toLocaleTimeString('pt-BR');

      // 1. Adicionar ao Stream de Logs
      const logsContainer = document.getElementById('fsbLogsContainer');
      if (logsContainer) {
        const row = document.createElement('div');
        row.className = 'fsb-log-row';
        let tag = 'SYS';
        let tagType = 'info';

        if (type.includes('agent')) { tag = 'AGENT'; tagType = 'action'; }
        else if (type.includes('job') || type.includes('mission')) { tag = 'JOB'; tagType = 'action'; }
        else if (type.includes('ide') || type.includes('project')) { tag = 'IDE'; tagType = 'info'; }
        else if (type.includes('chat') || type.includes('lane')) { tag = 'CHAT'; tagType = 'info'; }
        else if (type.includes('error') || type.includes('fail')) { tag = 'ERROR'; tagType = 'error'; }
        else if (type.includes('vps') || type.includes('docker')) { tag = 'VPS'; tagType = 'info'; }
        else if (type.includes('git')) { tag = 'GIT'; tagType = 'info'; }

        const rawMsg = detail.message || detail.payload?.name || detail.payload?.title || detail.text || type;
        row.innerHTML = `
          <span class="fsb-log-time">${time}</span>
          <span class="fsb-log-tag ${tagType}">${SidebarController.escapeHTML(tag)}</span>
          <span class="fsb-log-text">${SidebarController.escapeHTML(rawMsg)}</span>
        `;
        logsContainer.appendChild(row);
        if (logsContainer.children.length > 150) logsContainer.removeChild(logsContainer.children[0]);
        logsContainer.scrollTop = logsContainer.scrollHeight;
      }

      // 2. Reação do Mascote
      if (type.includes('start') || type.includes('dispatched')) {
        MascotController.setMood('working');
      } else if (type.includes('complete') || type.includes('success')) {
        MascotController.setMood('success');
      } else if (type.includes('fail') || type.includes('error')) {
        MascotController.setMood('error');
      }
    });

    window.FenixSidebar = {
      toggle: () => MascotController.toggle(),
      open: () => { if (!state.isOpen) MascotController.toggle(); },
      confirmJob: (jobId) => SidebarController.approveJob(jobId),
      approveJob: (jobId) => SidebarController.approveJob(jobId),
      pauseJob: (jobId) => SidebarController.pauseJob(jobId),
      resumeJob: (jobId) => SidebarController.resumeJob(jobId),
      cancelJob: (jobId) => SidebarController.cancelJob(jobId),
      updateJobCardDOM: (jobId, job) => SidebarController.updateJobCardDOM(jobId, job),
      trackJob: (jobId, job) => SidebarController.trackJob(jobId, job),
      executeAction: (act) => SidebarController.executeAction(act),
      copyCode: (btn) => SidebarController.copyCode(btn),
      handleCommand: (cmd) => SidebarController.handleCommand(cmd),
      switchConversation: (id) => SidebarController.switchConversation(id),
      deleteConversation: (id, e) => SidebarController.deleteConversation(id, e),
      startNewConversation: () => SidebarController.startNewConversation(),
      toggleHistory: () => SidebarController.toggleHistoryDrawer(),
      copyText: (text, btn) => SidebarController.copyText(text, btn),
      downloadForensicJson: (data) => SidebarController.downloadForensicJson(data),
      dispatchReverseJob: (fileName, formatType) => SidebarController.dispatchReverseJob(fileName, formatType),
      openFileInIde: (fileName) => SidebarController.openFileInIde(fileName),
      send: (message) => {
        const input = document.getElementById('fsbChatInput');
        if (input) {
          input.value = message;
          SidebarController.sendChatMessage();
        }
      },
      setMood: (mood) => MascotController.setMood(mood),
      fetchTelemetry: (m) => SidebarController.fetchTelemetry(m)
    };

    console.log('[FENIX] Mascot Sidebar & RPG Agent Studio Inicializado com Sucesso.');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
