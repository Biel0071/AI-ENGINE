const { StorageManager } = require('../src/storage/storage-manager');
const { KnowledgeEngine } = require('../src/knowledge/knowledge-engine');

async function testKnowledge() {
  const sm = new StorageManager();
  await sm.boot();
  console.log('Stats:', sm.getStats());

  const engine = new KnowledgeEngine({ storageManager: sm, eventBus: { on: () => {} } });
  
  await engine.episodicMemory.recordEpisode('test1', { action: 'start' });
  const episode = await engine.episodicMemory.retrieveEpisode('test1');
  console.log('Episode:', episode);

  await engine.semanticMemory.memorize('vec1', 'Hello Semantic', { tags: ['test'] });
  const search = await engine.semanticMemory.search('hello');
  console.log('Search Result:', search);
  
  await engine.longTermMemory.learnFact('fact1', 'The sky is blue');
  const fact = await engine.longTermMemory.recall('fact1');
  console.log('Fact:', fact);
  
  await sm.shutdown();
}

testKnowledge().catch(console.error);
